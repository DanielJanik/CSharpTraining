# DeweyLib — Complete Solution (Milestones 1–12)

The finished DeweyLib application from the lab, organized exactly as Milestone
12 prescribes: a shared core library, a console app, and a REST API — the
console and the API both sitting on top of the *same* unchanged core code.

```
DeweyLib.sln
├── DeweyLib.Core/      class library — all domain code (M4–M11)
├── DeweyLib.Console/   console app   — exercises M1–M11
└── DeweyLib.Api/       ASP.NET Core minimal API (M12)
```

Requires the **.NET 10 SDK** (`dotnet --version` → 10.x).

## Run the console app (Milestones 1–11)

```bash
cd DeweyLib.Console
dotnet run
```

Menu options map to the milestones:

| Option | Milestone(s) | What it shows |
|--------|--------------|----------------|
| 1 List catalog | M4–M6 | Polymorphic `StatusLine()` over a generic repository |
| 2 Check out / 3 Return | M7, M9 | Service throws; UI catches; `🔔` event subscribers fire |
| 4 Place a hold | M9 | Reserve an item; you're notified (`📣`) when it's returned |
| 5 Reports | M8, M11 | Menu built by **reflection** — no hand-written switch |
| 6 Search | M8 | Conditional LINQ query |
| 7 Branch availability | M10 | Sequential vs concurrent timing + cancellation timeout |
| 8 Import feed | M10 | `await foreach` async stream — items arrive ~150ms apart |
| 9 Save & exit | M7 | JSON persistence |

To prove the M11 reflection claim: add a new method to
`DeweyLib.Core/Reports.cs` decorated with `[Report("My Report", Order = 6)]`,
rebuild, and it appears in the reports menu automatically — no other change.

## Run the Web API (Milestone 12)

```bash
cd DeweyLib.Api
dotnet run
```

Open the printed URL with `/swagger` appended (e.g.
`https://localhost:7080/swagger`) for the interactive UI. Endpoints:

| Method | Route | Notes |
|--------|-------|-------|
| GET  | `/api/items` | List the catalog |
| GET  | `/api/items/{barcode}` | One item, or 404 |
| POST | `/api/items/{barcode}/checkout` | Borrow; 404 if missing, **409** if already out |
| POST | `/api/items/{barcode}/return` | Return |
| GET  | `/api/reports` | All reflection-discovered reports as JSON |

Checking out the same barcode twice returns HTTP **409 Conflict** with a
`ProblemDetails` body whose `Detail` comes straight from the
`ItemUnavailableException` that `CheckoutService` threw — the same exception
that printed a console message in the console app. That's the whole payoff of
the layering: the business logic in `DeweyLib.Core` never changes between the
two front ends.

## What's where in DeweyLib.Core

| File | Milestone(s) |
|------|--------------|
| `LibraryItem.cs` | M4, M5 — abstract base + `Book`/`Dvd`/`Magazine`/`ReferenceBook` |
| `Repository.cs` | M6 — `IRepository<T>`, `InMemoryRepository<T>`, `Member` |
| `Exceptions.cs` | M7 — `ItemNotFoundException`, `ItemUnavailableException` |
| `CheckoutService.cs` | M7 + M9 — throws, and raises `ItemCirculated` |
| `Events.cs` | M9 — `CirculationEventArgs`, `HoldReadyEventArgs`, `HoldWatcher` |
| `LibraryStorage.cs` | M7 — `ItemData` + JSON save/load |
| `AsyncClients.cs` | M10 — `ExternalCatalogClient`, `MagazineFeed` async stream |
| `ReportAttribute.cs` | M11 — `[Report]` custom attribute |
| `Reports.cs` | M8 + M11 — string-returning, attribute-decorated reports |
| `ReportRunner.cs` | M11 — reflection discovery engine |

## Notes

- **Build status:** Core + Console build and run clean (0 warnings, 0 errors),
  verified end-to-end (events, holds, async streaming, reflection discovery).
  The API targets .NET 10 and pulls `Swashbuckle.AspNetCore` 10.2.2 from NuGet
  on first `dotnet run`/`restore`; if your environment ever objects to that
  version, any current `10.x` works.
- **Search** is the one report that isn't reflection-discovered: it takes
  parameters, and the discovery engine invokes parameterless methods, so the
  console calls it directly (menu option 6). All display reports are
  discovered.
- Console data is saved to `deweylib.json` next to the built executable;
  delete it to reset to seed data. The event file-logger writes `library.log`
  in the same folder.
- Currency in the overdue report renders using your machine's locale (`$` on a
  US system).
