namespace DeweyLib;

/// <summary>
/// Milestone 9 — carries information ABOUT a circulation event (a checkout
/// or a return). Inheriting from EventArgs is the long-standing .NET
/// convention for event payloads.
/// </summary>
public class CirculationEventArgs : EventArgs
{
    public LibraryItem Item { get; }
    public string Action { get; }      // "checkout" or "return"
    public DateTime Timestamp { get; }

    public CirculationEventArgs(LibraryItem item, string action)
    {
        Item = item;
        Action = action;
        Timestamp = DateTime.Now;
    }
}

/// <summary>
/// Milestone 9 — raised by HoldWatcher when an item someone reserved becomes
/// available again.
/// </summary>
public class HoldReadyEventArgs : EventArgs
{
    public string Patron { get; }
    public LibraryItem Item { get; }

    public HoldReadyEventArgs(string patron, LibraryItem item)
    {
        Patron = patron;
        Item = item;
    }
}

/// <summary>
/// Milestone 9 — a subscriber that itself owns an event. It listens to
/// CheckoutService.ItemCirculated; when a held item is returned, it raises
/// its OWN HoldReady event for the next patron in line. None of these three
/// pieces (service, watcher, console) reference each other's internals.
/// </summary>
public class HoldWatcher
{
    // barcode -> queue of patrons waiting for that specific item
    private readonly Dictionary<string, Queue<string>> _holds = new();

    public event EventHandler<HoldReadyEventArgs>? HoldReady;

    public void PlaceHold(string barcode, string patron)
    {
        if (!_holds.TryGetValue(barcode, out var queue))
            _holds[barcode] = queue = new Queue<string>();
        queue.Enqueue(patron);
    }

    /// <summary>
    /// Shaped exactly like EventHandler&lt;CirculationEventArgs&gt;, so it can
    /// be handed straight to CheckoutService.ItemCirculated as a handler.
    /// </summary>
    public void OnCirculation(object? sender, CirculationEventArgs e)
    {
        if (e.Action != "return") return;

        if (_holds.TryGetValue(e.Item.Barcode, out var queue) && queue.Count > 0)
        {
            string nextPatron = queue.Dequeue();
            HoldReady?.Invoke(this, new HoldReadyEventArgs(nextPatron, e.Item));
        }
    }
}
