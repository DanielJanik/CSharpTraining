namespace DeweyLib;

/// <summary>
/// Milestone 10 — stands in for a real, slow network call (contacting another
/// branch's system). Task.Delay simulates the latency WITHOUT blocking the
/// calling thread.
/// </summary>
public class ExternalCatalogClient
{
    public async Task<int> CheckBranchAvailabilityAsync(string branch, CancellationToken ct = default)
    {
        await Task.Delay(Random.Shared.Next(150, 400), ct);
        return Random.Shared.Next(0, 4);   // pretend: copies available at that branch
    }
}

/// <summary>
/// Milestone 10 — an async STREAM: results that arrive one at a time over a
/// period, consumed with `await foreach`, rather than all at once at the end.
/// </summary>
public static class MagazineFeed
{
    public static async IAsyncEnumerable<Magazine> ImportFeedAsync(int count)
    {
        for (int i = 1; i <= count; i++)
        {
            await Task.Delay(150);
            yield return new Magazine("Wired", $"M-F{i:000}", i);
        }
    }
}
