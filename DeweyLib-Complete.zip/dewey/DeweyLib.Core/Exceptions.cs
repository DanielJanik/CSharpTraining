namespace DeweyLib;

/// <summary>
/// Milestone 7 — raised when no item matches a given barcode. Carries the
/// offending barcode so the catching code can use it directly.
/// </summary>
public class ItemNotFoundException : Exception
{
    public string Barcode { get; }

    public ItemNotFoundException(string barcode)
        : base($"No item with barcode '{barcode}'.") => Barcode = barcode;
}

/// <summary>
/// Milestone 7 — raised when an item can't be borrowed/returned in its
/// current state. Carries the title and (when relevant) the due-back date.
/// </summary>
public class ItemUnavailableException : Exception
{
    public string Title { get; }
    public DateTime? DueBack { get; }

    public ItemUnavailableException(string title, DateTime? dueBack, string reason)
        : base($"'{title}' {reason}")
    {
        Title = title;
        DueBack = dueBack;
    }
}
