namespace DeweyLib;

/// <summary>
/// Milestone 11 — metadata attached to a report method so the discovery
/// engine can find it at runtime. AttributeUsage restricts it to methods.
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public class ReportAttribute : Attribute
{
    public string MenuTitle { get; }
    public int Order { get; set; } = 99;

    public ReportAttribute(string menuTitle) => MenuTitle = menuTitle;
}
