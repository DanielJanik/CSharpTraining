using System.Reflection;

namespace DeweyLib;

/// <summary>
/// Milestone 11 — scans a Reports instance at runtime, finds every method
/// marked [Report], and returns them (ordered) as ready-to-run callables.
/// No hand-written switch listing each report — adding a new [Report] method
/// makes it appear automatically.
/// </summary>
public static class ReportRunner
{
    public record DiscoveredReport(string MenuTitle, int Order, Func<string> Run);

    public static List<DiscoveredReport> Discover(object reportsInstance)
    {
        return reportsInstance.GetType()
            .GetMethods(BindingFlags.Public | BindingFlags.Instance)
            .Select(m => (Method: m, Attr: m.GetCustomAttribute<ReportAttribute>()))
            .Where(x => x.Attr is not null)
            .OrderBy(x => x.Attr!.Order)
            .Select(x => new DiscoveredReport(
                x.Attr!.MenuTitle,
                x.Attr!.Order,
                () => (string)x.Method.Invoke(reportsInstance, null)!))
            .ToList();
    }
}
