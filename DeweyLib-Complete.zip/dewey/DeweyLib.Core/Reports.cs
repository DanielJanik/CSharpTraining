namespace DeweyLib;

/// <summary>
/// Milestone 11 — the six Milestone 8 LINQ reports, now living on an instance
/// class. Each discoverable report is decorated with [Report] and RETURNS a
/// string instead of printing, so the same report can be shown on the console
/// (M11) or returned over HTTP (M12).
///
/// Search is intentionally NOT decorated: it takes parameters, so it can't be
/// invoked by the parameterless discovery engine. The console calls it
/// directly from its own menu entry instead.
/// </summary>
public class Reports
{
    private readonly IRepository<LibraryItem> _catalog;

    public Reports(IRepository<LibraryItem> catalog) => _catalog = catalog;

    [Report("Available items", Order = 1)]
    public string AvailableItems()
    {
        var items = _catalog.GetAll()
            .Where(i => !i.IsCheckedOut)
            .OrderBy(i => i.Title);
        return string.Join("\n", items.Select(i => $"  {i.Title}"));
    }

    [Report("Checked out — due soonest", Order = 2)]
    public string DueSoonest()
    {
        var items = _catalog.GetAll()
            .Where(i => i.IsCheckedOut)
            .OrderBy(i => i.DueDate)
            .Select(i => new { i.Title, Days = (i.DueDate!.Value - DateTime.Today).Days });
        return string.Join("\n", items.Select(x => $"  {x.Title}: {x.Days} days left"));
    }

    [Report("Catalog by type", Order = 3)]
    public string ByType()
    {
        var groups = _catalog.GetAll().GroupBy(i => i.GetType().Name);
        var lines = new List<string>();
        foreach (var group in groups)
        {
            lines.Add($"  {group.Key}: {group.Count()} items");
            foreach (var item in group)
                lines.Add($"    - {item.Title}");
        }
        return string.Join("\n", lines);
    }

    [Report("Overdue fees", Order = 4)]
    public string OverdueFees()
    {
        var overdue = _catalog.GetAll().Where(i => i.IsOverdue).ToList();
        var worst = overdue.MaxBy(i => i.DaysLate);
        return $"  {overdue.Count} overdue, {overdue.Sum(i => i.CurrentFee):C} owed\n"
             + $"  Worst: {worst?.Title} ({worst?.DaysLate} days)";
    }

    [Report("Full catalog", Order = 5)]
    public string FullCatalog()
        => string.Join("\n", _catalog.GetAll().Select(i => $"  {i.StatusLine()}"));

    /// <summary>
    /// Conditional search (Milestone 8). Not a discoverable [Report] because
    /// it needs arguments; invoked directly by the console.
    /// </summary>
    public string Search(string? titleFragment, string? typeFilter)
    {
        var query = _catalog.GetAll();

        if (!string.IsNullOrEmpty(titleFragment))
            query = query.Where(i => i.Title.Contains(titleFragment, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrEmpty(typeFilter))
            query = query.Where(i => i.GetType().Name.Equals(typeFilter, StringComparison.OrdinalIgnoreCase));

        var lines = query.Select(i => $"  {i.StatusLine()}").ToList();
        return lines.Count > 0 ? string.Join("\n", lines) : "  (nothing matched)";
    }
}
