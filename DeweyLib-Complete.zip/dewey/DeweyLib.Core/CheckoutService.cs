namespace DeweyLib;

/// <summary>
/// Milestone 7 — owns the circulation rules and THROWS on failure rather
/// than returning true/false; knows nothing about how errors are displayed.
/// Milestone 9 — additionally ANNOUNCES each checkout/return via an event,
/// without knowing who (if anyone) is listening.
///
/// The same service sits unchanged under the console app AND the Web API.
/// </summary>
public class CheckoutService
{
    private readonly IRepository<LibraryItem> _catalog;

    public CheckoutService(IRepository<LibraryItem> catalog) => _catalog = catalog;

    // M9 — outside code may only += / -= this; only this class can Invoke it.
    public event EventHandler<CirculationEventArgs>? ItemCirculated;

    public LibraryItem Borrow(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Checkout())
            throw new ItemUnavailableException(item.Title, item.DueDate, "is already checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "checkout"));
        return item;
    }

    public LibraryItem GiveBack(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Return())
            throw new ItemUnavailableException(item.Title, null, "was not checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "return"));
        return item;
    }
}
