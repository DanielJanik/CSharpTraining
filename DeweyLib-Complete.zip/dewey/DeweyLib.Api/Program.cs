using DeweyLib;
using DeweyLib.Api;

var builder = WebApplication.CreateBuilder(args);

// M12 / M6 — register one shared catalog, declared against the INTERFACE.
builder.Services.AddSingleton<IRepository<LibraryItem>>(_ =>
{
    var repo = new InMemoryRepository<LibraryItem>();
    repo.Add(new Book("Dune", "B-001", "Frank Herbert"));
    repo.Add(new Book("1984", "B-002", "George Orwell"));
    repo.Add(new Dvd("Inception", "D-101"));
    repo.Add(new Magazine("National Geographic", "M-201", 1));
    return repo;
});

// CheckoutService depends on IRepository<LibraryItem>, which DI supplies.
builder.Services.AddSingleton<CheckoutService>();

// M12 — global exception handling + Swagger.
builder.Services.AddExceptionHandler<LibraryExceptionHandler>();
builder.Services.AddProblemDetails();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseExceptionHandler();
app.UseSwagger();
app.UseSwaggerUI();

// ── Endpoints ────────────────────────────────────────────────────────────
var items = app.MapGroup("/api/items");

// GET /api/items — list everything (lightweight projection).
items.MapGet("/", (IRepository<LibraryItem> repo) =>
    Results.Ok(repo.GetAll().Select(i => new
    {
        i.Title,
        i.Barcode,
        Kind = i.GetType().Name,
        i.IsCheckedOut,
        i.DueDate
    })));

// GET /api/items/{barcode} — one item, or 404.
items.MapGet("/{barcode}", (string barcode, IRepository<LibraryItem> repo) =>
{
    var item = repo.Find(i => i.Barcode == barcode);
    return item is null
        ? Results.NotFound()
        : Results.Ok(new { item.Title, item.Barcode, Kind = item.GetType().Name, item.IsCheckedOut, item.DueDate });
});

// POST /api/items/{barcode}/checkout — Borrow throws; the handler maps it.
items.MapPost("/{barcode}/checkout", (string barcode, CheckoutService svc) =>
{
    var item = svc.Borrow(barcode); // throws → LibraryExceptionHandler → 404 / 409
    return Results.Ok(new { item.Title, item.DueDate });
});

// POST /api/items/{barcode}/return — GiveBack, same error mapping.
items.MapPost("/{barcode}/return", (string barcode, CheckoutService svc) =>
{
    var item = svc.GiveBack(barcode);
    return Results.Ok(new { item.Title, item.IsCheckedOut });
});

// GET /api/reports — every reflection-discovered report, rendered to text.
app.MapGet("/api/reports", (IRepository<LibraryItem> repo) =>
{
    var reports = new Reports(repo);
    var discovered = ReportRunner.Discover(reports);
    return Results.Ok(discovered.Select(r => new { r.MenuTitle, r.Order, Body = r.Run() }));
});

app.Run();
