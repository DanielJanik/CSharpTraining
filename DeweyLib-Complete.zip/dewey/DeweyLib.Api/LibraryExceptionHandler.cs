using DeweyLib;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

namespace DeweyLib.Api;

/// <summary>
/// Milestone 12 — catches the exact same exceptions CheckoutService throws
/// (Milestone 7) and turns them into proper HTTP responses, globally, instead
/// of a try/catch around every endpoint. CheckoutService is unchanged.
/// </summary>
public class LibraryExceptionHandler : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext ctx, Exception ex, CancellationToken ct)
    {
        var (status, title) = ex switch
        {
            ItemNotFoundException => (404, "Item Not Found"),
            ItemUnavailableException => (409, "Item Unavailable"),
            _ => (500, "Internal Server Error"),
        };

        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(new ProblemDetails
        {
            Status = status,
            Title = title,
            Detail = ex.Message
        }, ct);

        return true;
    }
}
