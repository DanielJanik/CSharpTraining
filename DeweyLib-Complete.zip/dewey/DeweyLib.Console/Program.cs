using System.Diagnostics;
using DeweyLib;

// ─────────────────────────────────────────────────────────────────────────
// DeweyLib console app — exercises Milestones 1 through 11.
//
//   M1–M3  banner, looping validated menu, methods
//   M4–M6  item hierarchy + generic repository
//   M7     CheckoutService throws; JSON persistence
//   M8     LINQ reports (now via M11)
//   M9     events: console logger, file logger, hold watcher
//   M10    async: concurrent branch checks, cancellation, async stream
//   M11    reflection-discovered reports menu
//
// The Web API (Milestone 12) is the separate DeweyLib.Api project; both it
// and this console app share the exact same DeweyLib.Core code.
// ─────────────────────────────────────────────────────────────────────────

// M6 — declare against the interface.
IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();

// M7 — load persisted data, falling back to seed data on missing/corrupt file.
string dataPath = Path.Combine(AppContext.BaseDirectory, "deweylib.json");
try
{
    var loaded = LibraryStorage.Load(dataPath);
    if (loaded.Count > 0)
        foreach (var item in loaded) catalog.Add(item);
    else
        SeedCatalog(catalog);
}
catch (Exception ex)
{
    Console.WriteLine($"⚠ Could not load saved data ({ex.Message}). Starting fresh.");
    SeedCatalog(catalog);
}

// M7/M9 — the service that owns the rules and announces what it does.
var checkoutService = new CheckoutService(catalog);

// M9 — three independent subscribers; CheckoutService knows about none of them.
checkoutService.ItemCirculated += (sender, e) =>
    Console.WriteLine($"🔔 {e.Item.Title} {e.Action} at {e.Timestamp:t}");

checkoutService.ItemCirculated += (sender, e) =>
    File.AppendAllText(Path.Combine(AppContext.BaseDirectory, "library.log"),
        $"{e.Timestamp:u} {e.Action} {e.Item.Barcode}\n");

var holdWatcher = new HoldWatcher();
checkoutService.ItemCirculated += holdWatcher.OnCirculation;
holdWatcher.HoldReady += (sender, e) =>
    Console.WriteLine($"📣 Notify {e.Patron}: '{e.Item.Title}' is now available!");

// M11 — discover the reports once via reflection.
var reports = new Reports(catalog);

PrintBanner();
Console.Write("What's your name? ");
string name = Console.ReadLine() ?? "";
Console.WriteLine($"Welcome, {name}!");

// M2 — the main loop. Top-level statements allow `await` directly.
while (true)
{
    switch (GetMenuChoice())
    {
        case 1: ListItems(catalog); break;
        case 2: DoCheckout(checkoutService, catalog, dataPath); break;
        case 3: DoReturn(checkoutService, catalog, dataPath); break;
        case 4: PlaceHold(holdWatcher); break;
        case 5: ReportsMenu(reports); break;
        case 6: SearchCatalog(reports); break;
        case 7: await CheckBranchesAsync(); break;
        case 8: await ImportFeedAsync(catalog, dataPath); break;
        case 9:
            Save(catalog, dataPath);
            Console.WriteLine("Goodbye!");
            return;
    }
}

// ─────────────────────────────────────────────────────────────────────────
// Methods (M3) — top-level local functions.
// ─────────────────────────────────────────────────────────────────────────

static void PrintBanner()
{
    Console.WriteLine("╔════════════════════════════╗");
    Console.WriteLine("║      📚 DEWEYLIB v1.0      ║");
    Console.WriteLine("╚════════════════════════════╝");
}

static int GetMenuChoice()
{
    while (true)
    {
        Console.WriteLine();
        Console.WriteLine("1. List catalog");
        Console.WriteLine("2. Check out an item");
        Console.WriteLine("3. Return an item");
        Console.WriteLine("4. Place a hold");
        Console.WriteLine("5. Reports");
        Console.WriteLine("6. Search catalog");
        Console.WriteLine("7. Check branch availability (async)");
        Console.WriteLine("8. Import magazine feed (async stream)");
        Console.WriteLine("9. Save & exit");
        Console.Write("Choose an option: ");

        string input = Console.ReadLine() ?? "";
        if (int.TryParse(input, out int choice) && choice >= 1 && choice <= 9)
            return choice;

        Console.WriteLine("✗ Invalid option — enter a number 1-9.");
    }
}

static void ListItems(IRepository<LibraryItem> catalog)
{
    Console.WriteLine();
    int i = 1;
    foreach (var item in catalog.GetAll())
        Console.WriteLine($"{i++}. {item.StatusLine()}");
}

// M7 — services throw, the UI catches and decides how to display.
static void DoCheckout(CheckoutService service, IRepository<LibraryItem> catalog, string dataPath)
{
    Console.Write("Barcode to check out: ");
    string barcode = Console.ReadLine() ?? "";
    try
    {
        var item = service.Borrow(barcode);
        Console.WriteLine($"✓ '{item.Title}' due back {item.DueDate:d}");
        Save(catalog, dataPath);
    }
    catch (ItemNotFoundException ex)
    {
        Console.WriteLine($"✗ {ex.Message} (you typed: {ex.Barcode})");
    }
    catch (ItemUnavailableException ex)
    {
        Console.WriteLine($"✗ {ex.Message}");
    }
}

static void DoReturn(CheckoutService service, IRepository<LibraryItem> catalog, string dataPath)
{
    Console.Write("Barcode to return: ");
    string barcode = Console.ReadLine() ?? "";
    try
    {
        var item = service.GiveBack(barcode);
        Console.WriteLine($"✓ '{item.Title}' returned.");
        Save(catalog, dataPath);
    }
    catch (ItemNotFoundException ex)
    {
        Console.WriteLine($"✗ {ex.Message} (you typed: {ex.Barcode})");
    }
    catch (ItemUnavailableException ex)
    {
        Console.WriteLine($"✗ {ex.Message}");
    }
}

// M9 — reserve an item; the hold fires automatically when it's returned.
static void PlaceHold(HoldWatcher holdWatcher)
{
    Console.Write("Barcode to hold: ");
    string barcode = Console.ReadLine() ?? "";
    Console.Write("Patron name: ");
    string patron = Console.ReadLine() ?? "";
    holdWatcher.PlaceHold(barcode, patron);
    Console.WriteLine($"✓ Hold placed for {patron} on {barcode}. " +
                      "You'll be notified when it's returned.");
}

// M11 — menu generated entirely from reflection-discovered reports.
static void ReportsMenu(Reports reports)
{
    var discovered = ReportRunner.Discover(reports);
    while (true)
    {
        Console.WriteLine("\n--- Reports ---");
        for (int i = 0; i < discovered.Count; i++)
            Console.WriteLine($"{i + 1}. {discovered[i].MenuTitle}");
        Console.WriteLine("0. Back");
        Console.Write("Pick a report: ");

        string input = Console.ReadLine() ?? "";
        if (!int.TryParse(input, out int pick))
        {
            Console.WriteLine("✗ Please enter a number.");
            continue;
        }
        if (pick == 0) return;
        if (pick >= 1 && pick <= discovered.Count)
        {
            Console.WriteLine();
            Console.WriteLine(discovered[pick - 1].Run());
        }
        else
        {
            Console.WriteLine("✗ No such report.");
        }
    }
}

// M8 — search is parameterized, so it's invoked directly (not via discovery).
static void SearchCatalog(Reports reports)
{
    Console.Write("Title contains (blank = any): ");
    string? title = Console.ReadLine();
    Console.Write("Type (Book/Dvd/Magazine, blank = any): ");
    string? type = Console.ReadLine();
    Console.WriteLine();
    Console.WriteLine(reports.Search(title, type));
}

// M10 — sequential vs concurrent, plus a cancellation demo.
static async Task CheckBranchesAsync()
{
    var client = new ExternalCatalogClient();
    string[] branches = { "Main", "East", "West", "South" };

    var sw = Stopwatch.StartNew();
    foreach (var branch in branches)
        await client.CheckBranchAvailabilityAsync(branch);
    Console.WriteLine($"Sequential: {sw.ElapsedMilliseconds}ms");

    sw.Restart();
    var tasks = branches.Select(b => client.CheckBranchAvailabilityAsync(b));
    var results = await Task.WhenAll(tasks);
    Console.WriteLine($"Concurrent: {sw.ElapsedMilliseconds}ms " +
                      $"(results: {string.Join(", ", results)})");

    // Cancellation: give a slow call a 1-second budget.
    using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(1));
    try
    {
        // Force a long wait to demonstrate the timeout firing.
        await Task.Delay(TimeSpan.FromSeconds(3), cts.Token);
        Console.WriteLine("SlowBranch responded in time.");
    }
    catch (OperationCanceledException)
    {
        Console.WriteLine("⏱ Timed out after 1 second.");
    }
}

// M10 — async stream: each magazine is processed the moment it arrives.
static async Task ImportFeedAsync(IRepository<LibraryItem> catalog, string dataPath)
{
    var sw = Stopwatch.StartNew();
    await foreach (var magazine in MagazineFeed.ImportFeedAsync(3))
    {
        catalog.Add(magazine);
        Console.WriteLine($"Imported at {sw.ElapsedMilliseconds,4}ms: " +
                          $"{magazine.Title} Issue #{magazine.IssueNumber}");
    }
    Save(catalog, dataPath);
}

static void Save(IRepository<LibraryItem> catalog, string dataPath)
{
    try
    {
        LibraryStorage.Save(catalog.GetAll(), dataPath);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"⚠ Could not save data ({ex.Message}).");
    }
}

static void SeedCatalog(IRepository<LibraryItem> catalog)
{
    catalog.Add(new Book("Dune", "B-001", "Frank Herbert"));
    catalog.Add(new Book("1984", "B-002", "George Orwell"));
    catalog.Add(new Book("The Hobbit", "B-003", "J.R.R. Tolkien"));
    catalog.Add(new Dvd("Inception", "D-101"));
    catalog.Add(new Dvd("Arrival", "D-102"));
    catalog.Add(new Magazine("National Geographic", "M-201", 1));

    // Make one item overdue so the fee report isn't empty on first launch.
    var hobbit = catalog.Find(i => i.Barcode == "B-003");
    hobbit?.Checkout();
    hobbit?.BackdateForDemo(10);

    var arrival = catalog.Find(i => i.Barcode == "D-102");
    arrival?.Checkout();
}
