// ============================================================
//  LIBRATRACK – BEGINNER SOLUTIONS (Milestones 1–4)
//  INSTRUCTOR REFERENCE — complete working implementation
// ============================================================
//  This is the final state after M4, including challenges C1–C3.
//  Earlier milestone states are preserved in comments where the
//  refactor replaced them, so you can demo the progression.
//
//  RUN: dotnet new console -n DeweyLibSolution
//       paste into Program.cs → dotnet run
// ============================================================

using System;
using System.Collections.Generic;
using System.Linq;

// ═══════════════════ M1+M2+M3+M4: Final program ═══════════════════

// M4 step 4.1 — the data is now a List<Book>, not parallel arrays
var books = new List<Book>
{
    new("Dune", "Frank Herbert"),
    new("1984", "George Orwell"),
    new("The Hobbit", "J.R.R. Tolkien"),
    new("Emma", "Jane Austen"),
    new("It", "Stephen King"),
};
books[1].Checkout();   // seed one as checked out for demos
books[4].Checkout();

PrintBanner();                                   // M1/M3
Console.Write("What's your name? ");
string userName = Console.ReadLine()?.Trim() ?? "Guest";
if (string.IsNullOrWhiteSpace(userName)) userName = "Guest";
Console.WriteLine($"Welcome, {userName}!\n");

// M2 — the main loop
while (true)
{
    int choice = GetMenuChoice();                // M3 — extracted method

    switch (choice)                              // M2 — switch dispatch
    {
        case 1:
            ListBooks(books);
            break;

        case 2:
            Console.Write("Book number to check out: ");
            if (int.TryParse(Console.ReadLine(), out int co))
            {
                if (TryCheckout(books, co, out string coMsg))
                    Console.WriteLine($"✓ {coMsg}");
                else
                    Console.WriteLine($"✗ {coMsg}");
            }
            else Console.WriteLine("✗ Please enter a number.");
            break;

        case 3:
            Console.Write("Book number to return: ");
            if (int.TryParse(Console.ReadLine(), out int rt))
            {
                if (TryReturn(books, rt, out string rtMsg))
                    Console.WriteLine($"✓ {rtMsg}");
                else
                    Console.WriteLine($"✗ {rtMsg}");
            }
            else Console.WriteLine("✗ Please enter a number.");
            break;

        case 4:                                  // M4 challenge C2 — add a book
            Console.Write("New book title: ");
            string newTitle = Console.ReadLine()?.Trim() ?? "";
            Console.Write("Author: ");
            string newAuthor = Console.ReadLine()?.Trim() ?? "";
            if (newTitle.Length > 0 && newAuthor.Length > 0)
            {
                books.Add(new Book(newTitle, newAuthor));
                Console.WriteLine($"✓ Added '{newTitle}'. It's book #{books.Count}.");
            }
            else Console.WriteLine("✗ Title and author are required.");
            break;

        case 5:                                  // M4 challenge C3 — search
            Console.Write("Search text: ");
            string term = Console.ReadLine()?.Trim() ?? "";
            var hits = books
                .Where(b => b.Title.Contains(term, StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (hits.Count == 0)
                Console.WriteLine($"No books matching '{term}'.");
            else
                foreach (var b in hits)
                    Console.WriteLine($"  {b.StatusLine()}");
            break;

        case 6:
            Console.WriteLine($"Goodbye, {userName}! 📚");
            return;
    }

    Console.WriteLine("\nPress Enter to continue...");
    Console.ReadLine();
    Console.Clear();
    PrintBanner();
}

// ═══════════════════ M3: Extracted methods ════════════════════════

static void PrintBanner()
{
    Console.WriteLine("╔══════════════════════════════╗");
    Console.WriteLine("║      📚 LIBRATRACK v0.4      ║");
    Console.WriteLine("╚══════════════════════════════╝");
}

// M3: loops INTERNALLY until valid — callers never see bad input.
// M2 challenge: also accepts "exit"/"quit" words.
static int GetMenuChoice()
{
    while (true)
    {
        Console.WriteLine("\n1. List books");
        Console.WriteLine("2. Check out a book");
        Console.WriteLine("3. Return a book");
        Console.WriteLine("4. Add a book");
        Console.WriteLine("5. Search");
        Console.WriteLine("6. Exit");
        Console.Write("Choose an option: ");

        string input = Console.ReadLine()?.Trim().ToLower() ?? "";

        if (input is "exit" or "quit") return 6;          // word shortcut

        if (int.TryParse(input, out int choice) && choice is >= 1 and <= 6)
            return choice;

        Console.WriteLine("✗ Invalid option — enter a number 1-6.");
    }
}

// M4 step 4.2 — takes List<Book>, lets each Book describe itself
static void ListBooks(List<Book> books)
{
    Console.WriteLine();
    for (int i = 0; i < books.Count; i++)
        Console.WriteLine($"{i + 1,3}. {books[i].StatusLine()}");
}

// M4 step 4.3 — the menu layer only validates the INDEX;
// availability rules live inside Book (encapsulation!)
static bool TryCheckout(List<Book> books, int bookNumber, out string message)
{
    if (bookNumber < 1 || bookNumber > books.Count)
    {
        message = $"There is no book #{bookNumber}. Pick 1-{books.Count}.";
        return false;
    }

    var book = books[bookNumber - 1];
    if (book.Checkout())
    {
        message = $"'{book.Title}' checked out. Enjoy!";
        return true;
    }
    message = $"'{book.Title}' is already checked out.";
    return false;
}

static bool TryReturn(List<Book> books, int bookNumber, out string message)
{
    if (bookNumber < 1 || bookNumber > books.Count)
    {
        message = $"There is no book #{bookNumber}. Pick 1-{books.Count}.";
        return false;
    }

    var book = books[bookNumber - 1];
    if (book.Return())
    {
        message = $"'{book.Title}' returned. Thanks!";
        return true;
    }
    message = $"'{book.Title}' wasn't checked out.";
    return false;
}

// ═══════════════════ M4: The Book class ═══════════════════════════
//
// TEACHING NOTES:
// • Title/Author are get-only → set once in the constructor, then
//   immutable. Ask students: why is that a good default?
// • IsCheckedOut has a PRIVATE set → only Book's own methods can
//   change it. The menu cannot "cheat."
// • Checkout/Return return bool instead of throwing — appropriate
//   at this level; M7 (intermediate) upgrades this to exceptions
//   and discusses when each style fits.

public class Book
{
    public string Title  { get; }
    public string Author { get; }
    public bool   IsCheckedOut  { get; private set; }
    public int    TimesBorrowed { get; private set; }   // challenge C1

    public Book(string title, string author)
    {
        Title  = title;
        Author = author;
    }

    public bool Checkout()
    {
        if (IsCheckedOut) return false;     // rule enforced HERE, not in the menu
        IsCheckedOut = true;
        TimesBorrowed++;
        return true;
    }

    public bool Return()
    {
        if (!IsCheckedOut) return false;
        IsCheckedOut = false;
        return true;
    }

    public string StatusLine()
        => $"{Title,-15} by {Author,-18} " +
           $"[{(IsCheckedOut ? "CHECKED OUT" : "Available")}]" +
           (TimesBorrowed > 0 ? $"  (borrowed {TimesBorrowed}x)" : "");
}

/* ═══════════════ HISTORICAL: what M1 looked like ═══════════════
   Useful to show the journey on screen:

   Console.WriteLine("╔══════════════════════════════╗");
   Console.WriteLine("║      📚 LIBRATRACK v0.1      ║");
   Console.WriteLine("╚══════════════════════════════╝");
   Console.Write("What's your name? ");
   string? name = Console.ReadLine();
   Console.WriteLine($"Welcome, {name ?? "Guest"}!");
   Console.WriteLine("1. List books");
   Console.WriteLine("2. Check out a book");
   Console.WriteLine("3. Return a book");
   Console.WriteLine("4. Exit");
   Console.Write("Choose an option: ");
   string? choice = Console.ReadLine();
   Console.WriteLine($"You chose option {choice}");

   ═══════ HISTORICAL: M3's parallel arrays (pre-class) ═══════
   string[] titles     = { "Dune", "1984", "The Hobbit", "Emma", "It" };
   bool[]   checkedOut = { false, true, false, false, true };
   // The bug-magnet: nothing keeps these two arrays in sync.
   // That pain is the MOTIVATION for the Book class in M4.
================================================================ */
