// ============================================================
//  LIBRATRACK PROJECT – INTERMEDIATE LABS (Milestones 5–8)
//  Continue building your Library Management System
// ============================================================
//  PREREQUISITE: Completed Beginner Milestone 4 (Book class +
//  List<Book>), OR start from Solutions_Beginner.cs.
//
//    M5: Inheritance — Books, DVDs, Magazines    (OOP hierarchy)
//    M6: Generic Repository & Interfaces         (generics)
//    M7: Exceptions & JSON File Persistence      (error handling, I/O)
//    M8: LINQ Reports Dashboard                  (LINQ)
// ============================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 5: Media Hierarchy with Inheritance             ║
// ║  Skills: abstract classes, virtual/override, polymorphism  ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: The library now lends DVDs and Magazines too. Each has
//       different loan periods and late fees, but they share a
//       core: title, barcode, checked-out state.
//
// STEP 5.1 — Create the abstract base class:
//
//   public abstract class LibraryItem
//   {
//       public string Title   { get; }
//       public string Barcode { get; }
//       public bool IsCheckedOut { get; private set; }
//       public DateTime? DueDate { get; private set; }
//
//       protected LibraryItem(string title, string barcode) { ... }
//
//       public abstract int LoanDays { get; }          // subclasses MUST define
//       public virtual decimal DailyLateFee => 0.25m;  // subclasses MAY override
//
//       public bool Checkout()
//       {
//           if (IsCheckedOut) return false;
//           IsCheckedOut = true;
//           DueDate = DateTime.Today.AddDays(LoanDays);  // ← polymorphism in action!
//           return true;
//       }
//
//       public bool Return() { ... reset both properties ... }
//
//       public virtual string StatusLine() { ... include due date if out ... }
//   }
//
// STEP 5.2 — Create three subclasses:
//
//   Book     : LoanDays = 21, extra property: Author, Pages
//   Dvd      : LoanDays = 7,  DailyLateFee = 1.00m, extra: RuntimeMinutes
//   Magazine : LoanDays = 3,  extra: IssueNumber
//              Override StatusLine() to show "Issue #12"
//
// STEP 5.3 — Change your collection to List<LibraryItem> and seed
//   it with at least 2 of each type. Your existing menu should
//   work UNCHANGED for all three types — that's polymorphism.
//
// STEP 5.4 — Add a menu option "Show overdue items" that prints
//   any item where DueDate < DateTime.Today, including the fee:
//     fee = daysLate * item.DailyLateFee
//   (For testing, temporarily seed one item as checked out with a
//   past due date, or add a debug option that backdates one.)
//
// 🌶 CHALLENGE: Add a `ReferenceBook : Book` whose Checkout()
//   always fails ("Reference materials cannot leave the library").
//   Hint: you'll need to make Checkout virtual in the base class.
//
// ✅ CHECKPOINT M5: Checking out a DVD shows a due date 7 days out;
//    a Book shows 21. One foreach loop lists everything correctly.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 6: Generic Repository & Interfaces              ║
// ║  Skills: interfaces, generics, constraints                 ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Library code is mixing UI (menus) with data storage.
//       Extract storage behind an interface so we can later swap
//       in a file-backed or database-backed version.
//
// STEP 6.1 — Define the contract:
//
//   public interface IRepository<T> where T : class
//   {
//       void Add(T item);
//       bool Remove(T item);
//       T?   Find(Func<T, bool> predicate);
//       IEnumerable<T> GetAll();
//       IEnumerable<T> Where(Func<T, bool> predicate);
//       int  Count { get; }
//   }
//
// STEP 6.2 — Implement it:
//
//   public class InMemoryRepository<T> : IRepository<T> where T : class
//   { ... backed by a private List<T> ... }
//
// STEP 6.3 — Add a Member record and a second repository:
//
//   public record Member(int Id, string Name, string Email);
//
//   In your program:
//     IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();
//     IRepository<Member>      members = new InMemoryRepository<Member>();
//
//   Note: declare variables as the INTERFACE type, not the class —
//   ask yourself (or your instructor) why this matters.
//
// STEP 6.4 — Update every menu action to go through the repository
//   (catalog.Find(i => i.Barcode == input), etc.)
//
// 🌶 CHALLENGE: Add `bool Update(T item)` — tricky question: does
//   an in-memory repo even need it? Discuss reference semantics.
//
// ✅ CHECKPOINT M6: Program behavior is identical to M5, but all
//    data access flows through IRepository<T>. Adding a Member
//    repo took ~3 lines because the repository is generic.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 7: Exceptions & JSON Persistence                ║
// ║  Skills: custom exceptions, try/catch, File I/O, JSON      ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: (a) Replace bool-return error handling with rich
//       exceptions where appropriate. (b) Save/load the catalog
//       so data survives restarts.
//
// PART A — Custom exceptions:
//
//   public class ItemNotFoundException : Exception
//   {
//       public string Barcode { get; }
//       public ItemNotFoundException(string barcode)
//           : base($"No item with barcode '{barcode}'.") => Barcode = barcode;
//   }
//
//   public class ItemUnavailableException : Exception
//   {
//       public string Title { get; }
//       public DateTime? DueBack { get; }
//       ... message like "'Dune' is checked out until 6/25/2026."
//   }
//
//   7.1  Create a CheckoutService class:
//          public class CheckoutService
//          {
//              private readonly IRepository<LibraryItem> _catalog;
//              public CheckoutService(IRepository<LibraryItem> catalog) ...
//
//              public LibraryItem Borrow(string barcode)
//                  → throws ItemNotFoundException / ItemUnavailableException
//              public LibraryItem GiveBack(string barcode)
//          }
//   7.2  In the MENU layer, wrap calls in try/catch and print
//        friendly messages from the exception's properties.
//        DESIGN DISCUSSION: services throw, UI catches. Why?
//
// PART B — JSON persistence:
//
//   7.3  Create a SaveData record for serialization:
//          public record BookData(string Kind, string Title, string Barcode,
//                                 bool IsCheckedOut, DateTime? DueDate, ...);
//        (Polymorphic types need a "Kind" discriminator — or research
//        System.Text.Json's [JsonDerivedType] attribute. Either works.)
//
//   7.4  Add LibraryStorage class:
//          public static class LibraryStorage
//          {
//              public static void Save(IEnumerable<LibraryItem> items, string path) { ... }
//              public static List<LibraryItem> Load(string path) { ... }
//          }
//        Use JsonSerializer with WriteIndented = true.
//
//   7.5  Load at startup (if the file exists), save on exit AND
//        after every successful checkout/return.
//        Wrap Load in try/catch — a corrupted file should warn and
//        start fresh, never crash.
//
// 🌶 CHALLENGE: Write an activity log (append-only library.log)
//   recording every checkout/return with a timestamp.
//
// ✅ CHECKPOINT M7: Check out a book, exit, re-run → the book is
//    still checked out. Entering a bogus barcode prints a friendly
//    message that includes the barcode. Delete/corrupt the JSON
//    file → program warns and starts with seed data.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 8: LINQ Reports Dashboard                       ║
// ║  Skills: Where/Select/OrderBy/GroupBy/aggregates           ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Add a "Reports" menu with 6 LINQ-powered reports.
//       RULE: each report must be ONE LINQ statement (chained
//       calls are fine; foreach for printing is fine).
//
//   R1. Available items, alphabetical by title
//
//   R2. Checked-out items sorted by due date (soonest first),
//       showing days remaining:  (item.DueDate - DateTime.Today).Days
//
//   R3. Catalog breakdown by type:
//         Book: 5 | Dvd: 3 | Magazine: 4
//       Hint: GroupBy(i => i.GetType().Name)
//
//   R4. Overdue fee summary:
//         total items overdue, total fees owed (Sum), worst
//         offender (MaxBy days late)
//
//   R5. "Shelf report" — items grouped by first letter of Title:
//         D: Dune, Dracula
//         E: Emma
//       Hint: GroupBy(i => char.ToUpper(i.Title[0])), OrderBy key
//
//   R6. Search with multiple filters — prompt the user for an
//       optional title fragment AND an optional type name; build
//       the query conditionally:
//         var q = catalog.GetAll();
//         if (!string.IsNullOrEmpty(frag)) q = q.Where(...);
//         if (!string.IsNullOrEmpty(type)) q = q.Where(...);
//
// 🌶 CHALLENGES:
//   C1: R2 but using QUERY syntax (from..where..orderby..select)
//   C2: Most-borrowed report using the TimesBorrowed counter
//       from beginner challenge C1 (add it now if you skipped it)
//   C3: Export any report to CSV using Select + string.Join +
//       File.WriteAllLines
//
// ✅ CHECKPOINT M8 (END OF INTERMEDIATE TRACK):
//    All six reports run against your live data and update
//    immediately after a checkout. You used GroupBy at least
//    twice and can explain deferred execution to a partner.
//
//  🎉 The Advanced labs add events, async, and a Web API on top
//     of THIS code. Keep it working!

Console.WriteLine("DeweyLib Intermediate Labs — follow milestones M5–M8 above.");
Console.WriteLine("Prerequisite: your completed Beginner M4 code (or the provided solution).");
