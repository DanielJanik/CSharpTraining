// ============================================================
//  C# Training – BEGINNER DEMOS (Instructor File)
//  Cherry-pickable modules: run any subset by commenting in/out
// ============================================================
//  MODULES:
//    B1 – Console I/O & Variables
//    B2 – Strings & Formatting
//    B3 – Control Flow (if/switch/loops)
//    B4 – Methods & Parameters
//    B5 – Arrays & Lists
//    B6 – Your First Class
//    B7 – Debugging Walkthrough (intentional bugs to fix live)
// ------------------------------------------------------------
//  RUN: dotnet new console -n BeginnerDemos
//       copy this into Program.cs, then: dotnet run
// ============================================================

using System;
using System.Collections.Generic;
using System.Linq;

Console.WriteLine("=== BEGINNER DEMOS ===\n");

// ── Cherry-pick: comment out modules you don't need ──────────────
BeginnerDemos.B1_ConsoleIOAndVariables();
BeginnerDemos.B2_StringsAndFormatting();
BeginnerDemos.B3_ControlFlow();
BeginnerDemos.B4_MethodsAndParameters();
BeginnerDemos.B5_ArraysAndLists();
BeginnerDemos.B6_FirstClass();
// BeginnerDemos.B7_DebuggingWalkthrough();  // interactive — enable in class

static class BeginnerDemos
{
    // ══════════════════════════════════════════════════════════════
    // B1 – Console I/O & Variables
    // Teaching points: declaring variables, type inference, reading
    // input, converting strings to numbers safely
    // ══════════════════════════════════════════════════════════════
    public static void B1_ConsoleIOAndVariables()
    {
        Console.WriteLine("── B1: Console I/O & Variables ─────────────────");

        // Explicit typing vs type inference
        int    bookCount = 42;          // explicit
        var    libraryName = "City Library";  // inferred as string
        double lateFeePerDay = 0.25;
        bool   isOpen = true;
        char   section = 'F';           // F = Fiction

        Console.WriteLine($"Welcome to {libraryName}!");
        Console.WriteLine($"Books available: {bookCount}");
        Console.WriteLine($"Late fee: {lateFeePerDay:C}/day");  // :C = currency format
        Console.WriteLine($"Open now: {isOpen} | Section: {section}");

        // INSTRUCTOR: Uncomment for live input demo
        // Console.Write("Enter your name: ");
        // string? userName = Console.ReadLine();
        // Console.WriteLine($"Hello, {userName ?? "Guest"}!");

        // Safe number parsing — ALWAYS prefer TryParse over Parse
        string input = "17";   // pretend this came from Console.ReadLine()
        if (int.TryParse(input, out int parsedAge))
            Console.WriteLine($"Parsed age: {parsedAge}");
        else
            Console.WriteLine("That wasn't a number!");

        // What happens with bad input? Parse throws, TryParse doesn't:
        string bad = "seventeen";
        bool ok = int.TryParse(bad, out int result);
        Console.WriteLine($"TryParse(\"{bad}\") → success={ok}, value={result}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // B2 – Strings & Formatting
    // Teaching points: immutability, interpolation, common methods,
    // StringBuilder for loops
    // ══════════════════════════════════════════════════════════════
    public static void B2_StringsAndFormatting()
    {
        Console.WriteLine("── B2: Strings & Formatting ────────────────────");

        string title = "  The Great Gatsby  ";

        // Strings are IMMUTABLE — methods return NEW strings
        Console.WriteLine($"Original:  '{title}'");
        Console.WriteLine($"Trimmed:   '{title.Trim()}'");
        Console.WriteLine($"Upper:     '{title.Trim().ToUpper()}'");
        Console.WriteLine($"Length:    {title.Trim().Length}");
        Console.WriteLine($"Contains 'Great'? {title.Contains("Great")}");
        Console.WriteLine($"Replace:   '{title.Trim().Replace("Great", "Grand")}'");

        // Splitting and joining
        string csvAuthors = "Fitzgerald,Hemingway,Steinbeck";
        string[] authors = csvAuthors.Split(',');
        Console.WriteLine($"Authors ({authors.Length}): {string.Join(" | ", authors)}");

        // Format specifiers
        double price = 1234.5678;
        Console.WriteLine($"Currency: {price:C}");      // $1,234.57
        Console.WriteLine($"2 decimals: {price:F2}");   // 1234.57
        Console.WriteLine($"Number: {price:N1}");       // 1,234.6
        Console.WriteLine($"Percent: {0.847:P1}");      // 84.7%
        Console.WriteLine($"Padded: |{42,8}|{42,-8}|"); // right/left align

        // StringBuilder — use when concatenating in loops
        var sb = new System.Text.StringBuilder();
        for (int i = 1; i <= 5; i++)
            sb.Append($"Book{i} ");
        Console.WriteLine($"Built: {sb.ToString().Trim()}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // B3 – Control Flow
    // Teaching points: if/else chains, switch statement AND
    // expression, all four loop types, break/continue
    // ══════════════════════════════════════════════════════════════
    public static void B3_ControlFlow()
    {
        Console.WriteLine("── B3: Control Flow ─────────────────────────────");

        // if / else if / else
        int daysOverdue = 12;
        if (daysOverdue == 0)
            Console.WriteLine("Book returned on time!");
        else if (daysOverdue <= 7)
            Console.WriteLine($"Slightly late: {daysOverdue} days");
        else
            Console.WriteLine($"Very overdue: {daysOverdue} days — fee applies");

        // Classic switch statement
        char genre = 'M';
        switch (genre)
        {
            case 'F': Console.WriteLine("Genre: Fiction");  break;
            case 'M': Console.WriteLine("Genre: Mystery");  break;
            case 'S': Console.WriteLine("Genre: Sci-Fi");   break;
            default:  Console.WriteLine("Genre: Unknown");  break;
        }

        // Modern switch EXPRESSION — show students both!
        string genreName = genre switch
        {
            'F' => "Fiction",
            'M' => "Mystery",
            'S' => "Sci-Fi",
            _   => "Unknown"
        };
        Console.WriteLine($"Switch expression result: {genreName}");

        // for — when you know the count
        Console.Write("for:      ");
        for (int i = 1; i <= 5; i++) Console.Write($"{i} ");
        Console.WriteLine();

        // while — when condition-driven
        Console.Write("while:    ");
        int copies = 16;
        while (copies > 1) { copies /= 2; Console.Write($"{copies} "); }
        Console.WriteLine();

        // do-while — runs at least once
        Console.Write("do-while: ");
        int attempts = 0;
        do { attempts++; Console.Write($"try{attempts} "); } while (attempts < 3);
        Console.WriteLine();

        // foreach — for collections (most common in practice)
        Console.Write("foreach:  ");
        foreach (var b in new[] { "1984", "Dune", "It" }) Console.Write($"{b} ");
        Console.WriteLine();

        // break and continue
        Console.Write("skip evens, stop at 7: ");
        for (int i = 1; i <= 10; i++)
        {
            if (i % 2 == 0) continue;   // skip even numbers
            if (i > 7) break;           // stop entirely after 7
            Console.Write($"{i} ");
        }
        Console.WriteLine("\n");
    }

    // ══════════════════════════════════════════════════════════════
    // B4 – Methods & Parameters
    // Teaching points: return types, parameters, optional params,
    // out params, expression-bodied methods
    // ══════════════════════════════════════════════════════════════
    public static void B4_MethodsAndParameters()
    {
        Console.WriteLine("── B4: Methods & Parameters ─────────────────────");

        // A simple method with return value
        static decimal CalculateLateFee(int daysLate, decimal dailyRate = 0.25m)
        {
            if (daysLate <= 0) return 0m;
            decimal fee = daysLate * dailyRate;
            return Math.Min(fee, 10.00m);  // cap at $10
        }

        Console.WriteLine($"3 days late:  {CalculateLateFee(3):C}");
        Console.WriteLine($"60 days late: {CalculateLateFee(60):C} (capped)");
        Console.WriteLine($"Custom rate:  {CalculateLateFee(4, 0.50m):C}");
        Console.WriteLine($"Named arg:    {CalculateLateFee(daysLate: 2, dailyRate: 1.00m):C}");

        // void method — does something, returns nothing
        static void PrintReceipt(string title, decimal fee)
            => Console.WriteLine($"  RECEIPT: '{title}' — fee {fee:C}");

        PrintReceipt("Dune", CalculateLateFee(5));

        // out parameter — return more than one thing
        static bool TryCheckout(string title, int available, out string message)
        {
            if (available > 0) { message = $"'{title}' checked out!"; return true; }
            message = $"'{title}' is unavailable.";
            return false;
        }

        if (TryCheckout("1984", 3, out string msg1)) Console.WriteLine($"  ✓ {msg1}");
        if (!TryCheckout("Dune", 0, out string msg2)) Console.WriteLine($"  ✗ {msg2}");

        // params — variable argument count
        static int TotalPages(params int[] pages) => pages.Sum();
        Console.WriteLine($"Total pages: {TotalPages(180, 250, 320)}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // B5 – Arrays & Lists
    // Teaching points: fixed arrays vs dynamic lists, indexing,
    // common List methods, dictionaries as a preview
    // ══════════════════════════════════════════════════════════════
    public static void B5_ArraysAndLists()
    {
        Console.WriteLine("── B5: Arrays & Lists ───────────────────────────");

        // Array — fixed size
        string[] genres = { "Fiction", "Mystery", "Sci-Fi", "Biography" };
        Console.WriteLine($"First: {genres[0]}, Last: {genres[^1]}");  // ^1 = from end
        Console.WriteLine($"Count: {genres.Length}");

        // List<T> — grows dynamically (use this 95% of the time)
        var checkedOut = new List<string> { "Dune", "1984" };
        checkedOut.Add("Brave New World");
        checkedOut.Insert(0, "Fahrenheit 451");   // insert at front
        checkedOut.Remove("1984");

        Console.WriteLine($"Checked out ({checkedOut.Count}):");
        foreach (var book in checkedOut)
            Console.WriteLine($"  • {book}");

        Console.WriteLine($"Contains 'Dune'? {checkedOut.Contains("Dune")}");
        Console.WriteLine($"Index of 'Dune': {checkedOut.IndexOf("Dune")}");

        checkedOut.Sort();
        Console.WriteLine($"Sorted: {string.Join(", ", checkedOut)}");

        // Dictionary preview — key/value lookup
        var stock = new Dictionary<string, int>
        {
            ["Dune"] = 3,
            ["1984"] = 0,
            ["It"]   = 7,
        };
        Console.WriteLine($"Copies of Dune: {stock["Dune"]}");
        Console.WriteLine($"Have 'It'? {stock.ContainsKey("It")}");
        stock["Dune"]--;   // checkout decrements
        Console.WriteLine($"After checkout: {stock["Dune"]}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // B6 – Your First Class
    // Teaching points: fields vs properties, constructor, methods,
    // creating objects, why encapsulation matters
    // ══════════════════════════════════════════════════════════════
    public static void B6_FirstClass()
    {
        Console.WriteLine("── B6: Your First Class ─────────────────────────");

        var book = new Book("Dune", "Frank Herbert", 1965);
        book.Checkout();
        Console.WriteLine(book.GetSummary());

        var book2 = new Book("1984", "George Orwell", 1949);
        Console.WriteLine(book2.GetSummary());

        // Show why encapsulation matters — this would be a compile error:
        // book.IsCheckedOut = true;   // ✗ setter is private!
        // Students must use Checkout() which enforces the rules.

        book.Return();
        Console.WriteLine($"After return: {book.GetSummary()}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // B7 – Debugging Walkthrough (LIVE EXERCISE)
    // This method contains 3 INTENTIONAL BUGS. Walk through with
    // the debugger: set breakpoints, inspect locals, fix together.
    // ══════════════════════════════════════════════════════════════
    public static void B7_DebuggingWalkthrough()
    {
        Console.WriteLine("── B7: Debugging (3 intentional bugs!) ─────────");

        // BUG 1: off-by-one — loop misses the last element
        int[] ratings = { 4, 5, 3, 5, 4 };
        int sum = 0;
        for (int i = 0; i < ratings.Length - 1; i++)  // BUG: should be < Length
            sum += ratings[i];
        Console.WriteLine($"Average rating: {(double)sum / ratings.Length:F2} (should be 4.20)");

        // BUG 2: integer division — truncates the decimal
        int booksRead = 7, weeks = 2;
        double perWeek = booksRead / weeks;            // BUG: int/int = int (3, not 3.5)
        Console.WriteLine($"Books per week: {perWeek} (should be 3.5)");

        // BUG 3: == vs = ... wait, C# catches that one at compile time!
        // Real bug 3: string comparison ignoring case
        string answer = "YES";
        if (answer == "yes")                            // BUG: case-sensitive
            Console.WriteLine("User agreed");
        else
            Console.WriteLine("Hmm, user said: " + answer + " (should match!)");
        // FIX: answer.Equals("yes", StringComparison.OrdinalIgnoreCase)

        Console.WriteLine();
    }
}

// ─── First class for B6 ────────────────────────────────────────────
public class Book
{
    // Properties — the public face of the class
    public string Title  { get; }                    // read-only after construction
    public string Author { get; }
    public int    Year   { get; }
    public bool   IsCheckedOut { get; private set; } // only THIS class can change it

    // Constructor — runs when you write: new Book(...)
    public Book(string title, string author, int year)
    {
        Title  = title;
        Author = author;
        Year   = year;
    }

    // Methods — behavior that enforces business rules
    public void Checkout()
    {
        if (IsCheckedOut)
        {
            Console.WriteLine($"  ⚠ '{Title}' is already checked out!");
            return;
        }
        IsCheckedOut = true;
        Console.WriteLine($"  ✓ '{Title}' checked out.");
    }

    public void Return() => IsCheckedOut = false;

    public string GetSummary()
        => $"'{Title}' by {Author} ({Year}) — {(IsCheckedOut ? "OUT" : "Available")}";
}
