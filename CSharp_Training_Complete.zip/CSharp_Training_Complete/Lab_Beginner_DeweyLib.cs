// ============================================================
//  LIBRATRACK PROJECT – BEGINNER LABS (Milestones 1–4)
//  Build a Library Management System from scratch!
// ============================================================
//  THE BIG PICTURE:
//  Over these labs you will build "DeweyLib" — a console
//  library system. Each milestone adds a layer:
//
//    M1: Console menu & user input          (I/O, variables)
//    M2: Input validation & flow control    (if/switch/loops)
//    M3: Refactor into methods              (methods, params)
//    M4: Your first Book class              (classes, objects)
//
//  Later (Intermediate labs) you'll add inheritance, a generic
//  repository, file persistence, and LINQ reports. Then
//  (Advanced labs) events, async, and a Web API.
// ------------------------------------------------------------
//  SETUP:  dotnet new console -n DeweyLib
//          Work in Program.cs. Complete milestones in order.
//          ✅ CHECKPOINT comments tell you what must work
//             before moving to the next milestone.
// ============================================================

using System;
using System.Collections.Generic;

// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 1: Console Menu & User Input                    ║
// ║  Skills: Console I/O, variables, string interpolation      ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: When the program runs, it should display:
//
//    ╔══════════════════════════════╗
//    ║      📚 LIBRATRACK v0.1      ║
//    ╚══════════════════════════════╝
//    Welcome, <name>!
//
//    1. List books
//    2. Check out a book
//    3. Return a book
//    4. Exit
//    Choose an option:
//
// STEPS:
//   1.1  Print the banner (use Console.WriteLine)
//   1.2  Ask for the user's name with Console.Write + Console.ReadLine
//   1.3  Greet them using string interpolation: $"Welcome, {name}!"
//   1.4  Print the 4 menu options
//   1.5  Read their choice into a string variable
//   1.6  Print back: $"You chose option {choice}"
//
// 💡 HINTS:
//   - Console.Write() doesn't add a newline; WriteLine() does
//   - Console.ReadLine() returns string? — handle null with ??
//
// ✅ CHECKPOINT M1: Program greets you by name and echoes your
//    menu choice. No validation needed yet — that's M2!

// TODO: Write your Milestone 1 code here
Console.WriteLine("TODO: Milestone 1 — build the menu");



// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 2: Validation & the Main Loop                   ║
// ║  Skills: if/else, switch, while loops, int.TryParse        ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Make the menu run in a LOOP until the user picks Exit,
//       and reject invalid input gracefully.
//
// STEPS:
//   2.1  Wrap your menu in a while(true) loop
//   2.2  Use int.TryParse to convert the choice safely
//        if (!int.TryParse(input, out int choice)) → print error, continue
//   2.3  Use a switch statement on the choice:
//          case 1: Console.WriteLine("(listing books...)"); break;
//          case 2: ... case 3: ...
//          case 4: print goodbye, then `return;` to exit
//          default: print "Invalid option, try 1-4"
//   2.4  After each action, ask "Press Enter to continue" and
//        Console.ReadLine() so the screen doesn't fly by
//
// 🌶 CHALLENGE: Also accept the words "exit" or "quit" (case-
//    insensitive) anywhere. Hint: input.Trim().ToLower()
//
// ✅ CHECKPOINT M2: Menu loops forever, bad input shows an error
//    instead of crashing, option 4 cleanly exits.

// TODO: Upgrade your M1 code into the M2 loop



// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 3: Refactor into Methods                        ║
// ║  Skills: methods, parameters, return values, out params    ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Your Main logic is getting long. Extract methods so the
//       main loop reads like a table of contents.
//
// CREATE THESE METHODS (signatures given — you write bodies):
//
//   static void PrintBanner()
//       → prints the DeweyLib header box
//
//   static int GetMenuChoice()
//       → prints menu, reads input, loops INTERNALLY until the
//         user enters a valid number 1-4, then returns it
//
//   static void ListBooks(string[] titles, bool[] checkedOut)
//       → prints each book with its status:
//           1. Dune              [Available]
//           2. 1984              [CHECKED OUT]
//         Hint: for loop with index; use {title,-20} padding
//
//   static bool TryCheckout(string[] titles, bool[] checkedOut,
//                           int bookNumber, out string message)
//       → if the number is valid AND the book is available:
//           mark it checked out, message = success text, return true
//         otherwise message = explanation, return false
//
//   static bool TryReturn(...)   → mirror image of TryCheckout
//
// STARTING DATA (paste near the top of your program):
//   string[] titles     = { "Dune", "1984", "The Hobbit", "Emma", "It" };
//   bool[]   checkedOut = { false, true, false, false, true };
//
// ✅ CHECKPOINT M3: Main loop is ~15 lines. Checking out book 2
//    fails with a clear message ("already checked out"); checking
//    out book 1 succeeds and List shows the change.

// TODO: Milestone 3 methods



// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 4: Your First Class — Book                      ║
// ║  Skills: classes, properties, constructors, encapsulation  ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Parallel arrays (titles[] + checkedOut[]) are fragile.
//       Replace them with a Book class and a List<Book>.
//
// CREATE THE Book CLASS (bottom of file, after the top-level code):
//
//   public class Book
//   {
//       public string Title  { get; }                 // set once, in constructor
//       public string Author { get; }
//       public bool IsCheckedOut { get; private set; }  // only Book can change it
//
//       public Book(string title, string author) { ... }
//
//       public bool Checkout()   // false if already out
//       public bool Return()     // false if wasn't out
//       public string StatusLine()
//           → returns e.g. "Dune by Frank Herbert  [Available]"
//   }
//
// THEN:
//   4.1  Replace your arrays with:
//        var books = new List<Book>
//        {
//            new("Dune", "Frank Herbert"),
//            new("1984", "George Orwell"),
//            new("The Hobbit", "J.R.R. Tolkien"),
//        };
//   4.2  Rewrite ListBooks to take List<Book> and call StatusLine()
//   4.3  Rewrite checkout/return to find the Book and call ITS methods
//        — notice the validation logic moved INTO the class.
//        That's encapsulation: the object protects its own rules.
//
// 🌶 CHALLENGES:
//   C1: Add `public int TimesBorrowed { get; private set; }` —
//       increment inside Checkout(). Show it in StatusLine().
//   C2: Add an "Add a book" menu option (5) that prompts for
//       title + author and appends to the list.
//   C3: Add a search option: prompt for text, show books whose
//       Title contains it (case-insensitive).
//
// ✅ CHECKPOINT M4 (END OF BEGINNER TRACK):
//    - No parallel arrays remain
//    - Trying to check out an unavailable book is blocked BY THE
//      BOOK CLASS, not by menu code
//    - You can add a book at runtime and immediately check it out
//
//  🎉 Save this file! The Intermediate labs build directly on it.

// TODO: Milestone 4 — Book class + List<Book> refactor
