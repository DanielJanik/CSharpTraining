// ============================================================
//  LIBRATRACK WEB API — Milestone 12 Capstone
//  The same domain (DeweyLib.Core) now served over HTTP.
//  Notice how little the domain classes changed — that's the
//  payoff of the layered architecture built in M5–M11.
//
//  RUN:  dotnet run --project DeweyLib.Api
//  UI:   https://localhost:5001/swagger
// ============================================================

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using DeweyLib.Core;

var builder = WebApplication.CreateBuilder(args);

// ── M12.1: DI registration ────────────────────────────────────────
builder.Services.AddSingleton<IRepository<LibraryItem>>(_ =>
{
    var repo = new InMemoryRepository<LibraryItem>();
    repo.Add(new Book("Dune",              "B-001", "Frank Herbert",    412));
    repo.Add(new Book("1984",              "B-002", "George Orwell",    328));
    repo.Add(new Book("Emma",              "B-003", "Jane Austen",      474));
    repo.Add(new Book("The Hobbit",        "B-004", "J.R.R. Tolkien",   310));
    repo.Add(new ReferenceBook("Oxford English Dictionary", "R-001", "Oxford Press", 21730));
    repo.Add(new Dvd("Inception",          "D-101", 148));
    repo.Add(new Dvd("Arrival",            "D-102", 116));
    repo.Add(new Magazine("Wired",         "M-501", 6));
    repo.Add(new Magazine("National Geographic", "M-502", 3));
    return repo;
});

builder.Services.AddSingleton<CheckoutService>();
builder.Services.AddSingleton<HoldWatcher>();
builder.Services.AddSingleton(sp => new Reports(sp.GetRequiredService<IRepository<LibraryItem>>()));

// M12.3: exception → ProblemDetails middleware
builder.Services.AddExceptionHandler<LibraryExceptionHandler>();
builder.Services.AddProblemDetails();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "DeweyLib API", Version = "v1",
        Description = "Library management API — M12 capstone of the DeweyLib lab series." });
});

var app = builder.Build();

app.UseExceptionHandler();
app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "DeweyLib v1"));

// ── M12.4: events still work — wire up the logger ─────────────────
// The CheckoutService knows nothing about ILogger, yet every
// checkout/return appears in the ASP.NET log stream. Same event
// pattern from M9, new subscriber.
var service = app.Services.GetRequiredService<CheckoutService>();
service.ItemCirculated += (s, e) =>
    app.Logger.LogInformation("[{Action}] {Title} [{Barcode}] at {Time:t}",
        e.Action, e.Item.Title, e.Item.Barcode, e.Timestamp);

// HoldWatcher also works unchanged in the API
var holdWatcher = app.Services.GetRequiredService<HoldWatcher>();
service.ItemCirculated += holdWatcher.OnCirculation;
holdWatcher.HoldReady += (s, e) =>
    app.Logger.LogInformation("[HOLD] Notify {Patron}: '{Title}' is now available.",
        e.Patron, e.Item.Title);

// ── M12.2: endpoints ──────────────────────────────────────────────
var items   = app.MapGroup("/api/items").WithTags("Items");
var holds   = app.MapGroup("/api/holds").WithTags("Holds");
var reports = app.MapGroup("/api/reports").WithTags("Reports");

// GET /api/items — optional ?type=Book&available=true
items.MapGet("/", (
    IRepository<LibraryItem> repo,
    [FromQuery] string? type,
    [FromQuery] bool?   available) =>
{
    var q = repo.GetAll();

    if (!string.IsNullOrWhiteSpace(type))
        q = q.Where(i => i.GetType().Name.Equals(type, StringComparison.OrdinalIgnoreCase));

    if (available is not null)
        q = q.Where(i => i.IsCheckedOut == !available.Value);

    return Results.Ok(q.Select(ToDto));
})
.WithName("GetItems")
.WithSummary("List catalog items with optional type and availability filters.");

// GET /api/items/{barcode}
items.MapGet("/{barcode}", (string barcode, IRepository<LibraryItem> repo) =>
{
    var item = repo.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase));
    return item is null ? Results.NotFound(new { message = $"No item with barcode '{barcode}'." })
                        : Results.Ok(ToDto(item));
})
.WithName("GetItem")
.WithSummary("Get a single catalog item by barcode.");

// POST /api/items — add a new item
items.MapPost("/", (CreateItemRequest req, IRepository<LibraryItem> repo) =>
{
    if (repo.Find(i => i.Barcode.Equals(req.Barcode, StringComparison.OrdinalIgnoreCase)) is not null)
        return Results.Conflict(new { message = $"Barcode '{req.Barcode}' already exists." });

    LibraryItem item = req.Kind.ToLowerInvariant() switch
    {
        "book"          => new Book(req.Title, req.Barcode, req.Author ?? "Unknown", req.Pages ?? 0),
        "referencebook" => new ReferenceBook(req.Title, req.Barcode, req.Author ?? "Unknown", req.Pages ?? 0),
        "dvd"           => new Dvd(req.Title, req.Barcode, req.RuntimeMinutes ?? 0),
        "magazine"      => new Magazine(req.Title, req.Barcode, req.IssueNumber ?? 1),
        _               => throw new ArgumentException($"Unknown item kind '{req.Kind}'. Use: book, referencebook, dvd, magazine.")
    };

    repo.Add(item);
    return Results.Created($"/api/items/{item.Barcode}", ToDto(item));
})
.WithName("CreateItem")
.WithSummary("Add a new item to the catalog.");

// POST /api/items/{barcode}/checkout
items.MapPost("/{barcode}/checkout", (string barcode, CheckoutService svc) =>
{
    var item = svc.Borrow(barcode);   // throws → middleware maps to 404/409
    return Results.Ok(new
    {
        item.Title,
        item.Barcode,
        item.DueDate,
        message = $"'{item.Title}' checked out successfully."
    });
})
.WithName("CheckoutItem")
.WithSummary("Check out an available item. Returns 409 if unavailable.");

// POST /api/items/{barcode}/return
items.MapPost("/{barcode}/return", (string barcode, CheckoutService svc) =>
{
    var item = svc.GiveBack(barcode);
    return Results.Ok(new
    {
        item.Title,
        item.Barcode,
        returned = true,
        message  = $"'{item.Title}' returned successfully."
    });
})
.WithName("ReturnItem")
.WithSummary("Return a checked-out item. Returns 409 if the item wasn't checked out.");

// DELETE /api/items/{barcode}
items.MapDelete("/{barcode}", (string barcode, IRepository<LibraryItem> repo) =>
{
    var item = repo.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase))
               ?? throw new ItemNotFoundException(barcode);

    if (item.IsCheckedOut)
        return Results.Conflict(new { message = $"'{item.Title}' is currently checked out and cannot be removed." });

    repo.Remove(item);
    return Results.NoContent();
})
.WithName("DeleteItem")
.WithSummary("Remove an item from the catalog (must not be checked out).");

// ── Holds ──────────────────────────────────────────────────────────

holds.MapPost("/{barcode}", (
    string barcode,
    PlaceHoldRequest req,
    IRepository<LibraryItem> repo,
    HoldWatcher watcher) =>
{
    var item = repo.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase))
               ?? throw new ItemNotFoundException(barcode);

    watcher.PlaceHold(barcode, req.PatronName);
    return Results.Ok(new { message = $"Hold placed for {req.PatronName} on '{item.Title}'." });
})
.WithName("PlaceHold")
.WithSummary("Place a hold for a patron on a specific item.");

holds.MapGet("/", (HoldWatcher watcher) =>
    Results.Ok(watcher.CurrentHolds()))
.WithName("GetHolds")
.WithSummary("List all active hold queues.");

// ── Reports (your M8 LINQ, discovered via M11 reflection) ─────────

// GET /api/reports — list available reports
reports.MapGet("/", (Reports rpts) =>
    Results.Ok(ReportRunner.Discover(rpts)
        .Select(r => new { r.MenuTitle, r.Order })))
.WithName("ListReports")
.WithSummary("List all available reports (discovered via reflection).");

// GET /api/reports/{name} — run a named report
reports.MapGet("/{name}", (string name, Reports rpts) =>
{
    var discovered = ReportRunner.Discover(rpts);
    var report = discovered.FirstOrDefault(r =>
        r.MenuTitle.Equals(name, StringComparison.OrdinalIgnoreCase));

    if (report is null)
        return Results.NotFound(new
        {
            message = $"No report named '{name}'.",
            available = discovered.Select(r => r.MenuTitle)
        });

    return Results.Ok(new { report.MenuTitle, output = report.Run() });
})
.WithName("RunReport")
.WithSummary("Run a report by its menu title.");

// Convenience endpoints for the two most-requested reports
reports.MapGet("/overdue", (IRepository<LibraryItem> repo) =>
    Results.Ok(repo.GetAll()
        .Where(i => i.IsOverdue)
        .Select(i => new
        {
            i.Title, i.Barcode,
            daysLate = i.DaysLate,
            fee      = i.CurrentFee
        })
        .OrderByDescending(x => x.daysLate)))
.WithName("OverdueReport")
.WithSummary("Items that are currently overdue with accrued fees.");

reports.MapGet("/by-type", (IRepository<LibraryItem> repo) =>
    Results.Ok(repo.GetAll()
        .GroupBy(i => i.GetType().Name)
        .Select(g => new { type = g.Key, count = g.Count() })
        .OrderByDescending(x => x.count)))
.WithName("ByTypeReport")
.WithSummary("Catalog item counts grouped by media type.");

app.Run();

// ═══════════════════════════════════════════════════════════════════
//  Request / response types
// ═══════════════════════════════════════════════════════════════════

public record CreateItemRequest(
    [property: Required, MaxLength(120)] string Title,
    [property: Required, MaxLength(20)]  string Barcode,
    [property: Required] string Kind,           // book | referencebook | dvd | magazine
    string? Author         = null,
    int?    Pages          = null,
    int?    RuntimeMinutes = null,
    int?    IssueNumber    = null);

public record PlaceHoldRequest(
    [property: Required, MaxLength(80)] string PatronName);

// ── Shared projection to JSON-friendly shape ───────────────────────
static object ToDto(LibraryItem i) => new
{
    i.Title,
    i.Barcode,
    Kind         = i.GetType().Name,
    i.IsCheckedOut,
    i.DueDate,
    i.LoanDays,
    i.DailyLateFee,
    i.TimesBorrowed,
    i.IsOverdue,
    i.DaysLate,
    i.CurrentFee,
};

// ── M12.3: exception → ProblemDetails middleware ───────────────────
public class LibraryExceptionHandler : IExceptionHandler
{
    private readonly ILogger<LibraryExceptionHandler> _logger;

    public LibraryExceptionHandler(ILogger<LibraryExceptionHandler> logger)
        => _logger = logger;

    public async ValueTask<bool> TryHandleAsync(
        HttpContext ctx, Exception ex, CancellationToken ct)
    {
        _logger.LogWarning(ex, "Request failed: {Message}", ex.Message);

        var (status, title) = ex switch
        {
            ItemNotFoundException    => (StatusCodes.Status404NotFound,           "Item Not Found"),
            ItemUnavailableException => (StatusCodes.Status409Conflict,           "Item Unavailable"),
            ArgumentException        => (StatusCodes.Status400BadRequest,         "Invalid Request"),
            _                        => (StatusCodes.Status500InternalServerError, "Internal Server Error"),
        };

        ctx.Response.StatusCode  = status;
        ctx.Response.ContentType = "application/problem+json";

        await ctx.Response.WriteAsJsonAsync(new ProblemDetails
        {
            Status = status,
            Title  = title,
            Detail = ex.Message,
        }, ct);

        return true;
    }
}
