// ============================================================
//  LIBRATRACK v1.0 — THE COMPLETE CONSOLE APPLICATION
//  End result of lab milestones M1–M11 (M12 is DeweyLib.Api)
// ============================================================
//  Milestone map — show students where each lab landed:
//    M1–M3  banner, validated menu loop, extracted methods
//    M4–M5  Book class → full media hierarchy with due dates
//    M6     IRepository<T> for catalog and members
//    M7     custom exceptions + JSON persistence
//    M8     LINQ reports... discovered by reflection (M11)
//    M9     events: notifier, activity log, hold watcher
//    M10    async: concurrent branch search, cancellation,
//           async-stream magazine import, async save/load
//
//  RUN:  dotnet run --project DeweyLib.ConsoleApp
// ============================================================

using System.Diagnostics;
using DeweyLib.Core;

// ════════════════ Composition root ════════════════════════════════

string dataPath = Path.Combine(AppContext.BaseDirectory, "deweylib.json");
string logPath  = Path.Combine(AppContext.BaseDirectory, "library.log");

IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();
IRepository<Member>      members = new InMemoryRepository<Member>();

// M7/M10: async load with graceful fallback — a corrupted file
// warns and reseeds; it never crashes the app.
try
{
    var loaded = await LibraryStorage.LoadAsync(dataPath);
    if (loaded.Count > 0)
    {
        foreach (var item in loaded) catalog.Add(item);
        Console.WriteLine($"Loaded {loaded.Count} items from {Path.GetFileName(dataPath)}.");
    }
    else
    {
        SeedCatalog(catalog);
    }
}
catch (Exception ex)
{
    Console.WriteLine($"⚠ Could not load saved data ({ex.Message}). Starting fresh.");
    SeedCatalog(catalog);
}

members.Add(new Member(1, "Alice", "alice@example.com"));
members.Add(new Member(2, "Bob",   "bob@example.com"));

var service     = new CheckoutService(catalog);
var holdWatcher = new HoldWatcher();
var external    = new ExternalCatalogClient();
var reports     = new Reports(catalog);

// ── M9: wire up three independent subscribers ─────────────────────
service.ItemCirculated += (s, e) =>                                   // 1) console notifier
    Console.WriteLine($"  🔔 {e.Item.Title} — {e.Action} at {e.Timestamp:t}");

service.ItemCirculated += (s, e) =>                                   // 2) activity log
    File.AppendAllText(logPath, $"{e.Timestamp:u} {e.Action,-9} {e.Item.Barcode} {e.Item.Title}\n");

service.ItemCirculated += holdWatcher.OnCirculation;                  // 3) hold watcher...
holdWatcher.HoldReady  += (s, e) =>                                   //    ...which raises its own event
    Console.WriteLine($"  📣 Notify {e.Patron}: '{e.Item.Title}' is now available!");

// ════════════════ M1–M3: banner, greeting, main loop ══════════════

PrintBanner();
Console.Write("What's your name? ");
string userName = Console.ReadLine()?.Trim() is { Length: > 0 } n ? n : "Guest";
Console.WriteLine($"Welcome, {userName}!");

while (true)
{
    int choice = GetMenuChoice();
    Console.WriteLine();

    switch (choice)
    {
        case 1:   // M5: one loop, polymorphic display
            foreach (var item in catalog.GetAll())
                Console.WriteLine($"  {item.StatusLine()}");
            break;

        case 2:   // M7: service throws, UI catches
            Console.Write("Barcode to check out: ");
            try
            {
                var item = service.Borrow(Console.ReadLine() ?? "");
                Console.WriteLine($"  ✓ '{item.Title}' due back {item.DueDate:d}");
                await LibraryStorage.SaveAsync(catalog.GetAll(), dataPath);
            }
            catch (ItemNotFoundException ex)    { Console.WriteLine($"  ✗ {ex.Message}"); }
            catch (ItemUnavailableException ex) { Console.WriteLine($"  ✗ {ex.Message}"); }
            break;

        case 3:
            Console.Write("Barcode to return: ");
            try
            {
                var item = service.GiveBack(Console.ReadLine() ?? "");
                Console.WriteLine($"  ✓ '{item.Title}' returned.");
                await LibraryStorage.SaveAsync(catalog.GetAll(), dataPath);
            }
            catch (Exception ex) when (ex is ItemNotFoundException or ItemUnavailableException)
            {
                Console.WriteLine($"  ✗ {ex.Message}");
            }
            break;

        case 4:   // M4 challenge: add at runtime
            AddItemInteractive(catalog);
            await LibraryStorage.SaveAsync(catalog.GetAll(), dataPath);
            break;

        case 5:   // M4 challenge: search (case-insensitive)
            Console.Write("Search text: ");
            string term = Console.ReadLine()?.Trim() ?? "";
            var hits = catalog
                .Where(i => i.Title.Contains(term, StringComparison.OrdinalIgnoreCase))
                .ToList();
            if (hits.Count == 0) Console.WriteLine($"  No items matching '{term}'.");
            else hits.ForEach(i => Console.WriteLine($"  {i.StatusLine()}"));
            break;

        case 6:   // M9: place a hold
            Console.Write("Barcode to hold: ");
            string holdCode = Console.ReadLine()?.Trim() ?? "";
            if (catalog.Find(i => i.Barcode.Equals(holdCode, StringComparison.OrdinalIgnoreCase)) is null)
            {
                Console.WriteLine($"  ✗ No item with barcode '{holdCode}'.");
                break;
            }
            Console.Write("Patron name: ");
            holdWatcher.PlaceHold(holdCode, Console.ReadLine() ?? "");
            Console.WriteLine("  📌 Hold placed. They'll be notified on return.");
            break;

        case 7:   // M9: show hold queues
            var current = holdWatcher.CurrentHolds();
            if (current.Count == 0) { Console.WriteLine("  No active holds."); break; }
            foreach (var (barcode, queue) in current)
                Console.WriteLine($"  {barcode}: {string.Join(" → ", queue)}");
            break;

        case 8:   // M5: overdue scan
            var overdue = catalog.Where(i => i.IsOverdue).ToList();
            if (overdue.Count == 0) { Console.WriteLine("  Nothing overdue 🎉"); break; }
            foreach (var i in overdue)
                Console.WriteLine($"  {i.Title,-24} {i.DaysLate} days late — fee {i.CurrentFee:C}");
            break;

        case 9:   // M8 + M11: reflection-generated reports menu
            RunReportsMenu(reports);
            break;

        case 10:  // M10: concurrent multi-branch search w/ cancellation
            await FindEverywhereAsync(external);
            break;

        case 11:  // M10: async-stream import — items appear as they arrive
            await ImportLatestIssuesAsync(external, catalog);
            await LibraryStorage.SaveAsync(catalog.GetAll(), dataPath);
            break;

        case 12:  // demo helper: manufacture overdue data
            Console.Write("Barcode to backdate 10 days: ");
            var target = catalog.Find(i =>
                i.Barcode.Equals(Console.ReadLine()?.Trim(), StringComparison.OrdinalIgnoreCase));
            if (target is null) { Console.WriteLine("  ✗ Not found."); break; }
            if (!target.IsCheckedOut && !target.Checkout())
            {
                Console.WriteLine("  ✗ Item refuses checkout (reference?).");
                break;
            }
            target.BackdateForDemo(10);
            Console.WriteLine($"  '{target.Title}' is now 10 days overdue (demo).");
            break;

        case 0:
            await LibraryStorage.SaveAsync(catalog.GetAll(), dataPath);
            Console.WriteLine($"  Saved. Goodbye, {userName}! 📚");
            return;
    }

    Console.WriteLine("\nPress Enter to continue...");
    Console.ReadLine();
    Console.Clear();
    PrintBanner();
}

// ════════════════ M3: extracted methods ═══════════════════════════

static void PrintBanner()
{
    Console.WriteLine("╔══════════════════════════════════════╗");
    Console.WriteLine("║          📚 LIBRATRACK v1.0          ║");
    Console.WriteLine("║   The complete DeweyLib project    ║");
    Console.WriteLine("╚══════════════════════════════════════╝");
}

static int GetMenuChoice()
{
    while (true)
    {
        Console.WriteLine("\n 1. List catalog          7. Show holds");
        Console.WriteLine(" 2. Check out             8. Show overdue");
        Console.WriteLine(" 3. Return                9. Reports");
        Console.WriteLine(" 4. Add item             10. Find everywhere (async)");
        Console.WriteLine(" 5. Search               11. Import latest issues (async)");
        Console.WriteLine(" 6. Place hold           12. Backdate item (demo)");
        Console.WriteLine(" 0. Save & exit");
        Console.Write("Choose: ");

        string input = Console.ReadLine()?.Trim().ToLowerInvariant() ?? "";
        if (input is "exit" or "quit") return 0;                       // M2 challenge
        if (int.TryParse(input, out int choice) && choice is >= 0 and <= 12)
            return choice;

        Console.WriteLine("✗ Invalid option — enter a number 0-12.");
    }
}

static void AddItemInteractive(IRepository<LibraryItem> catalog)
{
    Console.Write("Type (book/dvd/magazine/reference): ");
    string kind = Console.ReadLine()?.Trim().ToLowerInvariant() ?? "";
    Console.Write("Title: ");
    string title = Console.ReadLine()?.Trim() ?? "";
    Console.Write("Barcode: ");
    string barcode = Console.ReadLine()?.Trim() ?? "";

    if (title.Length == 0 || barcode.Length == 0)
    {
        Console.WriteLine("  ✗ Title and barcode are required.");
        return;
    }
    if (catalog.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase)) is not null)
    {
        Console.WriteLine($"  ✗ Barcode '{barcode}' already exists.");
        return;
    }

    try
    {
        LibraryItem item;
        switch (kind)
        {
            case "book":
            case "reference":
                Console.Write("Author: ");
                string author = Console.ReadLine()?.Trim() ?? "Unknown";
                item = kind == "book"
                    ? new Book(title, barcode, author)
                    : new ReferenceBook(title, barcode, author);
                break;
            case "dvd":
                item = new Dvd(title, barcode);
                break;
            case "magazine":
                Console.Write("Issue number: ");
                int.TryParse(Console.ReadLine(), out int issue);
                item = new Magazine(title, barcode, issue == 0 ? 1 : issue);
                break;
            default:
                Console.WriteLine($"  ✗ Unknown type '{kind}'.");
                return;
        }
        catalog.Add(item);
        Console.WriteLine($"  ✓ Added: {item.StatusLine()}");
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine($"  ✗ {ex.Message}");
    }
}

// ── M8 + M11: menu generated ENTIRELY from [Report] attributes ────
static void RunReportsMenu(Reports reports)
{
    var discovered = ReportRunner.Discover(reports);

    Console.WriteLine("── REPORTS (discovered via reflection) ──");
    for (int i = 0; i < discovered.Count; i++)
        Console.WriteLine($"  {i + 1}. {discovered[i].MenuTitle}");
    Console.Write("Pick (or 0 to run all): ");

    if (!int.TryParse(Console.ReadLine(), out int pick) || pick < 0 || pick > discovered.Count)
    {
        Console.WriteLine("  ✗ Invalid choice.");
        return;
    }

    var toRun = pick == 0 ? discovered : new List<ReportRunner.DiscoveredReport> { discovered[pick - 1] };
    foreach (var report in toRun)
    {
        Console.WriteLine($"\n▶ {report.MenuTitle}");
        Console.WriteLine(Indent(report.Run(), "  "));
    }

    static string Indent(string text, string pad)
        => string.Join('\n', text.Split('\n').Select(line => pad + line));
}

// ── M10: concurrent branch search with a 2-second budget ─────────
static async Task FindEverywhereAsync(ExternalCatalogClient external)
{
    Console.Write("Title to find across branches: ");
    string title = Console.ReadLine()?.Trim() is { Length: > 0 } t ? t : "Dune";
    string[] branches = { "Main", "Eastside", "Westside", "South" };

    using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(2));
    var sw = Stopwatch.StartNew();

    try
    {
        // All four queries IN FLIGHT AT ONCE — total ≈ slowest, not the sum
        var tasks  = branches.Select(b => external.CheckBranchAvailabilityAsync(b, title, cts.Token));
        var counts = await Task.WhenAll(tasks);

        Console.WriteLine($"  Results in {sw.ElapsedMilliseconds}ms (concurrent):");
        foreach (var (branch, count) in branches.Zip(counts))
            Console.WriteLine($"    {branch,-10} {(count > 0 ? $"{count} available" : "none")}");
        Console.WriteLine($"  Total copies: {counts.Sum()}");
    }
    catch (OperationCanceledException)
    {
        Console.WriteLine($"  ⏱ Search cancelled at the 2s budget ({sw.ElapsedMilliseconds}ms).");
    }
}

// ── M10: consume an async stream — progress AS ITEMS ARRIVE ──────
static async Task ImportLatestIssuesAsync(
    ExternalCatalogClient external, IRepository<LibraryItem> catalog)
{
    int startIssue = catalog.GetAll().OfType<Magazine>()
        .Select(m => m.IssueNumber).DefaultIfEmpty(0).Max() + 1;

    Console.WriteLine("  Importing from publisher feed:");
    var sw = Stopwatch.StartNew();
    int imported = 0;

    await foreach (var magazine in external.ImportFeedAsync(count: 4, startIssue))
    {
        // Skip duplicates if the feed re-sends a barcode we have
        if (catalog.Find(i => i.Barcode == magazine.Barcode) is not null) continue;

        catalog.Add(magazine);
        imported++;
        Console.WriteLine($"    +{sw.ElapsedMilliseconds,4}ms  {magazine.Title} Issue #{magazine.IssueNumber} [{magazine.Barcode}]");
    }

    Console.WriteLine($"  ✓ Imported {imported} issues in {sw.ElapsedMilliseconds}ms.");
}

static void SeedCatalog(IRepository<LibraryItem> catalog)
{
    catalog.Add(new Book("Dune", "B-001", "Frank Herbert", 412));
    catalog.Add(new Book("1984", "B-002", "George Orwell", 328));
    catalog.Add(new Book("Emma", "B-003", "Jane Austen", 474));
    catalog.Add(new Book("The Hobbit", "B-004", "J.R.R. Tolkien", 310));
    catalog.Add(new ReferenceBook("Oxford English Dictionary", "R-001", "Oxford Press", 21730));
    catalog.Add(new Dvd("Inception", "D-101", 148));
    catalog.Add(new Dvd("Arrival", "D-102", 116));
    catalog.Add(new Magazine("Wired", "M-501", 6));
    catalog.Add(new Magazine("National Geographic", "M-502", 3));
    Console.WriteLine("Seeded catalog with sample data (first run).");
}
