# DeweyLib — Complete Application

The finished product of the DeweyLib lab series. A library management system built in three layers: a shared domain library, an interactive console app, and a REST API. Every concept from the training labs (M1–M12) is demonstrated in working, runnable code.

## Solution structure

```
DeweyLib.sln
│
├── DeweyLib.Core/          ← Shared domain (labs M4–M11)
│   ├── Items.cs              │  Book, Dvd, Magazine, ReferenceBook hierarchy
│   ├── Repositories.cs       │  IRepository<T> + InMemoryRepository<T>
│   ├── Exceptions.cs         │  ItemNotFoundException, ItemUnavailableException
│   ├── CheckoutService.cs    │  Business rules + ItemCirculated event
│   ├── HoldWatcher.cs        │  Event subscriber, hold queue management
│   ├── Storage.cs            │  Async JSON persistence (polymorphic)
│   ├── ExternalCatalogClient │  Simulated async network calls + async stream
│   └── Reporting.cs          │  LINQ reports + [Report] attribute + ReportRunner
│
├── DeweyLib.ConsoleApp/    ← Interactive CLI (labs M1–M11)
│   └── Program.cs            │  Full menu: checkout, returns, holds, async search,
│                             │  stream import, reflection-driven reports
│
└── DeweyLib.Api/           ← REST API (lab M12 capstone)
    └── Program.cs            │  12 endpoints + Swagger UI + exception middleware
```

## Requirements

- [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0)
- Any editor — VS Code with the C# Dev Kit extension is recommended

## Running the console app (M1–M11)

```bash
dotnet run --project DeweyLib.ConsoleApp
```

On first run the catalog is seeded with sample data and saved to `deweylib.json` in the output folder. Subsequent runs reload from that file — demonstrating M7 persistence.

**What to try:**
1. Check out `B-001` (Dune), check out `R-001` (reference book — it refuses), check out `B-001` again (409 pattern).
2. Place a hold for "Alice" on `B-001`, then return it — the hold notification fires.
3. Open **Reports** (option 9) — the menu is generated entirely by reflection (M11).
4. Use **Find everywhere** (option 10) — all four branches queried concurrently; try the 2s cancellation by temporarily setting a long forced delay in `ExternalCatalogClient`.
5. Use **Import latest issues** (option 11) — watch magazines appear one-by-one as the async stream yields them.
6. **Backdate** an item (option 12), then run the Overdue Fees report.

## Running the Web API (M12)

```bash
dotnet run --project DeweyLib.Api
```

Then open **https://localhost:5001/swagger** for the interactive Swagger UI.

**Endpoints to explore in Swagger:**

| Method | Path | What to try |
|--------|------|-------------|
| GET | `/api/items` | List all; add `?available=true` or `?type=Dvd` |
| GET | `/api/items/{barcode}` | Try `B-001`, then `BOGUS` (→ 404) |
| POST | `/api/items/B-001/checkout` | Checkout Dune |
| POST | `/api/items/B-001/checkout` | Again — expect **409 Conflict** with ProblemDetails |
| POST | `/api/items/B-001/return` | Return it |
| POST | `/api/holds/B-001` | Body: `{"patronName": "Alice"}` |
| POST | `/api/items/B-001/return` | Returns it → check API logs for hold notification |
| GET | `/api/reports` | Lists all reports (discovered by reflection) |
| GET | `/api/reports/overdue` | Structured overdue data |
| GET | `/api/reports/by-type` | Catalog counts |
| POST | `/api/items` | Add a new Book or Magazine |
| DELETE | `/api/items/{barcode}` | Remove an item (must not be checked out) |

## Lab milestone map

| File | Milestones demonstrated |
|------|------------------------|
| `Items.cs` | M4 (Book class), M5 (hierarchy, abstract/virtual) |
| `Repositories.cs` | M6 (IRepository<T>, generics) |
| `Exceptions.cs` | M7 (custom exceptions with context) |
| `CheckoutService.cs` | M7 (service throws, UI catches), M9 (events) |
| `HoldWatcher.cs` | M9 (event subscriber, chained events) |
| `Storage.cs` | M7 (JSON persistence), M10 (async I/O) |
| `ExternalCatalogClient.cs` | M10 (Task.WhenAll, cancellation, IAsyncEnumerable) |
| `Reporting.cs` | M8 (LINQ), M11 (reflection, [Report] attribute) |
| `ConsoleApp/Program.cs` | M1–M3 (menu, loop, methods), all of the above wired together |
| `Api/Program.cs` | M12 (ASP.NET Core, DI, middleware, REST endpoints) |

## Key design decisions worth discussing in class

**Services throw, UI layers catch.** `CheckoutService` throws `ItemNotFoundException` and `ItemUnavailableException`. The console app turns these into friendly messages; the API middleware turns them into 404/409 ProblemDetails. Same service code, two completely different UIs.

**Events decouple producers from consumers.** `CheckoutService` raises `ItemCirculated` and knows nothing about who is listening. The console app wires a console notifier, a file logger, and the `HoldWatcher`. The API wires an `ILogger`. Both use the same event — the service didn't change.

**Program against interfaces, not classes.** `IRepository<T>` means you could swap `InMemoryRepository<T>` for an EF Core / SQLite version and neither the console app nor the API would need changes beyond the DI registration.

**Reflection as a plugin system.** Decorating any method in `Reports` with `[Report]` makes it appear in both the console menu and the API's `/api/reports` endpoint automatically. No registration required — the same pattern ASP.NET uses for `[HttpGet]` and xUnit uses for `[Fact]`.
