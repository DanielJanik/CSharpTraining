// ============================================================
//  DeweyLib.Core – Items.cs
//  The media hierarchy (Beginner M4 → Intermediate M5)
// ============================================================

namespace DeweyLib.Core;

/// <summary>
/// Base for everything the library lends. Subclasses control loan
/// length and late fees; checkout/return rules live here so no UI
/// layer can bypass them (encapsulation, M4).
/// </summary>
public abstract class LibraryItem
{
    public string Title   { get; }
    public string Barcode { get; }
    public bool      IsCheckedOut  { get; private set; }
    public DateTime? DueDate       { get; private set; }
    public int       TimesBorrowed { get; private set; }

    protected LibraryItem(string title, string barcode)
    {
        if (string.IsNullOrWhiteSpace(title))   throw new ArgumentException("Title is required.", nameof(title));
        if (string.IsNullOrWhiteSpace(barcode)) throw new ArgumentException("Barcode is required.", nameof(barcode));
        Title   = title.Trim();
        Barcode = barcode.Trim().ToUpperInvariant();
    }

    /// <summary>Loan period — every subclass MUST define (abstract, M5).</summary>
    public abstract int LoanDays { get; }

    /// <summary>Late fee per day — subclasses MAY override (virtual, M5).</summary>
    public virtual decimal DailyLateFee => 0.25m;

    public bool    IsOverdue  => IsCheckedOut && DueDate < DateTime.Today;
    public int     DaysLate   => IsOverdue ? (DateTime.Today - DueDate!.Value).Days : 0;
    public decimal CurrentFee => DaysLate * DailyLateFee;

    /// <summary>Virtual so ReferenceBook can refuse (M5 challenge).</summary>
    public virtual bool Checkout()
    {
        if (IsCheckedOut) return false;
        IsCheckedOut = true;
        DueDate      = DateTime.Today.AddDays(LoanDays);   // polymorphic LoanDays!
        TimesBorrowed++;
        return true;
    }

    public bool Return()
    {
        if (!IsCheckedOut) return false;
        IsCheckedOut = false;
        DueDate      = null;
        return true;
    }

    public virtual string StatusLine()
        => $"[{Barcode}] {Title,-24} {GetType().Name,-9} " +
           (IsCheckedOut
               ? (IsOverdue ? $"OVERDUE {DaysLate}d (fee {CurrentFee:C})" : $"OUT — due {DueDate:d}")
               : "Available");

    // ── infrastructure hooks (not part of the lab API surface) ────
    /// <summary>Used by LibraryStorage to rebuild persisted state.</summary>
    internal void RestoreState(bool isOut, DateTime? due, int borrowed)
    {
        IsCheckedOut = isOut;
        DueDate      = due;
        TimesBorrowed = borrowed;
    }

    /// <summary>Demo/testing helper: makes a checked-out item overdue.</summary>
    public void BackdateForDemo(int days)
    {
        if (IsCheckedOut) DueDate = DateTime.Today.AddDays(-Math.Abs(days));
    }
}

public class Book : LibraryItem
{
    public string Author { get; }
    public int    Pages  { get; }

    public Book(string title, string barcode, string author, int pages = 0)
        : base(title, barcode)
    {
        Author = author;
        Pages  = pages;
    }

    public override int LoanDays => 21;

    public override string StatusLine() => base.StatusLine() + $"  by {Author}";
}

public class Dvd : LibraryItem
{
    public int RuntimeMinutes { get; }

    public Dvd(string title, string barcode, int runtimeMinutes = 0)
        : base(title, barcode) => RuntimeMinutes = runtimeMinutes;

    public override int     LoanDays     => 7;
    public override decimal DailyLateFee => 1.00m;   // DVDs cost more when late
}

public class Magazine : LibraryItem
{
    public int IssueNumber { get; }

    public Magazine(string title, string barcode, int issueNumber)
        : base(title, barcode) => IssueNumber = issueNumber;

    public override int LoanDays => 3;

    public override string StatusLine() => base.StatusLine() + $"  Issue #{IssueNumber}";
}

/// <summary>M5 challenge: reference materials never leave the building.</summary>
public class ReferenceBook : Book
{
    public ReferenceBook(string title, string barcode, string author, int pages = 0)
        : base(title, barcode, author, pages) { }

    public override bool Checkout() => false;   // always refuses

    public override string StatusLine() => base.StatusLine() + "  [REFERENCE ONLY]";
}
