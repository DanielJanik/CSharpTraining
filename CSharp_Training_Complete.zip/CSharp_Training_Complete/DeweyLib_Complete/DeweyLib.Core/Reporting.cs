// ============================================================
//  DeweyLib.Core – Reporting.cs
//  LINQ reports (M8) discovered via reflection plugins (M11)
// ============================================================

using System.Reflection;
using System.Text;

namespace DeweyLib.Core;

[AttributeUsage(AttributeTargets.Method)]
public class ReportAttribute : Attribute
{
    public string MenuTitle { get; }
    public int    Order     { get; set; } = 99;

    public ReportAttribute(string menuTitle) => MenuTitle = menuTitle;
}

/// <summary>
/// Every [Report] method is one LINQ statement producing text.
/// Adding a new report requires ZERO menu changes — ReportRunner
/// discovers it by reflection (exactly how ASP.NET finds [HttpGet]
/// endpoints and xUnit finds [Fact] tests).
/// </summary>
public class Reports
{
    private readonly IRepository<LibraryItem> _catalog;

    public Reports(IRepository<LibraryItem> catalog) => _catalog = catalog;

    [Report("Available items (alphabetical)", Order = 1)]
    public string AvailableItems() =>
        Lines(_catalog.GetAll()
            .Where(i => !i.IsCheckedOut)
            .OrderBy(i => i.Title)
            .Select(i => $"{i.Title}  ({i.GetType().Name})"));

    [Report("Checked out — due soonest first", Order = 2)]
    public string DueSoonest() =>
        Lines(_catalog.GetAll()
            .Where(i => i.IsCheckedOut)
            .OrderBy(i => i.DueDate)
            .Select(i =>
            {
                int days = (i.DueDate!.Value - DateTime.Today).Days;
                return $"{i.Title,-24} {(days < 0 ? $"{-days} days OVERDUE" : $"{days} days left")}";
            }));

    [Report("Catalog breakdown by type", Order = 3)]
    public string ByType() =>
        Lines(_catalog.GetAll()
            .GroupBy(i => i.GetType().Name)
            .OrderByDescending(g => g.Count())
            .Select(g => $"{g.Key,-14} {g.Count()}"));

    [Report("Overdue fee summary", Order = 4)]
    public string OverdueFees()
    {
        var overdue = _catalog.GetAll().Where(i => i.IsOverdue).ToList();
        if (overdue.Count == 0) return "Nothing overdue 🎉";

        var worst = overdue.MaxBy(i => i.DaysLate)!;
        return $"Items overdue: {overdue.Count}\n" +
               $"Total fees:    {overdue.Sum(i => i.CurrentFee):C}\n" +
               $"Worst:         {worst.Title} ({worst.DaysLate} days, {worst.CurrentFee:C})";
    }

    [Report("Shelf report (by first letter)", Order = 5)]
    public string ShelfReport() =>
        Lines(_catalog.GetAll()
            .GroupBy(i => char.ToUpperInvariant(i.Title[0]))
            .OrderBy(g => g.Key)
            .Select(g => $"{g.Key}: {string.Join(", ", g.Select(i => i.Title).OrderBy(t => t))}"));

    [Report("Most borrowed (top 5)", Order = 6)]
    public string MostBorrowed() =>
        Lines(_catalog.GetAll()
            .Where(i => i.TimesBorrowed > 0)
            .OrderByDescending(i => i.TimesBorrowed)
            .Take(5)
            .Select(i => $"{i.Title,-24} borrowed {i.TimesBorrowed}x"));

    // Not decorated → invisible to ReportRunner. Prove it in class!
    public string NotAReport() => "You should never see this in the menu.";

    private static string Lines(IEnumerable<string> rows)
    {
        var list = rows.ToList();
        return list.Count == 0 ? "(no matching items)" : string.Join('\n', list);
    }
}

public static class ReportRunner
{
    public record DiscoveredReport(string MenuTitle, int Order, Func<string> Run);

    /// <summary>
    /// M11: scan any object for [Report] methods returning string.
    /// </summary>
    public static List<DiscoveredReport> Discover(object reportsInstance) =>
        reportsInstance.GetType()
            .GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
            .Select(m => (Method: m, Attr: m.GetCustomAttribute<ReportAttribute>()))
            .Where(x => x.Attr is not null && x.Method.ReturnType == typeof(string)
                        && x.Method.GetParameters().Length == 0)
            .OrderBy(x => x.Attr!.Order)
            .Select(x => new DiscoveredReport(
                x.Attr!.MenuTitle,
                x.Attr!.Order,
                () => (string)x.Method.Invoke(reportsInstance, null)!))
            .ToList();
}
