// ============================================================
//  DeweyLib.Core – Exceptions.cs
//  Custom exceptions with context (Intermediate M7)
// ============================================================

namespace DeweyLib.Core;

/// <summary>
/// Design rule demonstrated throughout the app:
/// SERVICES THROW, UI LAYERS CATCH. The console app turns these
/// into friendly messages; the Web API middleware turns them into
/// 404/409 ProblemDetails responses. Same exceptions, two UIs.
/// </summary>
public class ItemNotFoundException : Exception
{
    public string Barcode { get; }

    public ItemNotFoundException(string barcode)
        : base($"No item with barcode '{barcode}'.") => Barcode = barcode;
}

public class ItemUnavailableException : Exception
{
    public string    Title   { get; }
    public DateTime? DueBack { get; }

    public ItemUnavailableException(string title, DateTime? dueBack, string reason)
        : base($"'{title}' {reason}" + (dueBack is null ? "." : $" (due back {dueBack:d})."))
    {
        Title   = title;
        DueBack = dueBack;
    }
}
