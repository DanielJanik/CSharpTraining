// ============================================================
//  DeweyLib.Core – ExternalCatalogClient.cs
//  Simulated external integrations (Advanced M10)
// ============================================================

using System.Runtime.CompilerServices;

namespace DeweyLib.Core;

/// <summary>
/// Stands in for real network calls (cover-art API, inter-library
/// loan network, publisher feed). Random delays make sequential vs
/// concurrent timing differences visible in class.
/// </summary>
public class ExternalCatalogClient
{
    public async Task<int> CheckBranchAvailabilityAsync(
        string branch, string title, CancellationToken ct = default, int? forcedDelayMs = null)
    {
        await Task.Delay(forcedDelayMs ?? Random.Shared.Next(150, 450), ct);
        return Random.Shared.Next(0, 4);   // copies at that branch
    }

    public async Task<string> FetchCoverArtUrlAsync(string title, CancellationToken ct = default)
    {
        await Task.Delay(Random.Shared.Next(200, 500), ct);
        return $"https://covers.example/{title.Replace(' ', '-').ToLowerInvariant()}.jpg";
    }

    /// <summary>
    /// M10 async stream: yields magazines one at a time, like a
    /// slow publisher feed. Consumers see items AS THEY ARRIVE.
    /// </summary>
    public async IAsyncEnumerable<Magazine> ImportFeedAsync(
        int count, int startIssue, [EnumeratorCancellation] CancellationToken ct = default)
    {
        for (int i = 0; i < count; i++)
        {
            await Task.Delay(Random.Shared.Next(120, 250), ct);
            int issue = startIssue + i;
            yield return new Magazine("Wired", $"M-F{issue:000}", issue);
        }
    }
}
