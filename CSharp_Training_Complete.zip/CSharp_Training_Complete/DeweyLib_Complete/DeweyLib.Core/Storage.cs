// ============================================================
//  DeweyLib.Core – Storage.cs
//  Polymorphic JSON persistence (M7), made async (M10)
// ============================================================

using System.Text.Json;
using System.Text.Json.Serialization;

namespace DeweyLib.Core;

/// <summary>
/// Flat DTO with a "Kind" discriminator so the polymorphic
/// hierarchy survives a JSON round-trip. (Class discussion: the
/// [JsonDerivedType] attribute is the built-in alternative.)
/// </summary>
public record ItemData(
    string Kind, string Title, string Barcode,
    bool IsCheckedOut, DateTime? DueDate, int TimesBorrowed,
    string? Author = null, int? Pages = null,
    int? RuntimeMinutes = null, int? IssueNumber = null);

public static class LibraryStorage
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public static async Task SaveAsync(
        IEnumerable<LibraryItem> items, string path, CancellationToken ct = default)
    {
        var dtos = items.Select(ToData).ToList();
        await File.WriteAllTextAsync(path, JsonSerializer.Serialize(dtos, Options), ct);
    }

    public static async Task<List<LibraryItem>> LoadAsync(
        string path, CancellationToken ct = default)
    {
        if (!File.Exists(path)) return new List<LibraryItem>();

        var json = await File.ReadAllTextAsync(path, ct);
        var dtos = JsonSerializer.Deserialize<List<ItemData>>(json) ?? new List<ItemData>();

        return dtos.Select(FromData).ToList();
    }

    private static ItemData ToData(LibraryItem i) => i switch
    {
        // ORDER MATTERS: ReferenceBook before Book (it IS a Book)
        ReferenceBook r => new ItemData("ReferenceBook", r.Title, r.Barcode, r.IsCheckedOut, r.DueDate, r.TimesBorrowed, r.Author, r.Pages),
        Book b          => new ItemData("Book",          b.Title, b.Barcode, b.IsCheckedOut, b.DueDate, b.TimesBorrowed, b.Author, b.Pages),
        Dvd d           => new ItemData("Dvd",           d.Title, d.Barcode, d.IsCheckedOut, d.DueDate, d.TimesBorrowed, RuntimeMinutes: d.RuntimeMinutes),
        Magazine m      => new ItemData("Magazine",      m.Title, m.Barcode, m.IsCheckedOut, m.DueDate, m.TimesBorrowed, IssueNumber: m.IssueNumber),
        _               => throw new NotSupportedException($"Cannot persist {i.GetType().Name}.")
    };

    private static LibraryItem FromData(ItemData d)
    {
        LibraryItem item = d.Kind switch
        {
            "ReferenceBook" => new ReferenceBook(d.Title, d.Barcode, d.Author ?? "Unknown", d.Pages ?? 0),
            "Book"          => new Book(d.Title, d.Barcode, d.Author ?? "Unknown", d.Pages ?? 0),
            "Dvd"           => new Dvd(d.Title, d.Barcode, d.RuntimeMinutes ?? 0),
            "Magazine"      => new Magazine(d.Title, d.Barcode, d.IssueNumber ?? 0),
            _               => throw new NotSupportedException($"Unknown kind '{d.Kind}' in save file.")
        };
        item.RestoreState(d.IsCheckedOut, d.DueDate, d.TimesBorrowed);
        return item;
    }
}
