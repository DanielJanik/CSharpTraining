// ============================================================
//  DeweyLib.Core – Repositories.cs
//  Generic repository pattern (Intermediate M6)
// ============================================================

namespace DeweyLib.Core;

/// <summary>
/// Storage contract. The console app and the Web API both program
/// against THIS, never against a concrete store — which is why
/// M12's stretch goal (swap in EF Core/SQLite) barely ripples.
/// </summary>
public interface IRepository<T> where T : class
{
    void Add(T item);
    bool Remove(T item);
    T?   Find(Func<T, bool> predicate);
    IEnumerable<T> GetAll();
    IEnumerable<T> Where(Func<T, bool> predicate);
    int  Count { get; }
}

public class InMemoryRepository<T> : IRepository<T> where T : class
{
    private readonly List<T> _items = new();

    public int Count => _items.Count;

    public void Add(T item) => _items.Add(item ?? throw new ArgumentNullException(nameof(item)));

    public bool Remove(T item) => _items.Remove(item);

    public T? Find(Func<T, bool> predicate) => _items.FirstOrDefault(predicate);

    public IEnumerable<T> GetAll() => _items.AsReadOnly();

    public IEnumerable<T> Where(Func<T, bool> predicate) => _items.Where(predicate);
}

/// <summary>A registered library patron (record = value semantics, M6).</summary>
public record Member(int Id, string Name, string Email);
