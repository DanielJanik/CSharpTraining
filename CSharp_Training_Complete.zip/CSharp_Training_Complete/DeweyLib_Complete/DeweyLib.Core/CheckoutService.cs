// ============================================================
//  DeweyLib.Core – CheckoutService.cs
//  Service layer with exceptions (M7) and events (M9)
// ============================================================

namespace DeweyLib.Core;

public class CirculationEventArgs : EventArgs
{
    public LibraryItem Item      { get; }
    public string      Action    { get; }   // "checkout" | "return"
    public DateTime    Timestamp { get; }

    public CirculationEventArgs(LibraryItem item, string action)
    {
        Item      = item;
        Action    = action;
        Timestamp = DateTime.Now;
    }
}

public class CheckoutService
{
    private readonly IRepository<LibraryItem> _catalog;

    public CheckoutService(IRepository<LibraryItem> catalog) => _catalog = catalog;

    /// <summary>
    /// M9: raised after every successful checkout or return.
    /// Only this class can raise it; outsiders may only += / -=.
    /// The console wires a notifier, a file logger, and the
    /// HoldWatcher to this; the API wires an ILogger. The service
    /// knows about NONE of them — that's the point.
    /// </summary>
    public event EventHandler<CirculationEventArgs>? ItemCirculated;

    public LibraryItem Borrow(string barcode)
    {
        var item = FindOrThrow(barcode);

        if (!item.Checkout())
            throw new ItemUnavailableException(item.Title, item.DueDate,
                item is ReferenceBook ? "is reference-only and cannot leave the library"
                                      : "is already checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "checkout"));
        return item;
    }

    public LibraryItem GiveBack(string barcode)
    {
        var item = FindOrThrow(barcode);

        if (!item.Return())
            throw new ItemUnavailableException(item.Title, null, "was not checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "return"));
        return item;
    }

    private LibraryItem FindOrThrow(string barcode)
        => _catalog.Find(i => i.Barcode.Equals(barcode?.Trim(), StringComparison.OrdinalIgnoreCase))
           ?? throw new ItemNotFoundException(barcode ?? "");
}
