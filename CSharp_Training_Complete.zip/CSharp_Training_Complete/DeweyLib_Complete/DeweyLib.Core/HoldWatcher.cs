// ============================================================
//  DeweyLib.Core – HoldWatcher.cs
//  Event subscriber managing hold queues (Advanced M9)
// ============================================================

namespace DeweyLib.Core;

public class HoldReadyEventArgs : EventArgs
{
    public string Patron  { get; }
    public LibraryItem Item { get; }
    public HoldReadyEventArgs(string patron, LibraryItem item)
    {
        Patron = patron;
        Item   = item;
    }
}

/// <summary>
/// Listens to CheckoutService.ItemCirculated. When a held item is
/// returned, dequeues the next patron and raises its OWN event so
/// the UI decides how to notify (console line, email, push...).
/// Note the chain: service event → watcher → watcher event → UI.
/// Neither end knows the other exists.
/// </summary>
public class HoldWatcher
{
    private readonly Dictionary<string, Queue<string>> _holds =
        new(StringComparer.OrdinalIgnoreCase);

    public event EventHandler<HoldReadyEventArgs>? HoldReady;

    public void PlaceHold(string barcode, string patron)
    {
        if (string.IsNullOrWhiteSpace(barcode) || string.IsNullOrWhiteSpace(patron)) return;

        if (!_holds.TryGetValue(barcode, out var queue))
            _holds[barcode] = queue = new Queue<string>();

        queue.Enqueue(patron.Trim());
    }

    /// <summary>Subscribe this to CheckoutService.ItemCirculated.</summary>
    public void OnCirculation(object? sender, CirculationEventArgs e)
    {
        if (e.Action != "return") return;

        if (_holds.TryGetValue(e.Item.Barcode, out var queue) && queue.Count > 0)
        {
            var nextPatron = queue.Dequeue();
            HoldReady?.Invoke(this, new HoldReadyEventArgs(nextPatron, e.Item));
        }
    }

    public IReadOnlyDictionary<string, IReadOnlyList<string>> CurrentHolds()
        => _holds.Where(kv => kv.Value.Count > 0)
                 .ToDictionary(kv => kv.Key, kv => (IReadOnlyList<string>)kv.Value.ToList());
}
