# DeweyLib Curriculum Guide — Cherry-Picking Reference

This guide maps every demo module and lab milestone to skills, time estimates, and prerequisites so you can assemble a class plan on the fly. All labs build **one application — DeweyLib, a Library Management System** — so any subset still feels like a coherent project.

## How the package fits together

```
DEMOS (instructor-run, complete code)      LABS (student-built, scaffolded)
─────────────────────────────────────      ─────────────────────────────────
Demos_Beginner.cs      B1–B7        →      Lab_Beginner_DeweyLib.cs      M1–M4
Demos_Intermediate.cs  I1–I8        →      Lab_Intermediate_DeweyLib.cs  M5–M8
Demos_Advanced.cs      A1–A8        →      Lab_Advanced_DeweyLib.cs      M9–M12

SOLUTIONS (instructor reference / catch-up starting points)
Solutions_Beginner.cs · Solutions_Intermediate.cs · Solutions_Advanced.cs
```

**Cherry-picking model:** every demo module is an independent static method — comment in/out the calls at the top of each demo file. Lab milestones are sequential within a level, but each level can start from the prior level's solution file, so a class can begin at M5 or M9 without doing earlier work.

## Demo module index

### Beginner (Demos_Beginner.cs)

| Module | Topic | Time | Pairs with lab |
|--------|-------|------|----------------|
| B1 | Console I/O, variables, TryParse | 15 min | M1 |
| B2 | Strings, formatting, StringBuilder | 15 min | M1–M2 |
| B3 | if/switch (statement + expression), all loops | 20 min | M2 |
| B4 | Methods, optional/named/out/params | 20 min | M3 |
| B5 | Arrays, List<T>, Dictionary preview | 20 min | M3–M4 |
| B6 | First class: properties, constructor, encapsulation | 25 min | M4 |
| B7 | Live debugging — 3 intentional bugs | 20 min | any |

### Intermediate (Demos_Intermediate.cs)

| Module | Topic | Time | Pairs with lab |
|--------|-------|------|----------------|
| I1 | Inheritance, abstract/virtual/override, pattern matching | 25 min | M5 |
| I2 | Interfaces, default members, IComparable | 20 min | M6 |
| I3 | Generics, repository pattern, constraints | 25 min | M6 |
| I4 | Dictionary/HashSet/Queue/Stack — choosing guide | 20 min | M6 |
| I5 | Exceptions, filters, custom exception with context | 25 min | M7 |
| I6 | File I/O, JSON round-trip, using declarations | 20 min | M7 |
| I7 | LINQ essentials + deferred execution gotcha | 30 min | M8 |
| I8 | Extension methods (how LINQ works) | 15 min | M8 |

### Advanced (Demos_Advanced.cs)

| Module | Topic | Time | Pairs with lab |
|--------|-------|------|----------------|
| A1 | Delegates → Func/Action → multicast → events | 30 min | M9 |
| A2 | Async deep dive: WhenAll/WhenAny, cancellation, progress | 35 min | M10 |
| A3 | IAsyncEnumerable / async streams | 15 min | M10 |
| A4 | LINQ advanced: Join, GroupJoin, SelectMany, ToLookup, Aggregate, Zip | 30 min | M11 reports |
| A5 | Reflection + custom attributes (mini ASP.NET routing) | 25 min | M11 |
| A6 | GC generations, Span<T> vs Substring benchmark, IDisposable | 25 min | — |
| A7 | Unsafe code & pointers (awareness; needs AllowUnsafeBlocks) | 15 min | — |
| A8 | Records, with-expressions, property/list patterns, collection expressions | 25 min | — |

## Lab milestone index (the DeweyLib build)

| Milestone | Builds | Skills | Time |
|-----------|--------|--------|------|
| M1 | Console menu & greeting | I/O, variables, interpolation | 30 min |
| M2 | Main loop + validation | if/switch/while, TryParse | 45 min |
| M3 | Refactor into methods | params, return values, out | 45 min |
| M4 | Book class replaces parallel arrays | classes, encapsulation | 60 min |
| M5 | Book/Dvd/Magazine hierarchy, due dates, overdue fees | inheritance, polymorphism | 60 min |
| M6 | IRepository<T> + Member repo | interfaces, generics | 45 min |
| M7 | Custom exceptions + JSON save/load | error handling, File I/O | 75 min |
| M8 | Six LINQ reports | Where/Select/GroupBy/aggregates | 60 min |
| M9 | Events: notifier, logger, hold watcher | delegates, events | 60 min |
| M10 | Async branch search, cancellation, async stream import | async/await | 75 min |
| M11 | Reflection-discovered report plugins | attributes, reflection | 45 min |
| M12 | **Capstone:** DeweyLib Web API + exception middleware | ASP.NET Core, DI, REST | 2–3 hrs |

Every milestone ends with a ✅ CHECKPOINT (observable behavior to verify) and 🌶 CHALLENGES for fast finishers. M12 includes five stretch goals (pagination, persistence, EF Core swap, xUnit tests, background worker).

## Sample class plans

**Half-day, true beginners:** Demos B1→B3→B4→B6, labs M1–M4. Use B7 (debugging) as an energizer after lunch if running a full day.

**Full day, some programming background:** Morning demos B6, I1, I3 with labs M4–M6; afternoon demos I5, I6, I7 with labs M7–M8.

**Full day, experienced developers:** Morning demos A1, A2, A3 with labs M9–M10 (start students from Solutions_Intermediate.cs); afternoon demo A5 with lab M11, then M12 capstone. A6/A8 make good lecture interludes while students wait on others.

**Two-day complete program:** Day 1 = beginner + intermediate tracks (M1–M8); Day 2 = advanced track (M9–M12), with A4/A6/A7/A8 demos sprinkled as lecture segments.

**Mixed-skill classroom:** start everyone at their level's first milestone using the prior solution file as the base; checkpoints let you verify each student independently. Challenges keep fast students busy without advancing them past the group.

## Instructor logistics

Setup per student: .NET 10 SDK, any editor (VS Code + C# Dev Kit recommended, or Visual Studio 2026 Community). Each demo file is a standalone console program: `dotnet new console`, paste, `dotnet run`. A7 requires `<AllowUnsafeBlocks>true</AllowUnsafeBlocks>` in the csproj. M12 requires `dotnet new webapi -n DeweyLib.Api --use-minimal-apis`.

Solutions files are runnable end-state programs: Beginner and Intermediate solutions are interactive console apps; the Advanced solution runs M9–M11 as a scripted demo and contains the complete M12 Web API Program.cs in a trailing comment block. Beginner/Intermediate solutions preserve "historical" code from earlier milestones in comments so you can show the progression on screen.

Distribute labs at session start; hold solutions until checkpoints are verified, or hand the prior level's solution to students who join mid-track.
