// ============================================================
//  C# Training – ADVANCED DEMOS (Instructor File)
//  Cherry-pickable modules: run any subset by commenting in/out
// ============================================================
//  MODULES:
//    A1 – Delegates, Events & the Observer Pattern
//    A2 – Async/Await Deep Dive (sequential vs concurrent, cancellation)
//    A3 – IAsyncEnumerable & Async Streams
//    A4 – LINQ Advanced (joins, SelectMany, lookups, Aggregate)
//    A5 – Reflection & Attributes
//    A6 – Memory, Span<T> & the Garbage Collector
//    A7 – Unsafe Code & Pointers (awareness-level)
//    A8 – Records, Pattern Matching & Modern C# Idioms
// ------------------------------------------------------------
//  RUN: dotnet new console -n AdvancedDemos
//       copy this into Program.cs
//       For A7: add <AllowUnsafeBlocks>true</AllowUnsafeBlocks>
//               inside <PropertyGroup> in the .csproj
// ============================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

Console.WriteLine("=== ADVANCED DEMOS ===\n");

// ── Cherry-pick: comment out modules you don't need ──────────────
AdvancedDemos.A1_DelegatesAndEvents();
await AdvancedDemos.A2_AsyncDeepDive();
await AdvancedDemos.A3_AsyncStreams();
AdvancedDemos.A4_LinqAdvanced();
AdvancedDemos.A5_ReflectionAndAttributes();
AdvancedDemos.A6_MemoryAndGC();
// AdvancedDemos.A7_UnsafeCode();   // requires AllowUnsafeBlocks in csproj
AdvancedDemos.A8_ModernIdioms();

static class AdvancedDemos
{
    // ══════════════════════════════════════════════════════════════
    // A1 – Delegates, Events & Observer Pattern
    // Build up: raw delegate → Func/Action → multicast → event.
    // Then show the library notification system pattern.
    // ══════════════════════════════════════════════════════════════
    public static void A1_DelegatesAndEvents()
    {
        Console.WriteLine("── A1: Delegates & Events ───────────────────────");

        // STEP 1: A delegate is a TYPE for methods
        FeeCalculator standard = days => days * 0.25m;
        FeeCalculator premium  = days => days * 0.10m;   // members pay less

        Console.WriteLine($"  Standard fee, 8 days: {standard(8):C}");
        Console.WriteLine($"  Premium fee,  8 days: {premium(8):C}");

        // STEP 2: Pass behavior as a parameter (strategy pattern)
        static decimal Charge(int days, FeeCalculator calc) => calc(days);
        Console.WriteLine($"  Strategy injection: {Charge(8, premium):C}");

        // STEP 3: Multicast — one call, many handlers
        Action<string> auditTrail  = msg => Console.WriteLine($"    [AUDIT] {msg}");
        auditTrail                += msg => Console.WriteLine($"    [METRICS] count++ for: {msg}");
        auditTrail("hold-placed");

        // STEP 4: Events — multicast with encapsulation
        // (only the OWNER can raise; outsiders can only +=/-=)
        var circulation = new CirculationDesk();

        circulation.ItemOverdue += (s, e) =>
            Console.WriteLine($"  📧 Email: '{e.Title}' overdue {e.DaysLate} days, fee {e.Fee:C}");
        circulation.ItemOverdue += (s, e) =>
        {
            if (e.DaysLate > 14)
                Console.WriteLine($"  🚨 Escalation: suspend account (>{14} days)");
        };

        circulation.ProcessOverdues();
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A2 – Async/Await Deep Dive
    // Sequential vs WhenAll vs WhenAny, cancellation, timeout,
    // progress reporting, common deadlock pitfall
    // ══════════════════════════════════════════════════════════════
    public static async Task A2_AsyncDeepDive()
    {
        Console.WriteLine("── A2: Async/Await Deep Dive ────────────────────");

        // Simulated I/O calls — each takes its own time
        static async Task<string> FetchCatalogAsync(string branch, int ms, CancellationToken ct = default)
        {
            await Task.Delay(ms, ct);   // pretend network call
            return $"{branch} catalog ({ms}ms)";
        }

        // SEQUENTIAL — total = sum of all delays
        var sw = Stopwatch.StartNew();
        await FetchCatalogAsync("Main",     250);
        await FetchCatalogAsync("Eastside", 200);
        await FetchCatalogAsync("Westside", 150);
        Console.WriteLine($"  Sequential:  {sw.ElapsedMilliseconds}ms (≈600)");

        // CONCURRENT — total = max of all delays
        sw.Restart();
        var all = await Task.WhenAll(
            FetchCatalogAsync("Main",     250),
            FetchCatalogAsync("Eastside", 200),
            FetchCatalogAsync("Westside", 150));
        Console.WriteLine($"  Concurrent:  {sw.ElapsedMilliseconds}ms (≈250) — {all.Length} results");

        // WhenAny — first one wins (e.g., race mirrored servers)
        sw.Restart();
        var winner = await Task.WhenAny(
            FetchCatalogAsync("Mirror-A", 300),
            FetchCatalogAsync("Mirror-B", 120));
        Console.WriteLine($"  WhenAny winner: {await winner} in {sw.ElapsedMilliseconds}ms");

        // CANCELLATION — cooperative, not forced
        using var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(100));
        try
        {
            await FetchCatalogAsync("Slow", 1000, cts.Token);
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("  Cancelled after 100ms timeout ✓");
        }

        // PROGRESS reporting from async work
        var progress = new Progress<int>(pct => Console.Write($"\r  Importing: {pct}%   "));
        await ImportRecordsAsync(progress);
        Console.WriteLine("done ✓");

        // PITFALL (talk through, do NOT run):
        //   var result = FetchCatalogAsync("X", 100).Result;   // ❌ can deadlock
        //   Always: var result = await FetchCatalogAsync(...); // ✓
        Console.WriteLine();
    }

    static async Task ImportRecordsAsync(IProgress<int> progress)
    {
        for (int pct = 0; pct <= 100; pct += 25)
        {
            await Task.Delay(60);
            progress.Report(pct);
        }
    }

    // ══════════════════════════════════════════════════════════════
    // A3 – IAsyncEnumerable & Async Streams
    // Stream results as they arrive instead of waiting for all
    // ══════════════════════════════════════════════════════════════
    public static async Task A3_AsyncStreams()
    {
        Console.WriteLine("── A3: Async Streams ────────────────────────────");

        // Producer: yields pages from a "slow database"
        static async IAsyncEnumerable<string[]> FetchPagesAsync(int pages)
        {
            for (int p = 1; p <= pages; p++)
            {
                await Task.Delay(80);   // per-page latency
                yield return Enumerable.Range(1, 3).Select(i => $"P{p}-Book{i}").ToArray();
            }
        }

        // Consumer: processes each page AS IT ARRIVES
        var sw = Stopwatch.StartNew();
        await foreach (var page in FetchPagesAsync(3))
            Console.WriteLine($"  +{sw.ElapsedMilliseconds,4}ms  received: {string.Join(", ", page)}");

        // Contrast: a Task<List<T>> version would show NOTHING until
        // every page was loaded. Streams give responsiveness.
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A4 – LINQ Advanced
    // Join, GroupJoin, SelectMany, ToLookup, Aggregate, Zip
    // ══════════════════════════════════════════════════════════════
    public static void A4_LinqAdvanced()
    {
        Console.WriteLine("── A4: LINQ Advanced ────────────────────────────");

        var members = new[]
        {
            new { Id = 1, Name = "Alice" },
            new { Id = 2, Name = "Bob"   },
            new { Id = 3, Name = "Carol" },
        };
        var loans = new[]
        {
            new { MemberId = 1, Title = "Dune",  Fee = 1.50m },
            new { MemberId = 1, Title = "1984",  Fee = 0.00m },
            new { MemberId = 2, Title = "It",    Fee = 3.25m },
        };

        // JOIN — inner join: only members WITH loans
        var joined = members.Join(loans,
            m => m.Id, l => l.MemberId,
            (m, l) => $"{m.Name} → {l.Title}");
        Console.WriteLine($"  Join: {string.Join("; ", joined)}");

        // GROUPJOIN — left-join style: every member, with their (possibly empty) loans
        var withCounts = members.GroupJoin(loans,
            m => m.Id, l => l.MemberId,
            (m, ls) => $"{m.Name}:{ls.Count()}");
        Console.WriteLine($"  GroupJoin: {string.Join(", ", withCounts)}");  // Carol:0 included!

        // SELECTMANY — flatten nested collections
        var branches = new[]
        {
            new { Branch = "Main", Titles = new[] { "Dune", "It" } },
            new { Branch = "East", Titles = new[] { "Emma" } },
        };
        var flat = branches.SelectMany(b => b.Titles.Select(t => $"{b.Branch}/{t}"));
        Console.WriteLine($"  SelectMany: {string.Join(", ", flat)}");

        // TOLOOKUP — like GroupBy but materialized + indexable
        var lookup = loans.ToLookup(l => l.MemberId);
        Console.WriteLine($"  Lookup[1]: {string.Join(", ", lookup[1].Select(l => l.Title))}");
        Console.WriteLine($"  Lookup[99]: empty? {!lookup[99].Any()} (no KeyNotFound — safe!)");

        // AGGREGATE — custom fold
        var receipt = loans.Aggregate("FEES:", (acc, l) => acc + $" {l.Title}={l.Fee:C}");
        Console.WriteLine($"  Aggregate: {receipt}");

        // ZIP — pair two sequences positionally
        var barcodes = new[] { "B-1", "B-2", "B-3" };
        var titles   = new[] { "Dune", "1984", "It" };
        Console.WriteLine($"  Zip: {string.Join(", ", barcodes.Zip(titles, (b, t) => $"{b}:{t}"))}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A5 – Reflection & Attributes
    // Inspect types at runtime; define and read a custom attribute
    // (the mechanism behind [Required], [HttpGet], xUnit [Fact]...)
    // ══════════════════════════════════════════════════════════════
    public static void A5_ReflectionAndAttributes()
    {
        Console.WriteLine("── A5: Reflection & Attributes ──────────────────");

        // Inspect a type at runtime
        Type t = typeof(ReportEngine);
        Console.WriteLine($"  Type: {t.FullName}");
        Console.WriteLine($"  Methods: {string.Join(", ", t.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly).Select(m => m.Name))}");

        // Read our CUSTOM attribute and dispatch dynamically —
        // this is a mini version of how ASP.NET routes [HttpGet] methods
        var engine = new ReportEngine();
        foreach (var method in t.GetMethods())
        {
            var attr = method.GetCustomAttribute<ReportAttribute>();
            if (attr is null) continue;
            Console.WriteLine($"  Running report '{attr.Name}' (schedule: {attr.Schedule}):");
            method.Invoke(engine, null);    // dynamic invocation
        }

        // Instantiate by name — plugin-style loading
        var instance = Activator.CreateInstance(typeof(ReportEngine));
        Console.WriteLine($"  Activator created: {instance?.GetType().Name}");

        // TALKING POINT: reflection is powerful but ~100x slower than a
        // direct call. Modern alternative: Source Generators (compile-time).
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A6 – Memory, Span<T> & the Garbage Collector
    // Gen 0/1/2, allocation pressure, Span slicing without copies
    // ══════════════════════════════════════════════════════════════
    public static void A6_MemoryAndGC()
    {
        Console.WriteLine("── A6: Memory & Garbage Collection ──────────────");

        // Observe GC generations
        var obj = new byte[1000];
        Console.WriteLine($"  New object generation: {GC.GetGeneration(obj)} (Gen 0 = nursery)");
        GC.Collect();   // demo only — NEVER call in production code!
        GC.WaitForPendingFinalizers();
        Console.WriteLine($"  After collection:      {GC.GetGeneration(obj)} (survivor promoted)");

        Console.WriteLine($"  Total managed memory:  {GC.GetTotalMemory(false) / 1024:N0} KB");
        Console.WriteLine($"  Gen0 collections so far: {GC.CollectionCount(0)}");

        // Allocation pressure comparison: Substring vs Span slicing
        const string isbnLine = "ISBN:978-0441172719|TITLE:Dune";

        // Substring ALLOCATES a new string each call:
        string viaSubstring = isbnLine.Substring(5, 17);

        // Span SLICES the same memory — zero allocation:
        ReadOnlySpan<char> span = isbnLine.AsSpan(5, 17);

        Console.WriteLine($"  Substring: {viaSubstring}");
        Console.WriteLine($"  Span:      {span.ToString()} (no intermediate allocation)");

        // Micro-benchmark to make it visceral
        var sw = Stopwatch.StartNew();
        long dummy = 0;
        for (int i = 0; i < 1_000_000; i++)
            dummy += isbnLine.Substring(5, 17).Length;       // 1M string allocations
        var substringMs = sw.ElapsedMilliseconds;

        sw.Restart();
        for (int i = 0; i < 1_000_000; i++)
            dummy += isbnLine.AsSpan(5, 17).Length;          // zero allocations
        var spanMs = sw.ElapsedMilliseconds;

        Console.WriteLine($"  1M iterations — Substring: {substringMs}ms, Span: {spanMs}ms");

        // IDisposable + using = deterministic cleanup for UNMANAGED resources
        using (var resource = new TrackedResource("db-connection"))
            resource.Use();
        Console.WriteLine("  (Dispose ran at the closing brace — not when GC felt like it)");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A7 – Unsafe Code & Pointers  (AWARENESS LEVEL)
    // Requires: <AllowUnsafeBlocks>true</AllowUnsafeBlocks> in csproj
    // Message: you will almost never need this; here's what it is.
    // ══════════════════════════════════════════════════════════════
    public static void A7_UnsafeCode()
    {
        Console.WriteLine("── A7: Unsafe Code (awareness) ──────────────────");
        unsafe
        {
            int value = 42;
            int* ptr = &value;                      // take the address
            Console.WriteLine($"  Value: {value}, via pointer: {*ptr}");
            *ptr = 99;                              // write through the pointer
            Console.WriteLine($"  After *ptr = 99 → value = {value}");

            // stackalloc — allocate on the STACK (no GC involvement)
            Span<int> buffer = stackalloc int[4] { 1, 2, 3, 4 };
            int sum = 0;
            foreach (var n in buffer) sum += n;
            Console.WriteLine($"  stackalloc sum: {sum}");
        }
        // WHEN is unsafe legit? Interop with native libraries,
        // extreme perf hot paths, hardware access. Otherwise: avoid.
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // A8 – Records, Pattern Matching & Modern Idioms
    // The C# 9–12 features that make code dramatically shorter
    // ══════════════════════════════════════════════════════════════
    public static void A8_ModernIdioms()
    {
        Console.WriteLine("── A8: Modern C# Idioms ─────────────────────────");

        // Records: value equality + with-expressions + deconstruction
        var v1 = new CatalogEntry("Dune", "Herbert", 4.5);
        var v2 = v1 with { Rating = 4.8 };
        var (title, author, _) = v2;                       // deconstruct
        Console.WriteLine($"  with-expr: {v2}");
        Console.WriteLine($"  Deconstructed: {title} / {author}");
        var v3 = v2 with { Rating = 4.5 };
        Console.WriteLine($"  Value equality: v1 == v3? {v1 == v3}");   // true — same data

        // Property patterns + relational patterns
        static string Shelf(CatalogEntry e) => e switch
        {
            { Rating: >= 4.5 }                    => "Staff Picks",
            { Author: "Herbert" }                 => "Sci-Fi Masters",
            { Rating: < 2.0 }                     => "Discount Bin",
            _                                     => "General",
        };
        Console.WriteLine($"  Shelf(v2) = {Shelf(v2)}");

        // List patterns (C# 11)
        int[] returns = { 1, 2, 3, 4, 5 };
        var summary = returns switch
        {
            []                  => "no returns",
            [var only]          => $"single return: {only}",
            [var first, .., var last] => $"{returns.Length} returns, first={first}, last={last}",
        };
        Console.WriteLine($"  List pattern: {summary}");

        // Tuples for lightweight multi-returns
        static (int total, double avg) Stats(IEnumerable<int> xs)
            => (xs.Sum(), xs.Average());
        var (total, avg) = Stats(returns);
        Console.WriteLine($"  Tuple return: total={total}, avg={avg:F1}");

        // Collection expressions (C# 12)
        int[] merged = [..returns, 6, 7];
        Console.WriteLine($"  Collection expr: [{string.Join(",", merged)}]");

        // Null-handling idioms — show all four
        string? maybe = null;
        Console.WriteLine($"  ??  → {maybe ?? "fallback"}");
        maybe ??= "assigned";
        Console.WriteLine($"  ??= → {maybe}");
        Console.WriteLine($"  ?.  → len {maybe?.Length}");
        ArgumentNullException.ThrowIfNull(maybe);   // guard-clause idiom
        Console.WriteLine();
    }
}

// ═══════════════════════════════════════════════════════════════════
//  SUPPORTING TYPES
// ═══════════════════════════════════════════════════════════════════

// A1: custom delegate type
public delegate decimal FeeCalculator(int daysLate);

// A1: event publisher
public class OverdueEventArgs : EventArgs
{
    public string  Title    { get; }
    public int     DaysLate { get; }
    public decimal Fee      { get; }
    public OverdueEventArgs(string title, int days, decimal fee)
    { Title = title; DaysLate = days; Fee = fee; }
}

public class CirculationDesk
{
    public event EventHandler<OverdueEventArgs>? ItemOverdue;

    public void ProcessOverdues()
    {
        // Pretend we scanned the database...
        var overdue = new[] { ("Dune", 5), ("1984", 21) };
        foreach (var (title, days) in overdue)
            ItemOverdue?.Invoke(this, new OverdueEventArgs(title, days, days * 0.25m));
    }
}

// A5: custom attribute + reflective dispatch target
[AttributeUsage(AttributeTargets.Method)]
public class ReportAttribute : Attribute
{
    public string Name     { get; }
    public string Schedule { get; set; } = "daily";
    public ReportAttribute(string name) => Name = name;
}

public class ReportEngine
{
    [Report("overdue-summary", Schedule = "hourly")]
    public void OverdueSummary() => Console.WriteLine("    → 2 items overdue, $5.75 in fees");

    [Report("circulation-stats")]
    public void CirculationStats() => Console.WriteLine("    → 148 checkouts this week");

    public void NotAReport() { }   // no attribute → skipped by the dispatcher
}

// A6: IDisposable demonstration
public class TrackedResource : IDisposable
{
    private readonly string _name;
    public TrackedResource(string name) { _name = name; Console.WriteLine($"  Acquired: {_name}"); }
    public void Use() => Console.WriteLine($"  Using:    {_name}");
    public void Dispose() => Console.WriteLine($"  Disposed: {_name}");
}

// A8: record
public record CatalogEntry(string Title, string Author, double Rating);
