// ============================================================
//  LIBRATRACK – ADVANCED SOLUTIONS (Milestones 9–12)
//  INSTRUCTOR REFERENCE
// ============================================================
//  PART 1 (this runnable file): M9 events, M10 async, M11 reflection
//      RUN: dotnet new console -n DeweyLibAdvanced → Program.cs
//      (Includes minimal copies of the M5–M7 domain types so it
//       compiles standalone; in a real class, students keep theirs.)
//
//  PART 2 (bottom, in comments): complete M12 Web API Program.cs
//      RUN: dotnet new webapi -n DeweyLib.Api --use-minimal-apis
// ============================================================

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

// ════════════════════ Composition root ════════════════════════════

IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();
catalog.Add(new Book("Dune", "B-001", "Frank Herbert"));
catalog.Add(new Book("1984", "B-002", "George Orwell"));
catalog.Add(new Dvd("Inception", "D-101"));

var service    = new CheckoutService(catalog);
var holdWatcher = new HoldWatcher();
var reports    = new Reports(catalog);

// ── M9 step 9.3: three independent subscribers ────────────────────
service.ItemCirculated += (s, e) =>                                   // a) console
    Console.WriteLine($"  🔔 {e.Item.Title} {e.Action} at {e.Timestamp:t}");

service.ItemCirculated += (s, e) =>                                   // b) log file
    System.IO.File.AppendAllText("library.log",
        $"{e.Timestamp:u} {e.Action,-9} {e.Item.Barcode} {e.Item.Title}\n");

service.ItemCirculated += holdWatcher.OnCirculation;                  // c) holds

Console.WriteLine("=== LIBRATRACK ADVANCED (M9–M11 demo run) ===\n");

// ════════════════════ M9: Events in action ════════════════════════
Console.WriteLine("── M9: Events ──────────────────────────────────");

holdWatcher.PlaceHold("B-001", "Alice");
holdWatcher.PlaceHold("B-001", "Bob");

service.Borrow("B-001");        // fires console + log subscribers
service.GiveBack("B-001");      // ALSO fires HoldWatcher → notifies Alice
service.Borrow("B-001");
service.GiveBack("B-001");      // notifies Bob

// ════════════════════ M10: Async operations ═══════════════════════
Console.WriteLine("\n── M10: Async ──────────────────────────────────");

var external = new ExternalCatalogClient();
string[] branches = { "Main", "East", "West", "South" };

// 10.3 — concurrent branch availability with Task.WhenAll
var sw = Stopwatch.StartNew();
var tasks  = branches.Select(b => external.CheckBranchAvailabilityAsync(b, "Dune"));
var counts = await Task.WhenAll(tasks);
Console.WriteLine($"  Concurrent: " +
    string.Join(" | ", branches.Zip(counts, (b, c) => $"{b}: {c}")) +
    $"   ({sw.ElapsedMilliseconds}ms)");

// Sequential comparison — feel the difference
sw.Restart();
foreach (var b in branches)
    await external.CheckBranchAvailabilityAsync(b, "Dune");
Console.WriteLine($"  Sequential: same work took {sw.ElapsedMilliseconds}ms");

// 10.4 — cancellation with a time budget
using (var cts = new CancellationTokenSource(TimeSpan.FromMilliseconds(250)))
{
    try
    {
        await external.CheckBranchAvailabilityAsync("VerySlowBranch", "Dune", cts.Token, forcedDelay: 2000);
        Console.WriteLine("  Slow branch answered (unexpected)");
    }
    catch (OperationCanceledException)
    {
        Console.WriteLine("  ✓ Slow branch cancelled at 250ms budget");
    }
}

// 10.5 — async stream import, items appear AS THEY ARRIVE
Console.WriteLine("  Importing latest issues:");
sw.Restart();
await foreach (var mag in ImportFeedAsync(3))
{
    catalog.Add(mag);
    Console.WriteLine($"    +{sw.ElapsedMilliseconds,4}ms  added {mag.Title} Issue #{((Magazine)mag).IssueNumber}");
}

static async IAsyncEnumerable<LibraryItem> ImportFeedAsync(int count)
{
    for (int i = 1; i <= count; i++)
    {
        await Task.Delay(150);                       // simulated feed latency
        yield return new Magazine($"Wired", $"M-9{i:00}", issue: i);
    }
}

// ════════════════════ M11: Reflection plugins ═════════════════════
Console.WriteLine("\n── M11: Reflection-discovered reports ──────────");
ReportRunner.RunAll(reports);    // class demo runs all; lab builds the menu

Console.WriteLine("\nDone. See bottom of file for the complete M12 Web API.");

// ═══════════════════════════════════════════════════════════════════
//  DOMAIN TYPES (minimal versions so this file compiles standalone)
// ═══════════════════════════════════════════════════════════════════

public abstract class LibraryItem
{
    public string Title { get; }
    public string Barcode { get; }
    public bool IsCheckedOut { get; private set; }
    public DateTime? DueDate { get; private set; }
    protected LibraryItem(string title, string barcode) { Title = title; Barcode = barcode; }
    public abstract int LoanDays { get; }
    public virtual decimal DailyLateFee => 0.25m;
    public bool IsOverdue => IsCheckedOut && DueDate < DateTime.Today;

    public bool Checkout()
    {
        if (IsCheckedOut) return false;
        IsCheckedOut = true;
        DueDate = DateTime.Today.AddDays(LoanDays);
        return true;
    }
    public bool Return()
    {
        if (!IsCheckedOut) return false;
        IsCheckedOut = false; DueDate = null;
        return true;
    }
}

public class Book : LibraryItem
{
    public string Author { get; }
    public Book(string t, string b, string author) : base(t, b) => Author = author;
    public override int LoanDays => 21;
}

public class Dvd : LibraryItem
{
    public Dvd(string t, string b) : base(t, b) { }
    public override int LoanDays => 7;
    public override decimal DailyLateFee => 1.00m;
}

public class Magazine : LibraryItem
{
    public int IssueNumber { get; }
    public Magazine(string t, string b, int issue) : base(t, b) => IssueNumber = issue;
    public override int LoanDays => 3;
}

public interface IRepository<T> where T : class
{
    void Add(T item);
    T? Find(Func<T, bool> predicate);
    IEnumerable<T> GetAll();
}

public class InMemoryRepository<T> : IRepository<T> where T : class
{
    private readonly List<T> _items = new();
    public void Add(T item) => _items.Add(item);
    public T? Find(Func<T, bool> p) => _items.FirstOrDefault(p);
    public IEnumerable<T> GetAll() => _items.AsReadOnly();
}

public class ItemNotFoundException : Exception
{
    public string Barcode { get; }
    public ItemNotFoundException(string b) : base($"No item with barcode '{b}'.") => Barcode = b;
}
public class ItemUnavailableException : Exception
{
    public ItemUnavailableException(string title, string reason) : base($"'{title}' {reason}.") { }
}

// ═══════════════════ M9: Events ═══════════════════════════════════

public class CirculationEventArgs : EventArgs
{
    public LibraryItem Item { get; }
    public string Action { get; }
    public DateTime Timestamp { get; }
    public CirculationEventArgs(LibraryItem item, string action)
    { Item = item; Action = action; Timestamp = DateTime.Now; }
}

public class CheckoutService
{
    private readonly IRepository<LibraryItem> _catalog;
    public CheckoutService(IRepository<LibraryItem> catalog) => _catalog = catalog;

    // The event — only THIS class can raise; outsiders only += / -=
    public event EventHandler<CirculationEventArgs>? ItemCirculated;

    public LibraryItem Borrow(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);
        if (!item.Checkout())
            throw new ItemUnavailableException(item.Title, "is already checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "checkout"));
        return item;
    }

    public LibraryItem GiveBack(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);
        if (!item.Return())
            throw new ItemUnavailableException(item.Title, "was not checked out");

        ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "return"));
        return item;
    }
}

// Subscriber c) — reacts to returns, knows nothing about the service
public class HoldWatcher
{
    private readonly Dictionary<string, Queue<string>> _holds = new();

    public void PlaceHold(string barcode, string patron)
    {
        if (!_holds.TryGetValue(barcode, out var q))
            _holds[barcode] = q = new Queue<string>();
        q.Enqueue(patron);
        Console.WriteLine($"  📌 Hold placed: {patron} → {barcode}");
    }

    public void OnCirculation(object? sender, CirculationEventArgs e)
    {
        if (e.Action != "return") return;
        if (_holds.TryGetValue(e.Item.Barcode, out var q) && q.Count > 0)
            Console.WriteLine($"  📣 Notify {q.Dequeue()}: '{e.Item.Title}' is now available!");
    }
}

// ═══════════════════ M10: External client ═════════════════════════

public class ExternalCatalogClient
{
    private static readonly Random _rng = new();

    public async Task<int> CheckBranchAvailabilityAsync(
        string branch, string title, CancellationToken ct = default, int? forcedDelay = null)
    {
        await Task.Delay(forcedDelay ?? _rng.Next(150, 400), ct);
        return _rng.Next(0, 4);
    }

    public async Task<string> FetchCoverArtUrlAsync(string title, CancellationToken ct = default)
    {
        await Task.Delay(_rng.Next(200, 500), ct);
        return $"https://covers.example/{title.Replace(' ', '-').ToLower()}.jpg";
    }
}

// ═══════════════════ M11: Reflection plugins ══════════════════════

[AttributeUsage(AttributeTargets.Method)]
public class ReportAttribute : Attribute
{
    public string MenuTitle { get; }
    public int Order { get; set; } = 99;
    public ReportAttribute(string menuTitle) => MenuTitle = menuTitle;
}

public class Reports
{
    private readonly IRepository<LibraryItem> _catalog;
    public Reports(IRepository<LibraryItem> catalog) => _catalog = catalog;

    [Report("Available items", Order = 1)]
    public void AvailableItems()
    {
        foreach (var i in _catalog.GetAll().Where(i => !i.IsCheckedOut).OrderBy(i => i.Title))
            Console.WriteLine($"      {i.Title}");
    }

    [Report("Catalog by type", Order = 2)]
    public void ByType()
    {
        foreach (var g in _catalog.GetAll().GroupBy(i => i.GetType().Name))
            Console.WriteLine($"      {g.Key}: {g.Count()}");
    }

    [Report("Overdue fees", Order = 3)]
    public void OverdueFees()
    {
        var od = _catalog.GetAll().Where(i => i.IsOverdue).ToList();
        Console.WriteLine($"      {od.Count} overdue, " +
            $"{od.Sum(i => (DateTime.Today - i.DueDate!.Value).Days * i.DailyLateFee):C} owed");
    }

    public void NotAReport() { }   // no attribute → invisible to the runner
}

public static class ReportRunner
{
    public static void RunAll(object reportsInstance)
    {
        var discovered = reportsInstance.GetType()
            .GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)
            .Select(m => (Method: m, Attr: m.GetCustomAttribute<ReportAttribute>()))
            .Where(x => x.Attr is not null)
            .OrderBy(x => x.Attr!.Order)
            .ToList();

        foreach (var (method, attr) in discovered)
        {
            Console.WriteLine($"  ▶ {attr!.MenuTitle}");
            method.Invoke(reportsInstance, null);      // dynamic dispatch
        }
    }
}

/* ═══════════════════════════════════════════════════════════════════
   PART 2 — MILESTONE 12 SOLUTION: DeweyLib Web API
   Create with: dotnet new webapi -n DeweyLib.Api --use-minimal-apis
   Then replace Program.cs with the following (and bring over the
   domain types above, minus the console demo code).
═══════════════════════════════════════════════════════════════════

using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;

var builder = WebApplication.CreateBuilder(args);

// ── 12.1: DI registration ──────────────────────────────────────────
builder.Services.AddSingleton<IRepository<LibraryItem>>(_ =>
{
    var repo = new InMemoryRepository<LibraryItem>();
    repo.Add(new Book("Dune", "B-001", "Frank Herbert"));
    repo.Add(new Book("1984", "B-002", "George Orwell"));
    repo.Add(new Dvd("Inception", "D-101"));
    repo.Add(new Magazine("Wired", "M-501", 6));
    return repo;
});
builder.Services.AddSingleton<CheckoutService>();
builder.Services.AddExceptionHandler<LibraryExceptionHandler>();
builder.Services.AddProblemDetails();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseExceptionHandler();
app.UseSwagger();
app.UseSwaggerUI();

// ── 12.4: events still work — subscribe the logger ─────────────────
var service = app.Services.GetRequiredService<CheckoutService>();
service.ItemCirculated += (s, e) =>
    app.Logger.LogInformation("{Action}: {Title} [{Barcode}]",
        e.Action, e.Item.Title, e.Item.Barcode);

// ── 12.2: endpoints ────────────────────────────────────────────────
var items   = app.MapGroup("/api/items").WithTags("Items");
var reports = app.MapGroup("/api/reports").WithTags("Reports");

// GET /api/items?type=Book&available=true
items.MapGet("/", (IRepository<LibraryItem> repo,
    [FromQuery] string? type, [FromQuery] bool? available) =>
{
    var q = repo.GetAll();
    if (!string.IsNullOrEmpty(type))
        q = q.Where(i => i.GetType().Name.Equals(type, StringComparison.OrdinalIgnoreCase));
    if (available is not null)
        q = q.Where(i => i.IsCheckedOut == !available.Value);

    return Results.Ok(q.Select(ToDto));
});

items.MapGet("/{barcode}", (string barcode, IRepository<LibraryItem> repo) =>
{
    var item = repo.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase));
    return item is null ? Results.NotFound() : Results.Ok(ToDto(item));
});

items.MapPost("/", (CreateItemRequest req, IRepository<LibraryItem> repo) =>
{
    if (repo.Find(i => i.Barcode == req.Barcode) is not null)
        return Results.Conflict(new { message = $"Barcode {req.Barcode} already exists." });

    LibraryItem item = req.Kind.ToLower() switch
    {
        "book"     => new Book(req.Title, req.Barcode, req.Author ?? "Unknown"),
        "dvd"      => new Dvd(req.Title, req.Barcode),
        "magazine" => new Magazine(req.Title, req.Barcode, req.IssueNumber ?? 1),
        _          => throw new ArgumentException($"Unknown kind '{req.Kind}'")
    };
    repo.Add(item);
    return Results.Created($"/api/items/{item.Barcode}", ToDto(item));
});

items.MapPost("/{barcode}/checkout", (string barcode, CheckoutService svc) =>
{
    var item = svc.Borrow(barcode);     // throws → handled by middleware
    return Results.Ok(new { item.Title, item.Barcode, item.DueDate });
});

items.MapPost("/{barcode}/return", (string barcode, CheckoutService svc) =>
{
    var item = svc.GiveBack(barcode);
    return Results.Ok(new { item.Title, item.Barcode, returned = true });
});

// Reports — your M8 LINQ, nearly verbatim
reports.MapGet("/overdue", (IRepository<LibraryItem> repo) =>
    Results.Ok(repo.GetAll()
        .Where(i => i.IsOverdue)
        .Select(i => new {
            i.Title, i.Barcode,
            daysLate = (DateTime.Today - i.DueDate!.Value).Days,
            fee = (DateTime.Today - i.DueDate!.Value).Days * i.DailyLateFee
        })));

reports.MapGet("/by-type", (IRepository<LibraryItem> repo) =>
    Results.Ok(repo.GetAll()
        .GroupBy(i => i.GetType().Name)
        .Select(g => new { type = g.Key, count = g.Count() })));

app.Run();

static object ToDto(LibraryItem i) => new
{
    i.Title, i.Barcode, kind = i.GetType().Name,
    i.IsCheckedOut, i.DueDate, i.LoanDays
};

// ── 12.2: request model with validation ────────────────────────────
public record CreateItemRequest(
    [property: Required, MaxLength(120)] string Title,
    [property: Required, MaxLength(20)]  string Barcode,
    [property: Required] string Kind,           // "book" | "dvd" | "magazine"
    string? Author = null,
    int? IssueNumber = null);

// ── 12.3: exception → ProblemDetails middleware ─────────────────────
public class LibraryExceptionHandler : IExceptionHandler
{
    private readonly ILogger<LibraryExceptionHandler> _logger;
    public LibraryExceptionHandler(ILogger<LibraryExceptionHandler> logger) => _logger = logger;

    public async ValueTask<bool> TryHandleAsync(
        HttpContext ctx, Exception ex, CancellationToken ct)
    {
        _logger.LogWarning(ex, "Request failed: {Message}", ex.Message);

        var (status, title) = ex switch
        {
            ItemNotFoundException    => (StatusCodes.Status404NotFound,  "Item Not Found"),
            ItemUnavailableException => (StatusCodes.Status409Conflict,  "Item Unavailable"),
            ArgumentException        => (StatusCodes.Status400BadRequest,"Invalid Request"),
            _                        => (StatusCodes.Status500InternalServerError, "Server Error"),
        };

        ctx.Response.StatusCode = status;
        await ctx.Response.WriteAsJsonAsync(new ProblemDetails
        {
            Status = status, Title = title, Detail = ex.Message
        }, ct);
        return true;
    }
}
═══════════════════════════════════════════════════════════════════ */
