# C# Fundamentals & Advanced Topics
## 2-Day Remote Training — Instructor Lesson Plan
### Delivery via Microsoft Teams — Two Half-Day Sessions (8:00 AM – 11:30 AM)

---

## ⚠️ Important: This is a Compressed Half-Day Format

This lesson plan covers a **3.5-hour session each day** (8:00 AM – 11:30 AM), not a full 8-hour day. All the original content is preserved — every section, every lab, every slide — but breaks are minimal (5 minutes), lunch is removed, and every section and lab is compressed proportionally to fit.

**What this means in practice:**
- Pacing is tight. There is very little slack — running long on one section eats directly into the next.
- Most labs are still real hands-on practice, but the time windows are short. Expect to spend more time circulating and less time waiting.
- **Lab 6 (the Web API capstone) is the biggest compromise** — it drops from a 90-minute independent build to a 20-minute instructor-led live walkthrough. See the note in that section for how to run it.
- Consider this plan a tight but complete pass through the material. If your group needs more hands-on time on any lab, the original 8-hour structure (with full lunch breaks and longer lab windows) is a reasonable fallback — you'd need to either extend the session or split content across additional days.

---

## Overview

| | Day 1 | Day 2 |
|---|---|---|
| **Time** | 8:00 AM – 11:30 AM | 8:00 AM – 11:30 AM |
| **Theme** | C# Foundations | Advanced C# & Applications |
| **Sections** | 1–4 (Introduction, Fundamentals, OOP, Interfaces) | 5–9 (LINQ, Events, Async, Exceptions, Web API) |
| **Labs** | Labs 1–3 | Labs 4–6 (Lab 6 is instructor-led, see note) |
| **Application built** | DeweyLib console app M1–M4 | DeweyLib M5–M12 + Web API |
| **Engagement beats** | Poll after Section 1, discussion during OOP | Knowledge check after LINQ, timing demo for async |

---

## Before the Class

### Instructor setup (night before)
- [ ] Upload to Teams channel Files tab: `DeweyLib_Training_Package.zip` (contains all demos, lab starters, solutions, and the complete app)
- [ ] Post in the Teams channel: "Please download and unzip the training files before 8am. Run `dotnet --version` to confirm .NET 10 is installed."
- [ ] Prepare breakout rooms in Teams (6 rooms, auto-assignment works fine)
- [ ] Have the completed app (`DeweyLib_Complete/`) open in your own VS Code — ready to reference or run at any time
- [ ] Have `Demos_Beginner.cs`, `Demos_Intermediate.cs`, and `Demos_Advanced.cs` open in separate tabs — you'll run modules from these live throughout both days

### Student prerequisites
- .NET 10 SDK installed (`dotnet --version` → `10.x.x`)
- VS Code + C# Dev Kit extension, OR Visual Studio 2022 Community
- Downloaded and unzipped the training package

---

## Day 1 — C# Foundations (8:00 AM – 11:30 AM, 3.5 hours)

### 8:00 – 8:05 | Welcome & Setup Check (5 min)

**Slides:** Title, Remote Rules, Setup Checklist

**What to do:**
1. Greet everyone as they join; let the title slide sit while people settle
2. Walk through the "How This Remote Class Works" slide — emphasise: camera on, chat is live, breakout rooms for labs
3. Setup check: ask everyone to type `dotnet --version` in their terminal and paste the result in chat. Handle any issues now — don't carry setup problems into content time
4. Quick introductions: name, role, one word about their C# experience
5. Show the Day 1 agenda table so students know exactly what's coming

**Common issues:** .NET version wrong (need 10.x), VS Code not recognising C# files (C# Dev Kit not installed). Keep `https://dotnet.microsoft.com/download` bookmarked.

---

### 8:05 – 8:40 | Section 1: Introduction to C# (35 min)

**Slides:** Section 1 divider → What is C# → History → Key Features → .NET/CLR → Application Types → Dev Environment

**Pacing guide:**
- **8:05 – 8:13** What is C# + History cards (8 min) — keep this brisk; it's context, not content
- **8:13 – 8:23** Key Features + .NET/CLR execution model (10 min) — the CLR slide is worth drawing: source → IL → JIT → native
- **8:23 – 8:33** Application types + Dev environment (10 min) — live demo: open a terminal, `dotnet new console -n Demo`, open in VS Code
- **8:33 – 8:40** Poll: experience levels (use the poll slide + Teams poll or just ask for chat responses A/B/C/D) — use results to calibrate your pace for Section 2

**Live demo during Dev Environment slide:**
```bash
dotnet new console -n HelloWorld
cd HelloWorld
code .
# Show: Program.cs, HelloWorld.csproj
dotnet run
```

**Talking point for CLR:** "Every .NET language — C#, F#, VB.NET — compiles to the same IL. That's why you can reference a library written in F# from a C# project."

---

### 8:40 – 8:55 | Lab 1: Hello C# (15 min)

**Slide:** Lab 1

**Setup:** Send students to breakout rooms. Rotate through rooms every 8-10 minutes.

**What students build:** A console app that prints a greeting, asks the user's name, and formats output with `$""` interpolation.

**Commands they need:**
```bash
dotnet new console -n HelloCSharp
cd HelloCSharp
code .
dotnet run
```

**What to watch for:**
- Students who can't find the terminal (show: VS Code → Terminal → New Terminal)
- Students using `Console.WriteLine($"Hello {name}!")` correctly — confirm they understand the `$` prefix
- Fast finishers: point them to the 🌶 challenge (multiplication table)

**Debrief (last 3 minutes, back in main room):** Ask 2–3 students to share screen and show their output.

---

### 8:55 – 9:00 | Break (5 min)

Remind: be back at 9:00 sharp, we're going into the densest content of Day 1.

---

### 9:00 – 9:35 | Section 2: C# Fundamentals (35 min)

**Slides:** Section 2 divider → Data Types → Data Types Demo (live) → Operators → Control Flow → Control Flow Demo (live) → Methods → Methods Demo (live)

**Pacing guide:**
- **9:00 – 9:09** Data types — run `Demos_Beginner.cs` module B1 live (9 min)
- **9:09 – 9:16** Operators & expressions — no separate slide needed; cover inline while showing B2 (7 min)
- **9:16 – 9:27** Control flow — run B3 live, emphasise switch *expression* vs statement. Draw the loop decision tree on the shared whiteboard: "Know the count? → for. Condition-driven? → while. Collection? → foreach." (11 min)
- **9:27 – 9:35** Methods — run B4 live. Show `out` parameters by live-coding `TryCheckout()` from scratch (8 min)

**Key moments to slow down:**
- `int.TryParse` vs `int.Parse` — show the exception with Parse on bad input first, then show TryParse
- Integer division: `7 / 2 = 3` — write this on screen, ask the class what they expect, reveal the answer
- Switch expression: write the statement version first, then collapse it to the expression form

**Demo file to use:** `Demos_Beginner.cs` — modules B1, B3, B4

---

### 9:35 – 9:40 | Break (5 min)

Post in Teams chat: "Back at 9:40. Lab 2 starts immediately — make sure VS Code is open."

---

### 9:40 – 10:00 | Lab 2: Data Types, Control Flow & Methods (20 min)

**Slide:** Lab 2

**What students build:** A `BookTracker` console app with a while-loop menu, `int.TryParse` validation, and extracted methods.

**Lab starter file:** `Lab_Beginner_DeweyLib.cs` milestones M1–M3 (the comments contain all the TODOs)

**Progression:**
1. M1 — basic menu output (5 min)
2. M2 — while loop + TryParse validation (15 min) — this is where most students stall; check in on breakout rooms early
3. M3 — extract methods: `PrintBanner()`, `GetMenuChoice()`, `ListBooks()` (20 min)

**What to watch for:**
- Students putting `Console.ReadLine()` outside the loop — common mistake
- Students using `int.Parse` without TryParse — point them to B1 demo
- The "how do I exit the loop" question → `return;` from Main, or a bool flag

**Debrief:** Ask: "What's the difference between a method that returns bool vs void? When would you use each?" (This sets up Lab 3.)

---

### 10:00 – 10:40 | Section 3: Classes, Objects & Inheritance (40 min)

**Slides:** Section 3 divider → Classes & Objects → Book Class Demo → Inheritance & Polymorphism → Discussion slide → Polymorphism in Action → Lab 3

**Pacing guide:**
- **10:00 – 10:09** Classes & Objects — run B6 live; write the Book class from scratch on screen (9 min)
- **10:09 – 10:20** Inheritance demo — run I1 live from `Demos_Intermediate.cs`; build the hierarchy step by step (11 min)
- **10:20 – 10:27** Discussion slide — "Should Checkout() be abstract or virtual?" — put in Teams chat, collect answers, explain (7 min)
- **10:27 – 10:40** Polymorphism in Action demo — run I1's polymorphism section; show the single foreach loop; use pattern matching (13 min)

**Critical teaching moment — private set:**
Write on screen: `book.IsCheckedOut = true;` — show that this is a compile ERROR. Then show that `book.Checkout()` works. Say: "The object is protecting its own state. The menu can't cheat."

**Critical teaching moment — polymorphism:**
Run the foreach loop that calls `Checkout()` on Books and DVDs. Show the due dates: Books get +21, DVDs get +7. "We wrote ONE line of code. The objects decided what to do. That's polymorphism."

**Demo file:** `Demos_Beginner.cs` B6 for Book class, then `Demos_Intermediate.cs` I1 for the full hierarchy

---

### 10:40 – 10:45 | Break (5 min)

---

### 10:45 – 11:05 | Lab 3: Build the Book Class (20 min)

**Slide:** Lab 3

**What students build:** Complete DeweyLib M1–M4 — a working console app with a Book class and the beginning of a media hierarchy.

**Lab starter:** Students extend their Lab 2 code. If anyone is behind, provide `Solutions_Beginner.cs` as a starting point for the hierarchy work.

**Progression:**
1. M4 — Create Book class, replace parallel arrays with `List<Book>` (20 min)
2. M5 preview — Add `abstract LibraryItem` base class, create Dvd and Magazine subclasses (20 min)
3. Demonstrate polymorphism: one foreach, three types, different LoanDays (10 min)

**Debrief:** Ask one student to share screen and show their class hierarchy. Ask the class: "Where are the checkout rules — in the menu or in the class?" (Answer: the class. Encapsulation.)

---

### 11:05 – 11:30 | Section 4: Interfaces & Generics + Day 1 Wrap-up (25 min)

**Slides:** Section 4 divider → Interfaces → Generic Repository code slide → Day 1 Complete → Day 2 Preview

**Pacing:**
- **11:05 – 11:17** Interfaces + Generic Repository — run I2 and I3 from `Demos_Intermediate.cs` (12 min)
- **11:17 – 11:23** Day 1 wrap-up slide — read through the checklist, ask students to confirm in chat (6 min)
- **11:23 – 11:30** Day 2 preview + homework suggestion (7 min)

**Key message for interfaces:** "Declare your variable as the INTERFACE type: `IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();` — if we later want a database, we change ONE line. The menu doesn't change."

**Homework suggestion (optional):** Read through Lab_Intermediate_DeweyLib.cs milestones M5–M8 before Day 2 starts. Come with questions.

---

## Day 2 — Advanced C# & Applications (8:00 AM – 11:30 AM, 3.5 hours)

### 8:00 – 8:05 | Day 1 Recap Q&A (5 min)

**No slides needed** — open Teams chat and address any questions from Day 1.

Quick verbal recap: "Yesterday: types, flow, methods, classes, inheritance, polymorphism, interfaces. Today: LINQ, events, async, exceptions, reflection, and we're building a REST API."

---

### 8:05 – 8:40 | Section 5: LINQ (35 min)

**Slides:** Section 5 divider → What is LINQ → LINQ Essentials code slide → Deferred Execution code slide → LINQ in Practice

**Pacing guide:**
- **8:05 – 8:12** What is LINQ + intro — set up a `List<LibraryItem>` in a new scratch file (7 min)
- **8:12 – 8:24** Run the LINQ Essentials demo — Where, Select, OrderBy, then GroupBy (SLOW DOWN HERE) (12 min)
- **8:24 – 8:33** Deferred Execution demo — run this live, let students see the `★` characters print at the right moment. Ask: "What did you expect to see? What did you actually see?" (9 min)
- **8:33 – 8:40** LINQ in Practice — FirstOrDefault vs First, Count vs .Count (7 min)

**The GroupBy slow-down:** Before running the demo, draw on the shared whiteboard:
```
catalog
  ├── Group "Book"    → [Dune, 1984, Emma]
  ├── Group "Dvd"     → [Inception, Arrival]
  └── Group "Magazine"→ [Wired, NatGeo]
```
Then show the code. The visual model first, code second.

**Deferred execution live moment:** Before calling `.ToList()`, ask the class: "How many stars have printed?" (zero). Call `.ToList()`, show the stars. "That's deferred execution."

**Demo file:** `Demos_Intermediate.cs` module I7

---

### 8:40 – 9:00 | Lab 4: LINQ Reports (20 min)

**Slide:** Lab 4

**What students build:** 5 LINQ report methods on a seeded catalog — written inline as single expressions.

**Key constraint to state upfront:** "Each report is ONE LINQ chain — no loops inside the method."

**Debrief:** Knowledge check slide — "What does FirstOrDefault() return if no item matches?" Answer: null (or the default value of T — which is null for classes). NOT an exception.

---

### 9:00 – 9:05 | Break (5 min)

---

### 9:05 – 9:35 | Section 6: Delegates, Events & Observer Pattern (30 min)

**Slides:** Section 6 divider → Delegates → Delegates to Events code → Observer Pattern

**Pacing guide:**
- **9:05 – 9:14** Build up from raw delegate → Func<> → Action<> → multicast → event — run A1 from `Demos_Advanced.cs` step by step (9 min)
- **9:14 – 9:26** Events code demo — show the `CheckoutService` with the event, wire three subscribers (12 min)
- **9:26 – 9:35** Observer pattern slide — "The service knows about NONE of these subscribers." Draw the connections on the whiteboard: `CheckoutService` → event → [Console, File, HoldWatcher]. Ask: "What would we change in CheckoutService to add a 4th subscriber?" (Nothing.) (9 min)

**Key insight to emphasise:** The event keyword adds encapsulation to a multicast delegate. Outside code can only += or -=. Only the owning class can invoke it. Write this on screen explicitly.

**Demo file:** `Demos_Advanced.cs` module A1

---

### 9:35 – 9:40 | Break (5 min)

---

### 9:40 – 10:15 | Section 7: Async/Await (35 min)

**Slides:** Section 7 divider → Why Async → Sequential vs Concurrent code → Async Pitfalls → Async Streams code

**Pacing guide:**
- **9:40 – 9:52** Why async + sequential vs concurrent demo — run A2 from `Demos_Advanced.cs`. Run sequential, read the time aloud. Run concurrent, read the time aloud. Let the difference land. (12 min)
- **9:52 – 10:01** Pitfalls slide — show `.Result` deadlock scenario, `async void` problem. Use the two-column layout to compare good vs bad (9 min)
- **10:01 – 10:10** CancellationToken demo — extend the concurrent demo to add a 500ms budget, trigger the cancellation (9 min)
- **10:10 – 10:15** Async streams — run A3 from `Demos_Advanced.cs`, watch items appear 150ms apart (5 min)

**The timing demo moment:** Say the numbers aloud as they print. "Sequential: 1,140ms. Concurrent: 387ms. Same work, three times faster, just by not waiting in line."

**Async pitfalls script:** For `.Result`, say: "In a simple console app it often works. In ASP.NET, it deadlocks. The habit to build now is: always await. Never use .Result or .Wait() on async code."

**Demo file:** `Demos_Advanced.cs` modules A2, A3

---

### 10:15 – 10:40 | Lab 5: Async Branch Search + Events (25 min)

**Slide:** Lab 5

**What students build:** Add events to CheckoutService, implement concurrent branch search with cancellation, and consume the async magazine feed.

**Progression:**
1. Wire the event + 2 subscribers (15 min) — guide: model after the A1 demo
2. Implement FindEverywhereAsync with Task.WhenAll (15 min) — copy the A2 demo pattern
3. Add 1-second CancellationTokenSource (5 min)
4. Wire ImportFeedAsync with await foreach (10 min)

**Debrief:** Ask students to share their sequential vs concurrent timings in chat. Note the variance — real network delays vary.

---

### 10:40 – 10:45 | Break (5 min)

"Last break — then exceptions, reflection, and we finish with the Web API."

---

### 10:45 – 11:10 | Section 8: Exceptions · Reflection · Memory (25 min)

**Slides:** Section 8 divider → Exception Handling → Custom Exception code → Reflection & Attributes → Memory cards

**Pacing guide:**
- **10:45 – 10:53** Custom exceptions demo — run I5 from `Demos_Intermediate.cs`. Create `ItemNotFoundException` live. Show the services-throw/UI-catches pattern (8 min)
- **10:53 – 11:01** Reflection & attributes — run A5 from `Demos_Advanced.cs`. Show `[Report]` attribute discovery. Say: "This is exactly how `[HttpGet]` works in ASP.NET." (8 min)
- **11:01 – 11:10** Memory management card slide — walk through GC generations, show Span<T> benchmark, IDisposable + using. Mention unsafe briefly — "You'll see it in library code. You probably won't write it." (9 min)

**Key moment for exceptions:** Write on screen: `throw;` vs `throw ex;`. "The first preserves the stack trace. The second resets it and hides where the error actually happened. Always use the bare `throw;` when re-throwing."

**Demo files:** `Demos_Intermediate.cs` I5, `Demos_Advanced.cs` A5, A6

---

### 11:10 – 11:30 | Section 9: ASP.NET Core Web API Capstone (20 min)

**⚠️ Compression note:** This section was originally 90 minutes with a full independent build lab. At 20 minutes there isn't time for students to build the API themselves from scratch. The approach below converts Lab 6 from a hands-on build into an **instructor-led live build** with students following along in their own editor — they type what you type, at your pace, so everyone ends the session with a running API on their machine even though they didn't design it independently. The full independent-build version of Lab 6 (with breakout rooms and the stretch goals) is still in `Lab_Advanced_DeweyLib.cs` for anyone who wants to redo it properly afterward.

**Slides:** Section 9 divider → Console Applications → ASP.NET Architecture → Minimal API code → Exception Middleware code → Lab 6

**Pacing guide:**
- **11:10 – 11:12** Console apps recap — "Everything you've built is a console app. Now we'll add an HTTP layer on top of the same domain." (2 min)
- **11:12 – 11:15** ASP.NET Core architecture + Minimal API code — walk through the Program.cs structure at a high level, don't linger (3 min)
- **11:15 – 11:17** Exception middleware code — "The same `ItemNotFoundException` from Lab 3 now becomes HTTP 404. The service code didn't change. Only the UI layer changed." (2 min)
- **11:17 – 11:28** Live-built walkthrough — see below (11 min)
- **11:28 – 11:30** Swagger demo + close (2 min)

**Live-built walkthrough approach:** Open a terminal and run `dotnet new webapi -n DeweyLib.Api --use-minimal-apis` on screen. Add the project reference to DeweyLib.Core. Then type the DI registration and these two endpoints live, narrating each line, with students typing along in their own project:
```csharp
items.MapGet("/", (IRepository<LibraryItem> repo) => repo.GetAll().Select(ToDto));
items.MapPost("/{barcode}/checkout", (string barcode, CheckoutService svc) => svc.Borrow(barcode));
```
Explain DI injection via the parameter as you go. Don't pause for independent work — keep typing and narrating, and let students catch up via chat if they fall behind. This is a guided build, not an exploration.

**What to watch for:**
- DI not registered — runtime error, not compile error. Show the error message and point to `builder.Services.Add...`
- Swagger not loading — usually missing `app.UseSwagger(); app.UseSwaggerUI();`
- Students falling behind on the typing — if more than a couple are stuck, pause briefly rather than losing them for the rest of the walkthrough

**Close (last 2 minutes):** Switch to the completed `DeweyLib.Api` solution in Swagger and hit every endpoint live — list, get one, checkout, double-checkout to show 409, return. Tell students: "Everything we just typed, plus holds and reports, is already finished in `DeweyLib_Complete/` in the Files tab. Run it tonight, poke at it, and if you want the full independent-build experience, `Lab_Advanced_DeweyLib.cs` has the complete Lab 6 with stretch goals."

---

### 11:30 | Day 2 Wrap-up (final slides)

**Slides:** What You Built → What to Study Next → Final title slide

Walk the "What You Built" slide — one sentence per milestone. "Two days ago you typed `Console.WriteLine`. Right now you have a running REST API."

Share the "What to Study Next" slide and tell them where to find the course files after the session ends.

---

## Remote Delivery Tips

### Keeping energy up on Teams
- Use the poll and discussion slides — even in a tighter 3.5-hour session, energy dips happen. Don't skip these
- Call on people by name during the code demos: "Alice, what do you think this returns?"
- Use the whiteboard feature for the GroupBy diagram and the CLR execution model
- Do a quick chat check-in every 45–60 minutes: "Drop a 👍 if you're following or ❓ if you have a question"
- Keep your own camera on during demos — it helps establish connection

### Managing the chat
- Acknowledge questions as they come: "Great question, I'll get to that in a moment" or "Alice asks X — anyone want to answer that before I do?"
- If a question takes more than 2 minutes to answer, note it in the chat and come back to it at the end of the section
- Students paste code in chat frequently — this is good, encourage it

### Breakout room management
- Set rooms to "auto-assign" — it's faster
- Teams will show you a list of rooms with a participant count — join the smallest room first
- Use the "Ask for Help" button briefing at the start of each lab: "Click the '...' in your breakout room and choose 'Ask for Help' if you're stuck"
- Announce "5 minutes left" before closing rooms — students lose track of time

### Pacing adjustments
- Running ahead: slow down on the deferred execution demo, add a whiteboard GroupBy drawing, give challenge extensions
- Running behind: cut the Async Streams slide (A3) from the lecture, cover it briefly in the lab debrief; skip the Unsafe Code slide; Labs 4 and 5 can be combined
- If Section 3 goes long: Labs 1 and 2 can be cut to 20 min each by removing the challenge extensions

### Technical issues
- Student can't share screen: they may need to grant screen-share permission in Teams settings → Settings → Privacy
- Student IDE not working: have them use the online editor at https://dotnetfiddle.net as a fallback
- Your screen share lagging: close other applications, share the specific window not the whole screen

---

## Slide Reference

| Slide # | Type | Content |
|---|---|---|
| 1 | Title | Master title |
| 2 | Remote rules | Teams etiquette cards |
| 3 | Setup | Pre-class checklist |
| 4 | Day 1 title | |
| 5 | Agenda table | Day 1 schedule |
| 6 | Section 1 | Introduction |
| 7–11 | Content | What is C#, History, Features, .NET/CLR, App types, Dev env |
| 12 | Lab 1 | Hello C# |
| 13 | Poll | Experience level |
| 14 | Section 2 | Fundamentals |
| 15–21 | Content | Data types, code demo, operators, control flow, code demo, methods, code demo |
| 22 | Lab 2 | Data types, flow, methods |
| 23 | Section 3 | Classes & Inheritance |
| 24–28 | Content | Classes, code demo, inheritance, discussion, polymorphism demo |
| 29 | Lab 3 | Book class |
| 30 | Section 4 | Interfaces & Generics |
| 31–33 | Content | Interfaces, generic repository code |
| 34 | Day 1 wrap-up | |
| 35 | Day 2 preview | |
| 36 | Day 2 title | |
| 37 | Agenda table | Day 2 schedule |
| 38 | Section 5 | LINQ |
| 39–42 | Content | What is LINQ, essentials code, deferred execution, in practice |
| 43 | Lab 4 | LINQ reports |
| 44 | Knowledge check | FirstOrDefault |
| 45 | Section 6 | Delegates & Events |
| 46–48 | Content | Delegates, delegates to events code, observer pattern |
| 49 | Section 7 | Async |
| 50–53 | Content | Why async, sequential vs concurrent code, pitfalls, async streams |
| 54 | Lab 5 | Async + events |
| 55 | Section 8 | Exceptions/Reflection/Memory |
| 56–59 | Content | Exception handling, custom exception code, reflection, memory cards |
| 60 | Section 9 | ASP.NET Core |
| 61–64 | Content | Console apps, ASP.NET architecture, Minimal API code, exception middleware |
| 65 | Lab 6 | Web API capstone |
| 66 | Day 2 wrap-up | What you built |
| 67 | Next steps | What to study next |
| 68 | Final title | |

---

## Files Reference

| File | Used when |
|---|---|
| `CSharp_2Day_Training.pptx` | The main deck — open this in PowerPoint or Teams |
| `Demos_Beginner.cs` | Section 1–3 live demos (modules B1–B7) |
| `Demos_Intermediate.cs` | Section 3–6 live demos (modules I1–I8) |
| `Demos_Advanced.cs` | Section 6–8 live demos (modules A1–A8) |
| `Lab_Beginner_DeweyLib.cs` | Labs 1–3 starter file |
| `Lab_Intermediate_DeweyLib.cs` | Lab 4 starter |
| `Lab_Advanced_DeweyLib.cs` | Labs 5–6 starter |
| `Solutions_Beginner.cs` | Reference / catch-up for Labs 1–3 |
| `Solutions_Intermediate.cs` | Reference / catch-up for Lab 4 |
| `Solutions_Advanced.cs` | Reference / catch-up for Labs 5–6 |
| `DeweyLib_Complete/` | The finished app — show this at the very start ("here's where you're going") |
