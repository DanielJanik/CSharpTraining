// ============================================================
//  LIBRATRACK – INTERMEDIATE SOLUTIONS (Milestones 5–8)
//  INSTRUCTOR REFERENCE — complete working implementation
// ============================================================
//  Final state after M8 incl. key challenges. Menu is trimmed to
//  the items needed to demonstrate each milestone.
//
//  RUN: dotnet new console -n DeweyLibIntermediate
//       paste into Program.cs → dotnet run
// ============================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

// ════════════════════ Composition root ════════════════════════════

string dataPath = Path.Combine(AppContext.BaseDirectory, "deweylib.json");

// M6: program against the INTERFACE
IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();
IRepository<Member>      members = new InMemoryRepository<Member>();

// M7: load persisted data, or seed on first run / corruption
try
{
    var loaded = LibraryStorage.Load(dataPath);
    if (loaded.Count > 0)
    {
        foreach (var item in loaded) catalog.Add(item);
        Console.WriteLine($"Loaded {loaded.Count} items from {Path.GetFileName(dataPath)}.");
    }
    else SeedCatalog(catalog);
}
catch (Exception ex)
{
    Console.WriteLine($"⚠ Could not load saved data ({ex.Message}). Starting fresh.");
    SeedCatalog(catalog);
}

members.Add(new Member(1, "Alice", "alice@example.com"));
members.Add(new Member(2, "Bob",   "bob@example.com"));

var checkoutService = new CheckoutService(catalog);

// ════════════════════ Main loop ═══════════════════════════════════

while (true)
{
    Console.WriteLine("\n╔══════════════════════════════╗");
    Console.WriteLine("║      📚 LIBRATRACK v0.8      ║");
    Console.WriteLine("╚══════════════════════════════╝");
    Console.WriteLine("1. List catalog        5. Reports");
    Console.WriteLine("2. Check out (barcode) 6. Backdate item (demo overdue)");
    Console.WriteLine("3. Return (barcode)    7. Exit");
    Console.WriteLine("4. Show overdue");
    Console.Write("Choose: ");

    switch (Console.ReadLine()?.Trim())
    {
        case "1":
            foreach (var item in catalog.GetAll())
                Console.WriteLine($"  {item.StatusLine()}");
            break;

        case "2":
            Console.Write("Barcode: ");
            // M7: services THROW, the UI layer CATCHES — separation of concerns
            try
            {
                var item = checkoutService.Borrow(Console.ReadLine()?.Trim() ?? "");
                Console.WriteLine($"✓ '{item.Title}' due back {item.DueDate:d}");
                LibraryStorage.Save(catalog.GetAll(), dataPath);
            }
            catch (ItemNotFoundException ex)
            {
                Console.WriteLine($"✗ {ex.Message} (you typed: {ex.Barcode})");
            }
            catch (ItemUnavailableException ex)
            {
                Console.WriteLine($"✗ {ex.Message}");
            }
            break;

        case "3":
            Console.Write("Barcode: ");
            try
            {
                var item = checkoutService.GiveBack(Console.ReadLine()?.Trim() ?? "");
                Console.WriteLine($"✓ '{item.Title}' returned.");
                LibraryStorage.Save(catalog.GetAll(), dataPath);
            }
            catch (Exception ex) when (ex is ItemNotFoundException or ItemUnavailableException)
            {
                Console.WriteLine($"✗ {ex.Message}");
            }
            break;

        case "4":   // M5 step 5.4
            var overdue = catalog.Where(i => i.IsOverdue).ToList();
            if (overdue.Count == 0) { Console.WriteLine("Nothing overdue 🎉"); break; }
            foreach (var i in overdue)
                Console.WriteLine($"  {i.Title,-15} {i.DaysLate} days late — fee {i.CurrentFee:C}");
            break;

        case "5":
            Reports.RunMenu(catalog);
            break;

        case "6":   // demo helper to create overdue data
            Console.Write("Barcode to backdate: ");
            var target = catalog.Find(i => i.Barcode == Console.ReadLine()?.Trim());
            if (target is null) { Console.WriteLine("Not found."); break; }
            if (!target.IsCheckedOut) target.Checkout();
            target.BackdateForDemo(days: 10);
            Console.WriteLine($"'{target.Title}' is now 10 days overdue (demo).");
            break;

        case "7":
            LibraryStorage.Save(catalog.GetAll(), dataPath);   // M7: save on exit
            Console.WriteLine("Saved. Goodbye! 📚");
            return;

        default:
            Console.WriteLine("Invalid option.");
            break;
    }
}

static void SeedCatalog(IRepository<LibraryItem> catalog)
{
    catalog.Add(new Book("Dune", "B-001", "Frank Herbert", 412));
    catalog.Add(new Book("1984", "B-002", "George Orwell", 328));
    catalog.Add(new Book("Emma", "B-003", "Jane Austen", 474));
    catalog.Add(new Dvd("Inception", "D-101", 148));
    catalog.Add(new Dvd("Arrival", "D-102", 116));
    catalog.Add(new Magazine("Wired", "M-501", 6));
    catalog.Add(new Magazine("National Geographic", "M-502", 3));
}

// ═══════════════════ M5: Media hierarchy ══════════════════════════

public abstract class LibraryItem
{
    public string Title   { get; }
    public string Barcode { get; }
    public bool IsCheckedOut { get; private set; }
    public DateTime? DueDate { get; private set; }
    public int TimesBorrowed { get; private set; }

    protected LibraryItem(string title, string barcode)
    {
        Title = title;
        Barcode = barcode;
    }

    public abstract int LoanDays { get; }
    public virtual decimal DailyLateFee => 0.25m;

    public bool IsOverdue   => IsCheckedOut && DueDate < DateTime.Today;
    public int  DaysLate    => IsOverdue ? (DateTime.Today - DueDate!.Value).Days : 0;
    public decimal CurrentFee => DaysLate * DailyLateFee;

    // virtual so ReferenceBook (challenge) can forbid checkout
    public virtual bool Checkout()
    {
        if (IsCheckedOut) return false;
        IsCheckedOut = true;
        DueDate = DateTime.Today.AddDays(LoanDays);   // polymorphic LoanDays!
        TimesBorrowed++;
        return true;
    }

    public bool Return()
    {
        if (!IsCheckedOut) return false;
        IsCheckedOut = false;
        DueDate = null;
        return true;
    }

    public virtual string StatusLine()
        => $"[{Barcode}] {Title,-22} ({GetType().Name,-8}) " +
           (IsCheckedOut ? $"OUT — due {DueDate:d}" : "Available");

    // demo/testing hook (also used by JSON restore)
    public void BackdateForDemo(int days)
    {
        if (IsCheckedOut) DueDate = DateTime.Today.AddDays(-days);
    }
    internal void RestoreState(bool isOut, DateTime? due, int borrowed)
    {
        IsCheckedOut = isOut; DueDate = due; TimesBorrowed = borrowed;
    }
}

public class Book : LibraryItem
{
    public string Author { get; }
    public int    Pages  { get; }
    public Book(string title, string barcode, string author, int pages)
        : base(title, barcode) { Author = author; Pages = pages; }
    public override int LoanDays => 21;
}

public class Dvd : LibraryItem
{
    public int RuntimeMinutes { get; }
    public Dvd(string title, string barcode, int runtime)
        : base(title, barcode) => RuntimeMinutes = runtime;
    public override int LoanDays => 7;
    public override decimal DailyLateFee => 1.00m;
}

public class Magazine : LibraryItem
{
    public int IssueNumber { get; }
    public Magazine(string title, string barcode, int issue)
        : base(title, barcode) => IssueNumber = issue;
    public override int LoanDays => 3;
    public override string StatusLine() => base.StatusLine() + $"  Issue #{IssueNumber}";
}

// M5 challenge: reference materials never leave the building
public class ReferenceBook : Book
{
    public ReferenceBook(string title, string barcode, string author, int pages)
        : base(title, barcode, author, pages) { }
    public override bool Checkout() => false;   // always refuses
    public override string StatusLine() => base.StatusLine() + "  [REFERENCE ONLY]";
}

// ═══════════════════ M6: Generic repository ═══════════════════════

public interface IRepository<T> where T : class
{
    void Add(T item);
    bool Remove(T item);
    T?   Find(Func<T, bool> predicate);
    IEnumerable<T> GetAll();
    IEnumerable<T> Where(Func<T, bool> predicate);
    int  Count { get; }
}

public class InMemoryRepository<T> : IRepository<T> where T : class
{
    private readonly List<T> _items = new();
    public int Count => _items.Count;
    public void Add(T item) => _items.Add(item);
    public bool Remove(T item) => _items.Remove(item);
    public T? Find(Func<T, bool> predicate) => _items.FirstOrDefault(predicate);
    public IEnumerable<T> GetAll() => _items.AsReadOnly();
    public IEnumerable<T> Where(Func<T, bool> predicate) => _items.Where(predicate);
}

public record Member(int Id, string Name, string Email);

// ═══════════════════ M7: Exceptions + service layer ═══════════════

public class ItemNotFoundException : Exception
{
    public string Barcode { get; }
    public ItemNotFoundException(string barcode)
        : base($"No item with barcode '{barcode}'.") => Barcode = barcode;
}

public class ItemUnavailableException : Exception
{
    public string Title { get; }
    public DateTime? DueBack { get; }
    public ItemUnavailableException(string title, DateTime? dueBack, string reason)
        : base($"'{title}' {reason}" + (dueBack is null ? "" : $" (due back {dueBack:d})"))
    { Title = title; DueBack = dueBack; }
}

public class CheckoutService
{
    private readonly IRepository<LibraryItem> _catalog;
    public CheckoutService(IRepository<LibraryItem> catalog) => _catalog = catalog;

    public LibraryItem Borrow(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase))
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Checkout())
            throw new ItemUnavailableException(item.Title, item.DueDate, "is already checked out");
        return item;
    }

    public LibraryItem GiveBack(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode.Equals(barcode, StringComparison.OrdinalIgnoreCase))
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Return())
            throw new ItemUnavailableException(item.Title, null, "was not checked out");
        return item;
    }
}

// ═══════════════════ M7: JSON persistence ═════════════════════════
// Polymorphic save via a "Kind" discriminator on a flat DTO.
// (Alternative shown in class: [JsonDerivedType] on the hierarchy.)

public record ItemData(
    string Kind, string Title, string Barcode,
    bool IsCheckedOut, DateTime? DueDate, int TimesBorrowed,
    string? Author = null, int? Pages = null,
    int? RuntimeMinutes = null, int? IssueNumber = null);

public static class LibraryStorage
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public static void Save(IEnumerable<LibraryItem> items, string path)
    {
        var dtos = items.Select(i => i switch
        {
            Dvd d      => new ItemData("Dvd", d.Title, d.Barcode, d.IsCheckedOut, d.DueDate, d.TimesBorrowed, RuntimeMinutes: d.RuntimeMinutes),
            Magazine m => new ItemData("Magazine", m.Title, m.Barcode, m.IsCheckedOut, m.DueDate, m.TimesBorrowed, IssueNumber: m.IssueNumber),
            Book b     => new ItemData("Book", b.Title, b.Barcode, b.IsCheckedOut, b.DueDate, b.TimesBorrowed, b.Author, b.Pages),
            _          => throw new NotSupportedException($"Unknown item type {i.GetType().Name}")
        });
        File.WriteAllText(path, JsonSerializer.Serialize(dtos, Options));
    }

    public static List<LibraryItem> Load(string path)
    {
        if (!File.Exists(path)) return new();
        var dtos = JsonSerializer.Deserialize<List<ItemData>>(File.ReadAllText(path)) ?? new();

        var items = new List<LibraryItem>();
        foreach (var d in dtos)
        {
            LibraryItem item = d.Kind switch
            {
                "Book"     => new Book(d.Title, d.Barcode, d.Author ?? "Unknown", d.Pages ?? 0),
                "Dvd"      => new Dvd(d.Title, d.Barcode, d.RuntimeMinutes ?? 0),
                "Magazine" => new Magazine(d.Title, d.Barcode, d.IssueNumber ?? 0),
                _          => throw new NotSupportedException($"Unknown kind '{d.Kind}' in save file")
            };
            item.RestoreState(d.IsCheckedOut, d.DueDate, d.TimesBorrowed);
            items.Add(item);
        }
        return items;
    }
}

// ═══════════════════ M8: LINQ reports ═════════════════════════════

public static class Reports
{
    public static void RunMenu(IRepository<LibraryItem> catalog)
    {
        Console.WriteLine("\n── REPORTS ─────────────────────");
        Console.WriteLine("a. Available (alphabetical)");
        Console.WriteLine("b. Due soonest");
        Console.WriteLine("c. Catalog by type");
        Console.WriteLine("d. Overdue fee summary");
        Console.WriteLine("e. Shelf report (by first letter)");
        Console.WriteLine("f. Most borrowed");
        Console.Write("Pick: ");

        var all = catalog.GetAll().ToList();
        switch (Console.ReadLine()?.Trim().ToLower())
        {
            case "a":   // R1
                foreach (var i in all.Where(i => !i.IsCheckedOut).OrderBy(i => i.Title))
                    Console.WriteLine($"  {i.Title}");
                break;

            case "b":   // R2 — days remaining on active loans
                foreach (var x in all
                    .Where(i => i.IsCheckedOut)
                    .OrderBy(i => i.DueDate)
                    .Select(i => new { i.Title, Days = (i.DueDate!.Value - DateTime.Today).Days }))
                    Console.WriteLine($"  {x.Title,-20} {(x.Days < 0 ? $"{-x.Days} days OVERDUE" : $"{x.Days} days left")}");
                break;

            case "c":   // R3 — GroupBy type
                foreach (var g in all.GroupBy(i => i.GetType().Name).OrderByDescending(g => g.Count()))
                    Console.WriteLine($"  {g.Key,-10} {g.Count()}");
                break;

            case "d":   // R4 — aggregates
                var od = all.Where(i => i.IsOverdue).ToList();
                Console.WriteLine($"  Overdue items: {od.Count}");
                Console.WriteLine($"  Total fees:    {od.Sum(i => i.CurrentFee):C}");
                var worst = od.MaxBy(i => i.DaysLate);
                Console.WriteLine($"  Worst:         {worst?.Title ?? "—"} ({worst?.DaysLate ?? 0} days)");
                break;

            case "e":   // R5 — shelf report
                foreach (var g in all
                    .GroupBy(i => char.ToUpper(i.Title[0]))
                    .OrderBy(g => g.Key))
                    Console.WriteLine($"  {g.Key}: {string.Join(", ", g.Select(i => i.Title).OrderBy(t => t))}");
                break;

            case "f":   // challenge C2 — most borrowed
                foreach (var i in all.OrderByDescending(i => i.TimesBorrowed).Take(3))
                    Console.WriteLine($"  {i.Title,-20} borrowed {i.TimesBorrowed}x");
                break;
        }
    }
}
