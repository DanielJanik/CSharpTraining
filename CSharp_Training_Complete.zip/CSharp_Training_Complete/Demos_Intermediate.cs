// ============================================================
//  C# Training – INTERMEDIATE DEMOS (Instructor File)
//  Cherry-pickable modules: run any subset by commenting in/out
// ============================================================
//  MODULES:
//    I1 – Inheritance & Polymorphism (media hierarchy)
//    I2 – Interfaces (contracts & multiple implementation)
//    I3 – Generics (repository pattern + constraints)
//    I4 – Collections Deep Dive (Dictionary, HashSet, Queue, Stack)
//    I5 – Exception Handling & Custom Exceptions
//    I6 – File I/O & JSON Serialization
//    I7 – LINQ Essentials (filtering, projection, grouping)
//    I8 – Extension Methods
// ------------------------------------------------------------
//  RUN: dotnet new console -n IntermediateDemos
//       copy this into Program.cs, then: dotnet run
// ============================================================

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

Console.WriteLine("=== INTERMEDIATE DEMOS ===\n");

// ── Cherry-pick: comment out modules you don't need ──────────────
IntermediateDemos.I1_InheritancePolymorphism();
IntermediateDemos.I2_Interfaces();
IntermediateDemos.I3_Generics();
IntermediateDemos.I4_CollectionsDeepDive();
IntermediateDemos.I5_ExceptionHandling();
IntermediateDemos.I6_FileIOAndJson();
IntermediateDemos.I7_LinqEssentials();
IntermediateDemos.I8_ExtensionMethods();

static class IntermediateDemos
{
    // ══════════════════════════════════════════════════════════════
    // I1 – Inheritance & Polymorphism
    // A library carries Books, DVDs, and Magazines — different rules,
    // same base. Show virtual/override/abstract/base in one hierarchy.
    // ══════════════════════════════════════════════════════════════
    public static void I1_InheritancePolymorphism()
    {
        Console.WriteLine("── I1: Inheritance & Polymorphism ──────────────");

        var items = new List<LibraryItem>
        {
            new PrintBook("Dune", "B-001", 412),
            new Dvd("Inception", "D-101", 148),
            new Magazine("Wired", "M-501", 2024, 6),
        };

        // POLYMORPHISM: one loop, three behaviors
        foreach (var item in items)
        {
            Console.WriteLine($"  {item.Describe()}");
            Console.WriteLine($"    Loan period: {item.LoanDays} days, Late fee: {item.DailyLateFee():C}/day");
        }

        // is / as / pattern matching with hierarchy
        foreach (var item in items)
        {
            string extra = item switch
            {
                PrintBook b => $"{b.Pages} pages",
                Dvd d       => $"{d.RuntimeMinutes} min runtime",
                Magazine m  => $"Issue {m.Issue}/{m.Year}",
                _           => "unknown"
            };
            Console.WriteLine($"  Pattern match: {item.Title} → {extra}");
        }
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I2 – Interfaces
    // Show: a class implementing TWO interfaces, interface as a
    // parameter type, default interface members (C# 8+)
    // ══════════════════════════════════════════════════════════════
    public static void I2_Interfaces()
    {
        Console.WriteLine("── I2: Interfaces ───────────────────────────────");

        var kiosk = new SelfCheckoutKiosk();

        // The SAME object through two different interface "lenses"
        IScanner scanner   = kiosk;
        IPrinter printer   = kiosk;

        var barcode = scanner.Scan();
        printer.Print($"Scanned item: {barcode}");
        printer.PrintReceipt("Dune", DateTime.Now.AddDays(14));  // default interface member!

        // Interface as a parameter — accepts ANYTHING that can print
        static void RunDiagnostics(IPrinter device)
            => device.Print("Diagnostics OK ✓");

        RunDiagnostics(kiosk);

        // IComparable<T> — make your own types sortable
        var holds = new List<HoldRequest>
        {
            new("Carol", priority: 2),
            new("Alice", priority: 1),
            new("Bob",   priority: 3),
        };
        holds.Sort();  // works because HoldRequest : IComparable<HoldRequest>
        Console.WriteLine($"  Hold queue: {string.Join(" → ", holds.Select(h => h.Patron))}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I3 – Generics
    // Build a generic in-memory repository — the pattern students
    // will use in the lab. Show constraints and why they matter.
    // ══════════════════════════════════════════════════════════════
    public static void I3_Generics()
    {
        Console.WriteLine("── I3: Generics ─────────────────────────────────");

        // One repository class works for ANY entity type
        var bookRepo   = new InMemoryRepository<PrintBook>();
        var memberRepo = new InMemoryRepository<Member>();

        bookRepo.Add(new PrintBook("Dune", "B-001", 412));
        bookRepo.Add(new PrintBook("1984", "B-002", 328));
        memberRepo.Add(new Member(1, "Alice"));

        Console.WriteLine($"  Books in repo:   {bookRepo.Count}");
        Console.WriteLine($"  Members in repo: {memberRepo.Count}");
        Console.WriteLine($"  Find: {bookRepo.Find(b => b.Title == "Dune")?.Title ?? "not found"}");

        // Generic method with constraint
        static T Oldest<T>(IEnumerable<T> items) where T : LibraryItem
            => items.OrderBy(i => i.Barcode).First();

        Console.WriteLine($"  Oldest barcode: {Oldest(bookRepo.GetAll()).Title}");

        // WHY constraints? Without `where T : LibraryItem`, the compiler
        // wouldn't let us access .Barcode — it wouldn't know T has one!
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I4 – Collections Deep Dive
    // When to use Dictionary vs HashSet vs Queue vs Stack
    // ══════════════════════════════════════════════════════════════
    public static void I4_CollectionsDeepDive()
    {
        Console.WriteLine("── I4: Collections Deep Dive ────────────────────");

        // Dictionary<K,V> — O(1) lookup by key
        var catalog = new Dictionary<string, string>
        {
            ["B-001"] = "Dune",
            ["B-002"] = "1984",
        };
        // Safe lookup patterns:
        if (catalog.TryGetValue("B-001", out var title))
            Console.WriteLine($"  Dictionary hit: {title}");
        Console.WriteLine($"  GetValueOrDefault: {catalog.GetValueOrDefault("B-999", "<missing>")}");

        // HashSet<T> — uniqueness, fast Contains
        var bannedPatrons = new HashSet<int> { 13, 27 };
        Console.WriteLine($"  Patron 13 banned? {bannedPatrons.Contains(13)}");
        bannedPatrons.Add(13);  // duplicate silently ignored
        Console.WriteLine($"  Set count after dup add: {bannedPatrons.Count}");

        // Queue<T> — FIFO: the holds waiting list
        var holdQueue = new Queue<string>();
        holdQueue.Enqueue("Alice");
        holdQueue.Enqueue("Bob");
        holdQueue.Enqueue("Carol");
        Console.WriteLine($"  Next hold goes to: {holdQueue.Dequeue()} (then {holdQueue.Peek()})");

        // Stack<T> — LIFO: undo history
        var undoStack = new Stack<string>();
        undoStack.Push("checkout B-001");
        undoStack.Push("renew B-002");
        Console.WriteLine($"  Undo last action: {undoStack.Pop()}");

        // Choosing guide (say it out loud in class):
        //   Need key→value lookup?       Dictionary
        //   Need uniqueness?             HashSet
        //   First-come-first-served?     Queue
        //   Most-recent-first?           Stack
        //   Just an ordered bag?         List
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I5 – Exception Handling & Custom Exceptions
    // try/catch/finally, exception filters, custom exception with
    // context properties, throw vs throw ex
    // ══════════════════════════════════════════════════════════════
    public static void I5_ExceptionHandling()
    {
        Console.WriteLine("── I5: Exception Handling ───────────────────────");

        var checkout = new CheckoutService();

        // Custom exception carries CONTEXT, not just a message
        try
        {
            checkout.Borrow(memberId: 13, barcode: "B-001");
        }
        catch (PatronSuspendedException ex)
        {
            Console.WriteLine($"  Caught: {ex.Message}");
            Console.WriteLine($"  Context → MemberId={ex.MemberId}, Until={ex.SuspendedUntil:d}");
        }

        // Exception filter — catch only SOME instances
        try
        {
            checkout.Borrow(memberId: 1, barcode: "MISSING");
        }
        catch (KeyNotFoundException ex) when (ex.Message.Contains("MISSING"))
        {
            Console.WriteLine($"  Filtered catch: {ex.Message}");
        }

        // finally — ALWAYS runs (cleanup)
        try
        {
            Console.WriteLine("  In try block...");
            throw new InvalidOperationException("boom");
        }
        catch (InvalidOperationException)
        {
            Console.WriteLine("  In catch block...");
        }
        finally
        {
            Console.WriteLine("  finally ALWAYS runs (close files, release locks)");
        }

        // INSTRUCTOR TALKING POINT: throw; vs throw ex;
        //   throw;     → preserves original stack trace  ✓
        //   throw ex;  → RESETS stack trace — hides the real origin  ✗
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I6 – File I/O & JSON Serialization
    // Read/write text files, serialize objects to JSON and back —
    // this is how the lab app will persist its data
    // ══════════════════════════════════════════════════════════════
    public static void I6_FileIOAndJson()
    {
        Console.WriteLine("── I6: File I/O & JSON ──────────────────────────");

        string dir = Path.Combine(Path.GetTempPath(), "deweylib-demo");
        Directory.CreateDirectory(dir);

        // Plain text
        string logPath = Path.Combine(dir, "activity.log");
        File.WriteAllLines(logPath, new[]
        {
            $"{DateTime.Now:u} Checkout B-001",
            $"{DateTime.Now:u} Return   B-002",
        });
        File.AppendAllText(logPath, $"{DateTime.Now:u} Renew    B-003\n");

        Console.WriteLine($"  Log file lines: {File.ReadAllLines(logPath).Length}");

        // JSON — the standard persistence format
        var books = new List<BookDto>
        {
            new("Dune", "Frank Herbert", 1965),
            new("1984", "George Orwell", 1949),
        };

        string jsonPath = Path.Combine(dir, "books.json");
        var options = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(jsonPath, JsonSerializer.Serialize(books, options));

        // Round-trip: load it back
        var loaded = JsonSerializer.Deserialize<List<BookDto>>(File.ReadAllText(jsonPath))!;
        Console.WriteLine($"  Round-tripped {loaded.Count} books from JSON:");
        foreach (var b in loaded)
            Console.WriteLine($"    • {b.Title} ({b.Year})");

        // using declaration for streams — deterministic cleanup
        using var writer = new StreamWriter(Path.Combine(dir, "report.txt"));
        writer.WriteLine("Report generated " + DateTime.Now);
        // writer.Dispose() called automatically at end of scope

        Console.WriteLine($"  Files written to: {dir}");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I7 – LINQ Essentials
    // The 8 operators that cover 90% of real-world usage
    // ══════════════════════════════════════════════════════════════
    public static void I7_LinqEssentials()
    {
        Console.WriteLine("── I7: LINQ Essentials ──────────────────────────");

        var loans = new List<Loan>
        {
            new("Dune",  "Alice", new DateTime(2024, 5, 1),  Returned: true),
            new("1984",  "Bob",   new DateTime(2024, 5, 10), Returned: false),
            new("It",    "Alice", new DateTime(2024, 5, 12), Returned: false),
            new("Dune",  "Carol", new DateTime(2024, 5, 15), Returned: true),
            new("Emma",  "Bob",   new DateTime(2024, 5, 20), Returned: false),
        };

        // 1. Where — filter
        var active = loans.Where(l => !l.Returned);
        Console.WriteLine($"  Active loans: {active.Count()}");

        // 2. Select — transform/project
        var titles = loans.Select(l => l.Title).Distinct();
        Console.WriteLine($"  Distinct titles: {string.Join(", ", titles)}");

        // 3. OrderBy / ThenBy
        var ordered = loans.OrderBy(l => l.Patron).ThenByDescending(l => l.Date);
        Console.WriteLine($"  First when sorted: {ordered.First().Patron} / {ordered.First().Title}");

        // 4. GroupBy — the most important one to demo slowly!
        var byPatron = loans.GroupBy(l => l.Patron);
        foreach (var g in byPatron)
            Console.WriteLine($"  {g.Key}: {g.Count()} loans ({string.Join(", ", g.Select(l => l.Title))})");

        // 5. Aggregates
        Console.WriteLine($"  Any overdue? {loans.Any(l => !l.Returned)}");
        Console.WriteLine($"  All returned? {loans.All(l => l.Returned)}");
        Console.WriteLine($"  Earliest loan: {loans.Min(l => l.Date):d}");

        // 6. First vs FirstOrDefault — IMPORTANT difference
        var none = loans.FirstOrDefault(l => l.Patron == "Zed");  // null, no crash
        Console.WriteLine($"  FirstOrDefault missing patron: {(none is null ? "null ✓" : "found")}");
        // loans.First(l => l.Patron == "Zed");  // ← would THROW

        // 7. DEFERRED EXECUTION — the classic gotcha, demo this live!
        var query = loans.Where(l =>
        {
            Console.Write("*");   // side effect proves when it runs
            return !l.Returned;
        });
        Console.Write("  Query defined (no stars yet) → enumerating: ");
        var list = query.ToList();   // NOW the stars print
        Console.WriteLine($" → {list.Count} results");
        Console.WriteLine();
    }

    // ══════════════════════════════════════════════════════════════
    // I8 – Extension Methods
    // Add methods to types you don't own — how LINQ itself works
    // ══════════════════════════════════════════════════════════════
    public static void I8_ExtensionMethods()
    {
        Console.WriteLine("── I8: Extension Methods ────────────────────────");

        // Our custom extensions (defined at bottom of file)
        Console.WriteLine($"  'dune'.ToTitleCase() → {"dune messiah".ToTitleCase()}");
        Console.WriteLine($"  '978-0441172719'.IsIsbn() → {"978-0441172719".IsIsbn()}");
        Console.WriteLine($"  'hello'.IsIsbn() → {"hello".IsIsbn()}");

        // Extension on IEnumerable — just like LINQ operators
        var fees = new[] { 1.25m, 0.0m, 3.50m, 0.0m, 2.00m };
        Console.WriteLine($"  Fees.WhereNonZero().Sum() = {fees.WhereNonZero().Sum():C}");
        Console.WriteLine();
    }
}

// ═══════════════════════════════════════════════════════════════════
//  SUPPORTING TYPES
// ═══════════════════════════════════════════════════════════════════

// ── I1: Media hierarchy ────────────────────────────────────────────
public abstract class LibraryItem
{
    public string Title   { get; }
    public string Barcode { get; }
    protected LibraryItem(string title, string barcode) { Title = title; Barcode = barcode; }

    public abstract int LoanDays { get; }                 // every subclass MUST define
    public virtual decimal DailyLateFee() => 0.25m;        // subclasses MAY override
    public virtual string Describe() => $"{GetType().Name}: '{Title}' [{Barcode}]";
}

public class PrintBook : LibraryItem
{
    public int Pages { get; }
    public PrintBook(string title, string barcode, int pages) : base(title, barcode) => Pages = pages;
    public override int LoanDays => 21;
}

public class Dvd : LibraryItem
{
    public int RuntimeMinutes { get; }
    public Dvd(string title, string barcode, int runtime) : base(title, barcode) => RuntimeMinutes = runtime;
    public override int LoanDays => 7;
    public override decimal DailyLateFee() => 1.00m;       // DVDs cost more when late
    public override string Describe() => base.Describe() + " 📀";
}

public class Magazine : LibraryItem
{
    public int Year  { get; }
    public int Issue { get; }
    public Magazine(string title, string barcode, int year, int issue) : base(title, barcode)
    { Year = year; Issue = issue; }
    public override int LoanDays => 3;
}

// ── I2: Interfaces ─────────────────────────────────────────────────
public interface IScanner { string Scan(); }

public interface IPrinter
{
    void Print(string text);
    // Default interface member (C# 8+) — implementers get it for free
    void PrintReceipt(string title, DateTime dueDate)
        => Print($"RECEIPT: '{title}' due {dueDate:d}");
}

public class SelfCheckoutKiosk : IScanner, IPrinter
{
    public string Scan() => "B-001";
    public void Print(string text) => Console.WriteLine($"  🖨 {text}");
}

public record HoldRequest(string Patron, int priority) : IComparable<HoldRequest>
{
    public int CompareTo(HoldRequest? other) => priority.CompareTo(other?.priority ?? 0);
}

// ── I3: Generic repository ─────────────────────────────────────────
public class InMemoryRepository<T> where T : class
{
    private readonly List<T> _items = new();
    public int Count => _items.Count;
    public void Add(T item) => _items.Add(item);
    public IEnumerable<T> GetAll() => _items.AsReadOnly();
    public T? Find(Func<T, bool> predicate) => _items.FirstOrDefault(predicate);
    public bool Remove(T item) => _items.Remove(item);
}

public record Member(int Id, string Name);

// ── I5: Custom exception + service ─────────────────────────────────
public class PatronSuspendedException : Exception
{
    public int      MemberId       { get; }
    public DateTime SuspendedUntil { get; }
    public PatronSuspendedException(int memberId, DateTime until)
        : base($"Member {memberId} is suspended until {until:d}.")
    { MemberId = memberId; SuspendedUntil = until; }
}

public class CheckoutService
{
    private readonly HashSet<int> _suspended = new() { 13 };
    private readonly Dictionary<string, string> _catalog = new() { ["B-001"] = "Dune" };

    public void Borrow(int memberId, string barcode)
    {
        if (_suspended.Contains(memberId))
            throw new PatronSuspendedException(memberId, DateTime.Today.AddDays(30));
        if (!_catalog.ContainsKey(barcode))
            throw new KeyNotFoundException($"Barcode {barcode} not in catalog.");
        Console.WriteLine($"  ✓ Member {memberId} borrowed {_catalog[barcode]}");
    }
}

// ── I6 / I7: DTOs ──────────────────────────────────────────────────
public record BookDto(string Title, string Author, int Year);
public record Loan(string Title, string Patron, DateTime Date, bool Returned);

// ── I8: Extension methods (must be in a static class) ──────────────
public static class LibraryExtensions
{
    public static string ToTitleCase(this string s)
        => string.Join(' ', s.Split(' ').Select(w =>
            w.Length == 0 ? w : char.ToUpper(w[0]) + w[1..].ToLower()));

    public static bool IsIsbn(this string s)
        => s.Replace("-", "").Length is 10 or 13 &&
           s.Replace("-", "").All(char.IsDigit);

    public static IEnumerable<decimal> WhereNonZero(this IEnumerable<decimal> source)
        => source.Where(x => x != 0m);
}
