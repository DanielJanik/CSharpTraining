// ============================================================
//  LIBRATRACK PROJECT – ADVANCED LABS (Milestones 9–12)
//  Complete your Library Management System
// ============================================================
//  PREREQUISITE: Completed Intermediate M8 (or start from
//  Solutions_Intermediate.cs).
//
//    M9:  Events & Notifications        (delegates, events)
//    M10: Async Operations              (async/await, cancellation)
//    M11: Reflection-Powered Plugins    (reflection, attributes)
//    M12: DeweyLib Web API            (ASP.NET Core capstone)
// ============================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 9: Events & Notifications                       ║
// ║  Skills: events, EventHandler<T>, multicast, decoupling    ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: When library activity happens, multiple independent
//       systems should react — without CheckoutService knowing
//       they exist. That's the event pattern.
//
// STEP 9.1 — Define event args:
//
//   public class CirculationEventArgs : EventArgs
//   {
//       public LibraryItem Item      { get; }
//       public string      Action    { get; }   // "checkout" | "return"
//       public DateTime    Timestamp { get; }
//       ...constructor...
//   }
//
// STEP 9.2 — Add the event to CheckoutService (from M7):
//
//   public event EventHandler<CirculationEventArgs>? ItemCirculated;
//
//   Raise it inside Borrow() and GiveBack() AFTER the state change:
//     ItemCirculated?.Invoke(this, new CirculationEventArgs(item, "checkout", DateTime.Now));
//
// STEP 9.3 — Wire up THREE independent subscribers at startup:
//
//   a) ConsoleNotifier  — prints "🔔 Dune checked out at 2:14 PM"
//   b) ActivityLogger   — appends a line to library.log (reuse M7 challenge)
//   c) HoldWatcher      — keeps a Queue<string> of patron names per
//      barcode; when a RETURN event fires for a barcode with holds,
//      prints "📣 Notify Alice: 'Dune' is now available!" and
//      dequeues her.
//
// STEP 9.4 — Add menu options: "Place hold" (enqueue a name for a
//   barcode) and "Show holds".
//
// 🌶 CHALLENGES:
//   C1: Add an OverdueScanner with its own event that fires once
//       per overdue item when a "Scan for overdue" menu option runs.
//   C2: Unsubscribe demo: a "Do Not Disturb" toggle that does
//       `service.ItemCirculated -= consoleNotifier.Handle;`
//
// ✅ CHECKPOINT M9: Returning a held book triggers, in order:
//    console notification, log line, hold notification — and
//    CheckoutService contains ZERO references to any of the three.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 10: Async Operations                            ║
// ║  Skills: async/await, Task.WhenAll, cancellation, streams  ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Real libraries sync with external systems (cover-art APIs,
//       inter-library loan networks). Simulate these with delays
//       and make the app stay responsive.
//
// STEP 10.1 — Make storage async. Change LibraryStorage (M7) to:
//
//   public static async Task SaveAsync(IEnumerable<LibraryItem> items, string path, CancellationToken ct = default)
//       → use await File.WriteAllTextAsync(...)
//   public static async Task<List<LibraryItem>> LoadAsync(string path, CancellationToken ct = default)
//
//   Update Main to:  static async Task Main(string[] args)
//   and await these calls. (Top-level statements: just use await.)
//
// STEP 10.2 — Simulated external lookups:
//
//   public class ExternalCatalogClient
//   {
//       private static readonly Random _rng = new();
//
//       public async Task<string> FetchCoverArtUrlAsync(string title, CancellationToken ct = default)
//       {
//           await Task.Delay(_rng.Next(200, 800), ct);   // fake network
//           return $"https://covers.example/{title.Replace(' ', '-').ToLower()}.jpg";
//       }
//
//       public async Task<int> CheckBranchAvailabilityAsync(string branch, string title, CancellationToken ct = default)
//       {
//           await Task.Delay(_rng.Next(300, 900), ct);
//           return _rng.Next(0, 4);   // copies available at that branch
//       }
//   }
//
// STEP 10.3 — "Find everywhere" menu option:
//   Given a title, query FOUR branches CONCURRENTLY with
//   Task.WhenAll, time it with Stopwatch, and print:
//     Main: 2 | East: 0 | West: 1 | South: 3   (total 612ms)
//   Then implement it SEQUENTIALLY behind a debug flag and show
//   the timing difference to your neighbor.
//
// STEP 10.4 — Cancellation: give "Find everywhere" a 1-second
//   budget using CancellationTokenSource(TimeSpan.FromSeconds(1)).
//   Catch OperationCanceledException and report partial failure
//   gracefully.
//
// STEP 10.5 — Async stream: implement
//
//   public async IAsyncEnumerable<LibraryItem> ImportFeedAsync(int count)
//       → yields one new Magazine every ~150ms (simulating a feed)
//
//   Menu option "Import latest issues" consumes it with
//   await foreach, adding each to the repository and printing
//   progress AS ITEMS ARRIVE (not all at the end!).
//
// 🌶 CHALLENGES:
//   C1: Add IProgress<int> to ImportFeedAsync's consumer to render
//       a percentage progress indicator.
//   C2: Race two mirrors with Task.WhenAny for cover art; use
//       whichever answers first, cancel the loser.
//   C3: Make all repository methods async (Task-returning) and
//       feel the ripple effect — discuss "async all the way up."
//
// ✅ CHECKPOINT M10: Concurrent branch search is measurably faster
//    than sequential; a 1s timeout cancels cleanly; imported
//    magazines appear one-by-one in real time.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 11: Reflection-Powered Report Plugins           ║
// ║  Skills: attributes, reflection, dynamic invocation        ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Convert your M8 reports into self-registering plugins.
//       Adding a new report should require ZERO menu changes.
//
// STEP 11.1 — Define the attribute:
//
//   [AttributeUsage(AttributeTargets.Method)]
//   public class ReportAttribute : Attribute
//   {
//       public string MenuTitle { get; }
//       public int    Order     { get; set; } = 99;
//       public ReportAttribute(string menuTitle) => MenuTitle = menuTitle;
//   }
//
// STEP 11.2 — Decorate your report methods (move them into a
//   Reports class whose constructor takes IRepository<LibraryItem>):
//
//   [Report("Available items", Order = 1)]
//   public void AvailableItems() { ...your M8 R1 LINQ... }
//
//   [Report("Overdue fees", Order = 4)]
//   public void OverdueFees() { ... }
//
// STEP 11.3 — Build the discovery engine:
//
//   public static class ReportRunner
//   {
//       public static void ShowMenu(object reportsInstance)
//       {
//           var methods = reportsInstance.GetType()
//               .GetMethods(BindingFlags.Public | BindingFlags.Instance)
//               .Select(m => (Method: m, Attr: m.GetCustomAttribute<ReportAttribute>()))
//               .Where(x => x.Attr is not null)
//               .OrderBy(x => x.Attr!.Order)
//               .ToList();
//
//           // TODO: print numbered menu from MenuTitle,
//           //       read choice, then: methods[i].Method.Invoke(reportsInstance, null);
//       }
//   }
//
// STEP 11.4 — Prove it: add a brand-new [Report] method and run
//   the program WITHOUT touching any menu code. It appears.
//
// 🌶 CHALLENGE: Support an optional `string? Category` on the
//   attribute and group the generated menu by category.
//
// ✅ CHECKPOINT M11: The reports menu is generated entirely by
//    reflection; new reports self-register via the attribute.


// ╔════════════════════════════════════════════════════════════╗
// ║  MILESTONE 12 (CAPSTONE): DeweyLib Web API               ║
// ║  Skills: ASP.NET Core, DI, middleware, REST, Swagger       ║
// ╚════════════════════════════════════════════════════════════╝
//
// GOAL: Expose your library over HTTP. Your domain classes
//       (LibraryItem hierarchy, repositories, CheckoutService)
//       move over almost unchanged — that's the payoff of the
//       layering you built in M6/M7.
//
// SETUP:
//   dotnet new webapi -n DeweyLib.Api --use-minimal-apis
//   Copy your domain classes into the project (or better: create
//   a class library DeweyLib.Core and reference it — ask your
//   instructor to demo `dotnet new classlib` + project refs).
//
// STEP 12.1 — Register services in Program.cs:
//
//   builder.Services.AddSingleton<IRepository<LibraryItem>>(sp => SeedCatalog());
//   builder.Services.AddSingleton<CheckoutService>();
//   builder.Services.AddEndpointsApiExplorer();
//   builder.Services.AddSwaggerGen();
//
// STEP 12.2 — Endpoints (route group /api/items):
//
//   GET    /api/items                 → all items; optional ?type=Book&available=true
//   GET    /api/items/{barcode}       → one item or 404
//   POST   /api/items                 → add item (validate with DataAnnotations)
//   POST   /api/items/{barcode}/checkout → 200 with due date, or 409 if unavailable
//   POST   /api/items/{barcode}/return   → 200, or 409 if wasn't out
//   GET    /api/reports/overdue       → overdue items + fees (reuse your LINQ!)
//   GET    /api/reports/by-type       → catalog counts grouped by type
//
// STEP 12.3 — Exception middleware: implement IExceptionHandler
//   mapping your M7 exceptions:
//     ItemNotFoundException    → 404 ProblemDetails
//     ItemUnavailableException → 409 ProblemDetails
//     anything else            → 500
//
// STEP 12.4 — Events still work! Subscribe a logger to
//   CheckoutService.ItemCirculated at startup so every API
//   checkout logs via ILogger. (M9 pays off here.)
//
// STEP 12.5 — Test everything through Swagger UI (/swagger):
//   checkout an item, verify 409 on double-checkout, confirm the
//   overdue report responds with live data.
//
// 🌶 STRETCH GOALS (pick any):
//   S1: Pagination — GET /api/items?page=2&pageSize=5 returning
//       { totalCount, page, pageSize, items }
//   S2: Persist with your M7 JSON storage: load at startup, save
//       on mutation (inject path via IConfiguration)
//   S3: Swap InMemoryRepository for EF Core + SQLite behind the
//       SAME IRepository<T> interface — measure how little changes
//   S4: Add xUnit test project; unit-test CheckoutService.Borrow
//       happy path + both exception paths
//   S5: An IHostedService background worker that scans for overdue
//       items every 30 seconds and logs them
//
// ✅ CHECKPOINT M12 (END OF PROGRAM):
//    □ All 7 endpoints respond correctly in Swagger
//    □ Double-checkout returns 409 with a ProblemDetails body
//      whose detail message comes from YOUR custom exception
//    □ Reports endpoints reuse M8 LINQ with minimal changes
//    □ You can diagram the request flow: HTTP → endpoint →
//      service → repository → domain object, and back
//
//  🏆 Congratulations — you built a layered, event-driven,
//     async-capable application from `Console.WriteLine` up!

Console.WriteLine("DeweyLib Advanced Labs — follow milestones M9–M12 above.");
Console.WriteLine("M12 requires: dotnet new webapi -n DeweyLib.Api --use-minimal-apis");
