namespace DeweyLib;

/// <summary>
/// Milestone 6 — the "plug shape". Describes WHAT a store must do, never HOW.
/// Generic over T so the same contract works for LibraryItem, Member, etc.
/// </summary>
public interface IRepository<T> where T : class
{
    void Add(T item);
    bool Remove(T item);
    T? Find(Func<T, bool> predicate);
    IEnumerable<T> GetAll();
    int Count { get; }
}

/// <summary>
/// Milestone 6 — one reusable, in-memory implementation that satisfies the
/// IRepository&lt;T&gt; promise for any reference type T.
/// </summary>
public class InMemoryRepository<T> : IRepository<T> where T : class
{
    private readonly List<T> _items = new();

    public int Count => _items.Count;

    public void Add(T item) => _items.Add(item);

    public bool Remove(T item) => _items.Remove(item);

    public T? Find(Func<T, bool> predicate) => _items.FirstOrDefault(predicate);

    public IEnumerable<T> GetAll() => _items.AsReadOnly();
}

/// <summary>
/// Milestone 6 — a compact data-holding type, used to demonstrate that the
/// same generic repository manages a completely different kind of data.
/// </summary>
public record Member(int Id, string Name, string Email);
