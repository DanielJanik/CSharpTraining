using System.Text.Json;

namespace DeweyLib;

/// <summary>
/// Milestone 7 — a deliberately FLAT save shape (no inheritance). "Kind"
/// records which concrete subclass each row should be rebuilt into on load.
/// </summary>
public record ItemData(
    string Kind, string Title, string Barcode,
    bool IsCheckedOut, DateTime? DueDate,
    string? Author = null, int? IssueNumber = null);

/// <summary>
/// Milestone 7 — static utility for saving/loading the catalog as JSON, so
/// data survives between runs.
/// </summary>
public static class LibraryStorage
{
    public static void Save(IEnumerable<LibraryItem> items, string path)
    {
        var dtos = items.Select(i => i switch
        {
            Dvd d => new ItemData("Dvd", d.Title, d.Barcode, d.IsCheckedOut, d.DueDate),
            Magazine m => new ItemData("Magazine", m.Title, m.Barcode, m.IsCheckedOut, m.DueDate, IssueNumber: m.IssueNumber),
            Book b => new ItemData("Book", b.Title, b.Barcode, b.IsCheckedOut, b.DueDate, b.Author),
            _ => throw new NotSupportedException()
        });

        var options = new JsonSerializerOptions { WriteIndented = true };
        File.WriteAllText(path, JsonSerializer.Serialize(dtos, options));
    }

    public static List<LibraryItem> Load(string path)
    {
        if (!File.Exists(path)) return new();

        var json = File.ReadAllText(path);
        var dtos = JsonSerializer.Deserialize<List<ItemData>>(json) ?? new();

        var items = new List<LibraryItem>();
        foreach (var d in dtos)
        {
            LibraryItem item = d.Kind switch
            {
                "Book" => new Book(d.Title, d.Barcode, d.Author ?? "Unknown"),
                "Dvd" => new Dvd(d.Title, d.Barcode),
                "Magazine" => new Magazine(d.Title, d.Barcode, d.IssueNumber ?? 0),
                _ => throw new NotSupportedException()
            };

            // The flat shape stores checkout state too — replay it so a
            // checked-out item that was saved comes back checked out, with
            // the same due date it had when saved. (The walkthrough's bare
            // Load omits this; restoring it here is what makes the M7
            // checkpoint — "still checked out after a restart" — actually
            // hold true.)
            if (d.IsCheckedOut && item.Checkout() && d.DueDate is DateTime due)
            {
                // Checkout() just set DueDate to Today + LoanDays. Override it
                // back to the exact stored date. offsetDays is negative when
                // the saved item was already overdue; BackdateForDemo negates
                // its argument, so we pass -offsetDays.
                int offsetDays = (due - DateTime.Today).Days;
                item.BackdateForDemo(-offsetDays);
            }

            items.Add(item);
        }

        return items;
    }
}
