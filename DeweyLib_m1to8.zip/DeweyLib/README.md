# DeweyLib — Milestones 1–8

A complete, runnable console application covering Milestones 1 through 8 of the
DeweyLib walkthrough. This is your starting point for **Milestone 9 (Events)**.

## Run it

```bash
cd DeweyLib
dotnet run
```

Requires the .NET 10 SDK (`dotnet --version` → 10.x). The project was written
and verified against the walkthrough's exact code; it builds with 0 warnings
and 0 errors.

## What each file covers

| File | Milestones | Contents |
|------|-----------|----------|
| `Program.cs` | M1, M2, M3, M7, M8 | Banner & prompts; looping validated menu; logic extracted into methods; startup load + save-after-change; reports submenu |
| `LibraryItem.cs` | M4, M5 | `abstract LibraryItem` base + `Book` / `Dvd` / `Magazine` (and the optional `ReferenceBook`); encapsulated checkout state, due dates, overdue/fee calculation |
| `Repository.cs` | M6 | Generic `IRepository<T>`, `InMemoryRepository<T>`, and the `Member` record |
| `CheckoutService.cs` | M7 | `ItemNotFoundException`, `ItemUnavailableException`, and the `CheckoutService` that throws |
| `LibraryStorage.cs` | M7 | Flat `ItemData` record + JSON save/load |
| `Reports.cs` | M8 | The six LINQ reports (Where, OrderBy, Select, GroupBy, aggregates, conditional search) |

## Menu

```
1. List catalog
2. Check out an item     (enter a barcode, e.g. B-001)
3. Return an item
4. Reports               (the six LINQ reports from M8)
5. Save & exit
```

## Notes / small deviations from the bare walkthrough text

- **Checkout state is persisted across restarts.** The walkthrough's bare
  `Load` rebuilds fresh items without their checked-out state, which would
  fail the M7 checkpoint ("still checked out after a restart"). `Load` here
  restores that state so the checkpoint actually holds.
- **Seed data** includes one backdated-overdue item so Report 4 (overdue fees)
  isn't empty on the very first launch (before any file exists).
- `CurrentFee` (= `DaysLate * DailyLateFee`) is defined on `LibraryItem`; the
  M8 fee report uses it but the walkthrough never spells out its definition.
- Data is saved to `deweylib.json` next to the built executable
  (`bin/.../deweylib.json`). Delete it to reset to seed data.
- Currency in the overdue report renders using your machine's locale (e.g. `$`
  on a US system).
