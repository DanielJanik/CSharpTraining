namespace DeweyLib;

/// <summary>
/// Milestone 7 — raised when no item matches a given barcode. Carries the
/// offending barcode so the catching code can use it directly.
/// </summary>
public class ItemNotFoundException : Exception
{
    public string Barcode { get; }

    public ItemNotFoundException(string barcode)
        : base($"No item with barcode '{barcode}'.") => Barcode = barcode;
}

/// <summary>
/// Milestone 7 — raised when an item can't be borrowed/returned in its
/// current state. Carries the title and (when relevant) the due-back date.
/// </summary>
public class ItemUnavailableException : Exception
{
    public string Title { get; }
    public DateTime? DueBack { get; }

    public ItemUnavailableException(string title, DateTime? dueBack, string reason)
        : base($"'{title}' {reason}")
    {
        Title = title;
        DueBack = dueBack;
    }
}

/// <summary>
/// Milestone 7 — owns the business rules for circulation. It THROWS on
/// failure rather than returning true/false, and knows nothing about how
/// errors will be displayed. The same service will sit unchanged under the
/// Web API in Milestone 12.
/// </summary>
public class CheckoutService
{
    private readonly IRepository<LibraryItem> _catalog;

    public CheckoutService(IRepository<LibraryItem> catalog) => _catalog = catalog;

    public LibraryItem Borrow(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Checkout())
            throw new ItemUnavailableException(item.Title, item.DueDate, "is already checked out");

        return item;
    }

    public LibraryItem GiveBack(string barcode)
    {
        var item = _catalog.Find(i => i.Barcode == barcode)
                   ?? throw new ItemNotFoundException(barcode);

        if (!item.Return())
            throw new ItemUnavailableException(item.Title, null, "was not checked out");

        return item;
    }
}
