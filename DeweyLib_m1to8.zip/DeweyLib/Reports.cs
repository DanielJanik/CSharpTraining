namespace DeweyLib;

/// <summary>
/// Milestone 8 — the six LINQ reports, gathered in one place. Each runs
/// against the live catalog, so results reflect checkouts/returns
/// immediately.
/// </summary>
public static class Reports
{
    // Report 1 — available items, alphabetical by title.
    public static void Available(IRepository<LibraryItem> catalog)
    {
        var available = catalog.GetAll()
            .Where(i => !i.IsCheckedOut)
            .OrderBy(i => i.Title);

        Console.WriteLine("\nAvailable items (A→Z):");
        foreach (var item in available)
            Console.WriteLine($"  {item.Title}");
    }

    // Report 2 — checked-out items, soonest due first, with days remaining.
    public static void DueSoonest(IRepository<LibraryItem> catalog)
    {
        var dueSoonest = catalog.GetAll()
            .Where(i => i.IsCheckedOut)
            .OrderBy(i => i.DueDate)
            .Select(i => new { i.Title, Days = (i.DueDate!.Value - DateTime.Today).Days });

        Console.WriteLine("\nChecked out (due soonest first):");
        foreach (var x in dueSoonest)
            Console.WriteLine($"  {x.Title}: {x.Days} days left");
    }

    // Report 3 — counts and titles, grouped by media type.
    public static void ByType(IRepository<LibraryItem> catalog)
    {
        var byType = catalog.GetAll().GroupBy(i => i.GetType().Name);

        Console.WriteLine("\nCatalog by type:");
        foreach (var group in byType)
        {
            Console.WriteLine($"  {group.Key}: {group.Count()} items");
            foreach (var item in group)
                Console.WriteLine($"    - {item.Title}");
        }
    }

    // Report 4 — fee summary across all overdue items.
    public static void OverdueFees(IRepository<LibraryItem> catalog)
    {
        var overdue = catalog.GetAll().Where(i => i.IsOverdue).ToList();

        Console.WriteLine("\nOverdue summary:");
        Console.WriteLine($"  Overdue items: {overdue.Count}");
        Console.WriteLine($"  Total fees: {overdue.Sum(i => i.CurrentFee):C}");

        var worst = overdue.MaxBy(i => i.DaysLate);
        Console.WriteLine($"  Worst: {worst?.Title} ({worst?.DaysLate} days)");
    }

    // Report 5 — full catalog dump (each item describes itself).
    public static void FullCatalog(IRepository<LibraryItem> catalog)
    {
        Console.WriteLine("\nFull catalog:");
        foreach (var item in catalog.GetAll())
            Console.WriteLine($"  {item.StatusLine()}");
    }

    // Report 6 — conditional search: each filter is applied only if supplied.
    public static void Search(IRepository<LibraryItem> catalog, string? titleFragment, string? typeFilter)
    {
        var query = catalog.GetAll();

        if (!string.IsNullOrEmpty(titleFragment))
            query = query.Where(i => i.Title.Contains(titleFragment, StringComparison.OrdinalIgnoreCase));

        if (!string.IsNullOrEmpty(typeFilter))
            query = query.Where(i => i.GetType().Name.Equals(typeFilter, StringComparison.OrdinalIgnoreCase));

        Console.WriteLine("\nSearch results:");
        var any = false;
        foreach (var item in query)
        {
            Console.WriteLine($"  {item.StatusLine()}");
            any = true;
        }
        if (!any) Console.WriteLine("  (nothing matched)");
    }
}
