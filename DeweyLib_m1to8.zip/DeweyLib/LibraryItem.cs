namespace DeweyLib;

/// <summary>
/// Milestone 5 — the abstract base of the media hierarchy.
/// Holds everything every library item has in common, and protects its
/// own state: IsCheckedOut / DueDate can only ever change via Checkout()
/// and Return(), never from outside the class.
/// </summary>
public abstract class LibraryItem
{
    public string Title { get; }
    public string Barcode { get; }
    public bool IsCheckedOut { get; private set; }
    public DateTime? DueDate { get; private set; }

    protected LibraryItem(string title, string barcode)
    {
        Title = title;
        Barcode = barcode;
    }

    // Each subclass MUST supply its own loan period.
    public abstract int LoanDays { get; }

    // Subclasses MAY override the late fee; default is 25 cents/day.
    public virtual decimal DailyLateFee => 0.25m;

    // Computed fresh every time they are read.
    public bool IsOverdue => IsCheckedOut && DueDate < DateTime.Today;
    public int DaysLate => IsOverdue ? (DateTime.Today - DueDate!.Value).Days : 0;

    // Used by the Milestone 8 fee report (overdue.Sum(i => i.CurrentFee)).
    public decimal CurrentFee => DaysLate * DailyLateFee;

    public virtual bool Checkout()
    {
        if (IsCheckedOut) return false;
        IsCheckedOut = true;
        DueDate = DateTime.Today.AddDays(LoanDays);
        return true;
    }

    public bool Return()
    {
        if (!IsCheckedOut) return false;
        IsCheckedOut = false;
        DueDate = null;
        return true;
    }

    public virtual string StatusLine()
        => $"[{Barcode}] {Title} ({GetType().Name}) "
           + (IsCheckedOut ? $"OUT — due {DueDate:d}" : "Available");

    /// <summary>
    /// Testing helper from Milestone 5 — pretend a checked-out item is
    /// <paramref name="days"/> days overdue, so the overdue report can be
    /// exercised without waiting weeks.
    /// </summary>
    public void BackdateForDemo(int days)
    {
        if (IsCheckedOut) DueDate = DateTime.Today.AddDays(-days);
    }
}

public class Book : LibraryItem
{
    public string Author { get; }

    public Book(string title, string barcode, string author)
        : base(title, barcode) => Author = author;

    public override int LoanDays => 21;
}

public class Dvd : LibraryItem
{
    public Dvd(string title, string barcode) : base(title, barcode) { }

    public override int LoanDays => 7;
    public override decimal DailyLateFee => 1.00m;
}

public class Magazine : LibraryItem
{
    public int IssueNumber { get; }

    public Magazine(string title, string barcode, int issue)
        : base(title, barcode) => IssueNumber = issue;

    public override int LoanDays => 3;
}

/// <summary>
/// Optional-challenge subclass from Milestone 5: reference materials never
/// leave the building, so Checkout() always fails — enforced in one place,
/// with no extra if-statements anywhere else in the program.
/// </summary>
public class ReferenceBook : Book
{
    public ReferenceBook(string title, string barcode, string author)
        : base(title, barcode, author) { }

    public override bool Checkout() => false;
}
