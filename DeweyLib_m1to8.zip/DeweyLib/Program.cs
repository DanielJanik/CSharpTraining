using DeweyLib;

// ─────────────────────────────────────────────────────────────────────────
// DeweyLib — Milestones 1 through 8 complete.
//
//   M1  Console banner, prompts, string interpolation
//   M2  while(true) loop + int.TryParse validation + switch
//   M3  logic extracted into named methods
//   M4  data lives in objects (now the LibraryItem hierarchy from M5)
//   M5  abstract base class + Book / Dvd / Magazine subclasses
//   M6  access flows through IRepository<LibraryItem>
//   M7  CheckoutService throws custom exceptions; JSON persistence
//   M8  six LINQ reports
//
// Start your Milestone 9 (Events) work from here.
// ─────────────────────────────────────────────────────────────────────────

// M6 — declare against the interface, build the concrete type once.
IRepository<LibraryItem> catalog = new InMemoryRepository<LibraryItem>();

// M6 — a second repository for a totally different type, proving the
// generic store is reusable. (Not yet surfaced in the menu; ready for later.)
IRepository<Member> members = new InMemoryRepository<Member>();
members.Add(new Member(1, "Alice", "alice@example.com"));
members.Add(new Member(2, "Bob", "bob@example.com"));

// M7 — load persisted data at startup, falling back to seed data if the
// file is missing or corrupt.
string dataPath = Path.Combine(AppContext.BaseDirectory, "deweylib.json");
try
{
    var loaded = LibraryStorage.Load(dataPath);
    if (loaded.Count > 0)
        foreach (var item in loaded) catalog.Add(item);
    else
        SeedCatalog(catalog);
}
catch (Exception ex)
{
    Console.WriteLine($"⚠ Could not load saved data ({ex.Message}). Starting fresh.");
    SeedCatalog(catalog);
}

// M7 — the service that owns the circulation rules.
var checkoutService = new CheckoutService(catalog);

PrintBanner();

Console.Write("What's your name? ");
string name = Console.ReadLine() ?? "";
Console.WriteLine($"Welcome, {name}!");

// M2 — the forever loop; the only way out is the Exit option, via `return`.
while (true)
{
    switch (GetMenuChoice())
    {
        case 1:
            ListItems(catalog);
            break;

        case 2:
            DoCheckout(checkoutService, catalog, dataPath);
            break;

        case 3:
            DoReturn(checkoutService, catalog, dataPath);
            break;

        case 4:
            ReportsMenu(catalog);
            break;

        case 5:
            Save(catalog, dataPath);
            Console.WriteLine("Goodbye!");
            return; // exits the loop AND the program
    }
}

// ─────────────────────────────────────────────────────────────────────────
// Methods (M3) — top-level local functions.
// ─────────────────────────────────────────────────────────────────────────

// M1 — the welcome banner.
static void PrintBanner()
{
    Console.WriteLine("╔════════════════════════════╗");
    Console.WriteLine("║      📚 DEWEYLIB v0.8      ║");
    Console.WriteLine("╚════════════════════════════╝");
}

// M2 + M3 — print the menu, read a choice, and only return once it's valid.
static int GetMenuChoice()
{
    while (true)
    {
        Console.WriteLine();
        Console.WriteLine("1. List catalog");
        Console.WriteLine("2. Check out an item");
        Console.WriteLine("3. Return an item");
        Console.WriteLine("4. Reports");
        Console.WriteLine("5. Save & exit");
        Console.Write("Choose an option: ");

        string input = Console.ReadLine() ?? "";
        if (int.TryParse(input, out int choice) && choice >= 1 && choice <= 5)
            return choice;

        Console.WriteLine("✗ Invalid option — enter a number 1-5.");
    }
}

// M4/M5/M6 — let every item describe itself, regardless of concrete type.
static void ListItems(IRepository<LibraryItem> catalog)
{
    Console.WriteLine();
    int i = 1;
    foreach (var item in catalog.GetAll())
        Console.WriteLine($"{i++}. {item.StatusLine()}");
}

// M7 — services throw, the UI catches and decides how to display.
static void DoCheckout(CheckoutService service, IRepository<LibraryItem> catalog, string dataPath)
{
    Console.Write("Barcode to check out: ");
    string barcode = Console.ReadLine() ?? "";
    try
    {
        var item = service.Borrow(barcode);
        Console.WriteLine($"✓ '{item.Title}' due back {item.DueDate:d}");
        Save(catalog, dataPath);
    }
    catch (ItemNotFoundException ex)
    {
        Console.WriteLine($"✗ {ex.Message} (you typed: {ex.Barcode})");
    }
    catch (ItemUnavailableException ex)
    {
        Console.WriteLine($"✗ {ex.Message}");
    }
}

static void DoReturn(CheckoutService service, IRepository<LibraryItem> catalog, string dataPath)
{
    Console.Write("Barcode to return: ");
    string barcode = Console.ReadLine() ?? "";
    try
    {
        var item = service.GiveBack(barcode);
        Console.WriteLine($"✓ '{item.Title}' returned.");
        Save(catalog, dataPath);
    }
    catch (ItemNotFoundException ex)
    {
        Console.WriteLine($"✗ {ex.Message} (you typed: {ex.Barcode})");
    }
    catch (ItemUnavailableException ex)
    {
        Console.WriteLine($"✗ {ex.Message}");
    }
}

// M8 — a small submenu over the six LINQ reports.
static void ReportsMenu(IRepository<LibraryItem> catalog)
{
    while (true)
    {
        Console.WriteLine();
        Console.WriteLine("--- Reports ---");
        Console.WriteLine("1. Available items (A→Z)");
        Console.WriteLine("2. Checked out, due soonest");
        Console.WriteLine("3. Grouped by type");
        Console.WriteLine("4. Overdue fee summary");
        Console.WriteLine("5. Full catalog");
        Console.WriteLine("6. Search");
        Console.WriteLine("0. Back");
        Console.Write("Choose a report: ");

        string input = Console.ReadLine() ?? "";
        if (!int.TryParse(input, out int choice))
        {
            Console.WriteLine("✗ Please enter a number.");
            continue;
        }

        switch (choice)
        {
            case 1: Reports.Available(catalog); break;
            case 2: Reports.DueSoonest(catalog); break;
            case 3: Reports.ByType(catalog); break;
            case 4: Reports.OverdueFees(catalog); break;
            case 5: Reports.FullCatalog(catalog); break;
            case 6:
                Console.Write("Title contains (blank = any): ");
                string? title = Console.ReadLine();
                Console.Write("Type (Book/Dvd/Magazine, blank = any): ");
                string? type = Console.ReadLine();
                Reports.Search(catalog, title, type);
                break;
            case 0: return;
            default: Console.WriteLine("✗ Unknown report."); break;
        }
    }
}

// M7 — persist the whole catalog. Wrapped so a write failure can't crash us.
static void Save(IRepository<LibraryItem> catalog, string dataPath)
{
    try
    {
        LibraryStorage.Save(catalog.GetAll(), dataPath);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"⚠ Could not save data ({ex.Message}).");
    }
}

// Sample data used only when there's no saved file yet. A couple of items
// are checked out and backdated so the overdue/fee reports have something
// to show on a fresh run.
static void SeedCatalog(IRepository<LibraryItem> catalog)
{
    catalog.Add(new Book("Dune", "B-001", "Frank Herbert"));
    catalog.Add(new Book("1984", "B-002", "George Orwell"));
    catalog.Add(new Book("The Hobbit", "B-003", "J.R.R. Tolkien"));
    catalog.Add(new Dvd("Inception", "D-101"));
    catalog.Add(new Dvd("Arrival", "D-102"));
    catalog.Add(new Magazine("National Geographic", "M-201", 1));

    // Make one item overdue so Report 4 isn't empty on first launch.
    var hobbit = catalog.Find(i => i.Barcode == "B-003");
    hobbit?.Checkout();
    hobbit?.BackdateForDemo(10);

    var arrival = catalog.Find(i => i.Barcode == "D-102");
    arrival?.Checkout();
}
